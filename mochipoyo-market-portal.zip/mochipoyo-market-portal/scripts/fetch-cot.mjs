// 投機筋の通貨先物ポジション（米CFTC 建玉明細報告 Commitments of Traders・Legacy Futures Only）
// 毎週金曜 15:30（米東部時間）に、その週の火曜時点のポジションが公表されます。
// 出力: data/cot.json
import { join } from "node:path";
import { httpGet, writeJson, addDays, ymd, num } from "./lib/util.mjs";

const ENDPOINT = "https://publicreporting.cftc.gov/resource/6dca-aqww.json";
export const CURRENCIES = [
  { ccy: "JPY", code: "097741", name: "日本円" },
  { ccy: "GBP", code: "096742", name: "英ポンド" },
  { ccy: "EUR", code: "099741", name: "ユーロ" },
  { ccy: "AUD", code: "232741", name: "豪ドル" },
  { ccy: "NZD", code: "112741", name: "NZドル" },
  { ccy: "CAD", code: "090741", name: "カナダドル" },
  { ccy: "CHF", code: "092741", name: "スイスフラン" },
  { ccy: "MXN", code: "095741", name: "メキシコペソ" }
];
const FIELDS = [
  "report_date_as_yyyy_mm_dd", "cftc_contract_market_code", "open_interest_all",
  "noncomm_positions_long_all", "noncomm_positions_short_all",
  "comm_positions_long_all", "comm_positions_short_all",
  "nonrept_positions_long_all", "nonrept_positions_short_all"
];

export function buildUrl(since) {
  const codes = CURRENCIES.map((c) => `'${c.code}'`).join(",");
  const params = new URLSearchParams({
    $select: FIELDS.join(","),
    $where: `cftc_contract_market_code in(${codes}) AND report_date_as_yyyy_mm_dd >= '${since}T00:00:00.000'`,
    $order: "report_date_as_yyyy_mm_dd DESC",
    $limit: "5000"
  });
  return `${ENDPOINT}?${params.toString()}`;
}

export function shape(records) {
  const by = new Map(CURRENCIES.map((c) => [c.code, new Map()]));
  for (const r of records) {
    const m = by.get(String(r.cftc_contract_market_code || "").trim());
    if (!m) continue;
    const d = String(r.report_date_as_yyyy_mm_dd || "").slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) continue;
    const row = [d, num(r.open_interest_all), num(r.noncomm_positions_long_all), num(r.noncomm_positions_short_all),
      num(r.comm_positions_long_all), num(r.comm_positions_short_all), num(r.nonrept_positions_long_all), num(r.nonrept_positions_short_all)];
    if (row.slice(1, 4).some((v) => v === null)) continue;
    m.set(d, row);
  }
  return CURRENCIES.map((c) => ({
    ...c,
    rows: [...by.get(c.code).values()].sort((a, b) => (a[0] < b[0] ? -1 : 1))
  }));
}

export async function run({ fetch: fetchImpl = fetch, outDir, now = new Date(), env = process.env, log = console.log } = {}) {
  const since = addDays(ymd(now), -7 * 110);
  const headers = env.SOCRATA_APP_TOKEN ? { "X-App-Token": env.SOCRATA_APP_TOKEN } : {};
  const records = await httpGet(fetchImpl, buildUrl(since), { as: "json", headers, timeoutMs: 60000 });
  if (!Array.isArray(records)) throw new Error("CFTC: 想定外の応答");
  const currencies = shape(records);
  const missing = currencies.filter((c) => !c.rows.length).map((c) => c.ccy);
  if (missing.length === currencies.length) throw new Error("CFTC: 対象通貨のデータがありません");
  const latest = currencies.map((c) => c.rows.at(-1)?.[0]).filter(Boolean).sort().at(-1);
  await writeJson(join(outDir, "cot.json"), {
    updated: now.toISOString(),
    source: "米商品先物取引委員会（CFTC）Commitments of Traders（Legacy・Futures Only）",
    columns: ["date", "open_interest", "noncomm_long", "noncomm_short", "comm_long", "comm_short", "nonrept_long", "nonrept_short"],
    latest,
    currencies
  });
  log(`CFTC: ${currencies.length}通貨（最新 ${latest}${missing.length ? `、欠け: ${missing.join(",")}` : ""}）`);
  return { ok: true, message: missing.length ? `一部欠け ${missing.join(",")}` : `${currencies.length}通貨`, asOf: latest };
}
