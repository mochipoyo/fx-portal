// 米国の金利・経済指標・為替参考値（FRED API）
// 必要: 環境変数 FRED_API_KEY（無料。https://fred.stlouisfed.org/docs/api/api_key.html で取得）
// 出力: data/us_rates.json, data/us_macro.json, data/fx_ref.json
import { join } from "node:path";
import { httpGet, writeJson, addDays, addMonths, ymd, num, round, sleep } from "./lib/util.mjs";

const API = "https://api.stlouisfed.org/fred/series/observations";

export const RATE_SERIES = [
  ["DGS3MO", "3カ月"], ["DGS2", "2年"], ["DGS5", "5年"], ["DGS10", "10年"], ["DGS30", "30年"]
];
const FED_SERIES = ["DFEDTARL", "DFEDTARU"];
const FX_SERIES = ["DEXJPUS", "DEXUSUK", "DEXUSEU"];
const MACRO_SERIES = ["CPIAUCSL", "CPILFESL", "PCEPI", "PCEPILFE", "UNRATE", "PAYEMS", "CES0500000003", "ICSA", "SAHMREALTIME"];

async function getSeries(fetchImpl, key, id, start) {
  const url = `${API}?series_id=${id}&api_key=${encodeURIComponent(key)}&file_type=json&observation_start=${start}`;
  const json = await httpGet(fetchImpl, url, { as: "json" });
  if (!json || !Array.isArray(json.observations)) throw new Error(`${id}: 想定外の応答`);
  const out = [];
  for (const o of json.observations) {
    const v = num(o.value);
    if (v !== null && /^\d{4}-\d{2}-\d{2}$/.test(o.date)) out.push([o.date, v]);
  }
  return out;
}

// ---------- 加工（テストしやすいよう個別に公開） ----------
// 前年同月比(%)：同じ月の12カ月前と比べる
export function yoy(obs, lag = 12) {
  const map = new Map(obs.map(([d, v]) => [d, v]));
  const out = [];
  for (const [d, v] of obs) {
    const prev = map.get(addMonths(d, -lag));
    if (prev) out.push([d, round((v / prev - 1) * 100, 2)]);
  }
  return out;
}
// 前月比(%)
export function mom(obs) {
  const out = [];
  for (let i = 1; i < obs.length; i++) {
    if (addMonths(obs[i - 1][0], 1) !== obs[i][0]) continue; // 欠けた月はとばす
    out.push([obs[i][0], round((obs[i][1] / obs[i - 1][1] - 1) * 100, 2)]);
  }
  return out;
}
// 前月差
export function diff(obs) {
  const out = [];
  for (let i = 1; i < obs.length; i++) {
    if (addMonths(obs[i - 1][0], 1) !== obs[i][0]) continue;
    out.push([obs[i][0], round(obs[i][1] - obs[i - 1][1], 1)]);
  }
  return out;
}
// 2系列を日付でそろえて掛け算（例：ドル円 × ポンドドル ＝ ポンド円）
export function crossMultiply(a, b, digits = 3) {
  const m = new Map(b);
  const out = [];
  for (const [d, v] of a) {
    const w = m.get(d);
    if (w !== undefined) out.push([d, round(v * w, digits)]);
  }
  return out;
}
// 変化した日だけを残す（政策金利のような階段状のデータを軽くする）
export function changePoints(obs) {
  const out = [];
  for (const [d, v] of obs) {
    if (!out.length || out[out.length - 1][1] !== v) out.push([d, v]);
  }
  return out;
}
const tail = (arr, n) => arr.slice(Math.max(0, arr.length - n));
const pick = (series) => ({
  latest: series.length ? { date: series[series.length - 1][0], value: series[series.length - 1][1] } : null,
  prev: series.length > 1 ? { date: series[series.length - 2][0], value: series[series.length - 2][1] } : null
});

export function buildMacro(raw) {
  const ind = [];
  const add = (o, series) => ind.push({ ...o, ...pick(series), series });
  add({ id: "cpi", name: "消費者物価指数（CPI）", measure: "前年比", unit: "%", freq: "M", src: "BLS", fred: ["CPIAUCSL"], hint: "物価の勢い。高いほど利下げしにくい" }, tail(yoy(raw.CPIAUCSL), 36));
  add({ id: "core_cpi", name: "コアCPI（食品・エネルギー除く）", measure: "前年比", unit: "%", freq: "M", src: "BLS", fred: ["CPILFESL"], hint: "FRBが重視する基調的な物価" }, tail(yoy(raw.CPILFESL), 36));
  add({ id: "cpi_mom", name: "CPI", measure: "前月比", unit: "%", freq: "M", src: "BLS", fred: ["CPIAUCSL"], hint: "直近1カ月の物価の伸び" }, tail(mom(raw.CPIAUCSL), 36));
  add({ id: "core_pce", name: "コアPCEデフレーター", measure: "前年比", unit: "%", freq: "M", src: "BEA", fred: ["PCEPILFE"], hint: "FRBの物価目標（2%）に使われる指標" }, tail(yoy(raw.PCEPILFE), 36));
  add({ id: "pce", name: "PCEデフレーター", measure: "前年比", unit: "%", freq: "M", src: "BEA", fred: ["PCEPI"], hint: "個人消費全体の物価" }, tail(yoy(raw.PCEPI), 36));
  add({ id: "unrate", name: "失業率", measure: "水準", unit: "%", freq: "M", src: "BLS", fred: ["UNRATE"], hint: "上がると景気減速のサイン" }, tail(raw.UNRATE, 36));
  add({ id: "nfp", name: "非農業部門雇用者数", measure: "前月差", unit: "千人", freq: "M", src: "BLS", fred: ["PAYEMS"], hint: "雇用の増え方。発表後に改定されることが多い" }, tail(diff(raw.PAYEMS), 36));
  add({ id: "ahe", name: "平均時給", measure: "前年比", unit: "%", freq: "M", src: "BLS", fred: ["CES0500000003"], hint: "賃金の伸び。物価の先行きに影響" }, tail(yoy(raw.CES0500000003), 36));
  add({ id: "claims", name: "新規失業保険申請件数", measure: "週次", unit: "件", freq: "W", src: "米労働省", fred: ["ICSA"], hint: "毎週の雇用の体温計" }, tail(raw.ICSA, 104));
  add({ id: "sahm", name: "サーム・ルール指標", measure: "水準", unit: "pt", freq: "M", src: "Claudia Sahm", fred: ["SAHMREALTIME"], hint: "0.50以上で景気後退入りのサインとされる", threshold: 0.5 }, tail(raw.SAHMREALTIME, 36));
  return ind;
}

export async function run({ fetch: fetchImpl = fetch, outDir, env = process.env, now = new Date(), log = console.log } = {}) {
  const key = env.FRED_API_KEY;
  if (!key) return { ok: false, skipped: true, message: "FRED_API_KEY が未設定のためスキップ" };
  const today = ymd(now);
  const raw = {};
  const plan = [
    ...RATE_SERIES.map(([id]) => [id, addDays(today, -365 * 3)]),
    ...FED_SERIES.map((id) => [id, addDays(today, -365 * 6)]),
    ...FX_SERIES.map((id) => [id, addDays(today, -365 * 3)]),
    ...MACRO_SERIES.map((id) => [id, addDays(today, -365 * 5)])
  ];
  for (const [id, start] of plan) {
    raw[id] = await getSeries(fetchImpl, key, id, start);
    if (!raw[id].length) throw new Error(`${id}: データが空です`);
    await sleep(env.NODE_ENV === "test" ? 0 : 250); // 120回/分の上限に余裕をもたせる
  }

  const updated = now.toISOString();
  const fredNote = "This product uses the FRED® API but is not endorsed or certified by the Federal Reserve Bank of St. Louis.";

  // 金利
  const lower = changePoints(raw.DFEDTARL);
  const upper = changePoints(raw.DFEDTARU);
  const lastL = raw.DFEDTARL[raw.DFEDTARL.length - 1];
  const lastU = raw.DFEDTARU[raw.DFEDTARU.length - 1];
  const rates = {
    updated,
    source: "米連邦準備制度理事会（FRB）H.15・FOMC公表値／FRED経由",
    note: fredNote,
    tenors: RATE_SERIES.map(([id, label]) => ({ id, label })),
    series: Object.fromEntries(RATE_SERIES.map(([id]) => [id, raw[id]])),
    fed: { lower: lastL[1], upper: lastU[1], date: lastU[0], lowerHistory: lower, upperHistory: upper }
  };
  await writeJson(join(outDir, "us_rates.json"), rates);

  // 経済指標
  await writeJson(join(outDir, "us_macro.json"), { updated, source: "FRED経由（各統計の作成機関は項目ごとに記載）", note: fredNote, indicators: buildMacro(raw) });

  // 為替の参考値（NY正午レート・週1回更新）
  const fx = {
    updated,
    source: "FRB H.10（NY正午の参考レート）／FRED経由。ポンド円・ユーロ円は当サイトで掛け算して算出",
    note: fredNote,
    usdjpy: raw.DEXJPUS,
    gbpusd: raw.DEXUSUK,
    eurusd: raw.DEXUSEU,
    gbpjpy: crossMultiply(raw.DEXJPUS, raw.DEXUSUK),
    eurjpy: crossMultiply(raw.DEXJPUS, raw.DEXUSEU)
  };
  await writeJson(join(outDir, "fx_ref.json"), fx);

  log(`FRED: ${plan.length}系列を取得（米10年 ${rates.series.DGS10.at(-1).join(" ")}）`);
  return { ok: true, message: `${plan.length}系列`, asOf: rates.series.DGS10.at(-1)[0] };
}
