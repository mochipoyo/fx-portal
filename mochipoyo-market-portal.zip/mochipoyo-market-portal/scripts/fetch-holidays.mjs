// 祝日（東京・ロンドン）
//   日本: 内閣府「国民の祝日について」CSV（Shift_JIS）… 公共データ利用規約（第1.0版）
//   英国: GOV.UK bank holidays（イングランド・ウェールズ）… Open Government Licence v3.0
// 米国（NYSE休場日・連邦祝日）は自動取得元がないため data/manual/holidays_us.json を手で更新します。
// 出力: data/holidays_jp.json, data/holidays_uk.json
import { join } from "node:path";
import { httpGet, writeJson, ymd, parseCsv } from "./lib/util.mjs";

export const URL_JP = "https://www8.cao.go.jp/chosei/shukujitsu/syukujitsu.csv";
export const URL_UK = "https://www.gov.uk/bank-holidays.json";

const UK_JA = {
  "New Year's Day": "元日",
  "Good Friday": "聖金曜日（グッドフライデー）",
  "Easter Monday": "イースターマンデー",
  "Early May bank holiday": "アーリー・メイ・バンクホリデー",
  "Spring bank holiday": "スプリング・バンクホリデー",
  "Summer bank holiday": "サマー・バンクホリデー",
  "Christmas Day": "クリスマス",
  "Boxing Day": "ボクシングデー"
};

export function parseJpCsv(text) {
  const out = [];
  for (const r of parseCsv(text)) {
    const m = String(r[0] || "").trim().match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
    if (!m) continue; // 見出し行など
    out.push([`${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`, String(r[1] || "").trim()]);
  }
  return out;
}

export function shapeUk(json) {
  const ev = json && json["england-and-wales"] && json["england-and-wales"].events;
  if (!Array.isArray(ev)) throw new Error("GOV.UK: england-and-wales が見つかりません");
  return ev
    .filter((e) => /^\d{4}-\d{2}-\d{2}$/.test(e.date))
    .map((e) => {
      const ja = UK_JA[e.title] || e.title;
      const sub = /substitute/i.test(e.notes || "") ? "（振替）" : "";
      return [e.date, ja + sub, e.title];
    })
    .sort((a, b) => (a[0] < b[0] ? -1 : 1));
}

export async function run({ fetch: fetchImpl = fetch, outDir, now = new Date(), log = console.log } = {}) {
  const from = `${new Date(now).getUTCFullYear() - 1}-01-01`;
  const results = [];
  const errors = [];

  try {
    const jp = parseJpCsv(await httpGet(fetchImpl, URL_JP, { encoding: "shift_jis" })).filter(([d]) => d >= from);
    if (!jp.length) throw new Error("日本の祝日が0件");
    await writeJson(join(outDir, "holidays_jp.json"), {
      updated: now.toISOString(),
      source: "内閣府「国民の祝日について」（https://www8.cao.go.jp/chosei/shukujitsu/gaiyou.html）を加工して作成",
      license: "公共データ利用規約（第1.0版）",
      days: jp
    });
    results.push(`日本${jp.length}件（〜${jp.at(-1)[0]}）`);
  } catch (e) { errors.push("日本: " + e.message); }

  try {
    const uk = shapeUk(await httpGet(fetchImpl, URL_UK, { as: "json" })).filter(([d]) => d >= from);
    if (!uk.length) throw new Error("英国の祝日が0件");
    await writeJson(join(outDir, "holidays_uk.json"), {
      updated: now.toISOString(),
      source: "GOV.UK Bank holidays（England and Wales）",
      license: "Contains public sector information licensed under the Open Government Licence v3.0.",
      days: uk
    });
    results.push(`英国${uk.length}件（〜${uk.at(-1)[0]}）`);
  } catch (e) { errors.push("英国: " + e.message); }

  log(`祝日: ${results.join("、")}${errors.length ? "／失敗: " + errors.join("、") : ""}`);
  if (!results.length) throw new Error(errors.join(" / "));
  return { ok: errors.length === 0, message: [...results, ...errors].join("、"), asOf: ymd(now) };
}
