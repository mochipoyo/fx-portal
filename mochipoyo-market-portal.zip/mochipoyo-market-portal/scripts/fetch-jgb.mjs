// 日本国債の金利（財務省「国債金利情報」CSV・Shift_JIS）
// 財務省は前営業日分を「翌営業日の午前9時30分頃」に公表します。
// 出力: data/jgb.json
import { join } from "node:path";
import { httpGet, writeJson, addDays, ymd, num, parseCsv } from "./lib/util.mjs";

export const URL_CURRENT = "https://www.mof.go.jp/jgbs/reference/interest_rate/jgbcm.csv";
export const URL_ALL = "https://www.mof.go.jp/jgbs/reference/interest_rate/data/jgbcm_all.csv";
const ERA = { M: 1867, T: 1911, S: 1925, H: 1988, R: 2018 };

// "R8.10.1" → "2026-10-01"、"2026/10/1" → "2026-10-01"
export function parseJgbDate(s) {
  s = String(s || "").trim();
  let m = s.match(/^([MTSHR])(\d+|元)\.(\d{1,2})\.(\d{1,2})$/);
  if (m) {
    const y = ERA[m[1]] + (m[2] === "元" ? 1 : Number(m[2]));
    return `${y}-${String(m[3]).padStart(2, "0")}-${String(m[4]).padStart(2, "0")}`;
  }
  m = s.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
  if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
  return null;
}

// CSV本文 → { tenors:["1Y",...], rows:[[date,[...]]] }
export function parseJgbCsv(text) {
  const rows = parseCsv(text);
  const h = rows.findIndex((r) => ["基準日", "Date"].includes(String(r[0] || "").trim()));
  if (h < 0) throw new Error("見出し行（基準日）が見つかりません");
  const tenors = rows[h].slice(1).map((c) => String(c).trim()).filter(Boolean)
    .map((c) => c.replace(/年$/, "Y"));
  const out = [];
  for (let i = h + 1; i < rows.length; i++) {
    const r = rows[i];
    const date = parseJgbDate(r[0]);
    if (!date) continue; // 空行・注記行は読み飛ばす
    out.push([date, tenors.map((_, j) => num(r[j + 1]))]);
  }
  return { tenors, rows: out };
}

export function mergeRows(a, b) {
  const m = new Map();
  for (const [d, v] of a) m.set(d, v);
  for (const [d, v] of b) m.set(d, v); // 後から来た方（当月分）を優先
  return [...m.entries()].sort((x, y) => (x[0] < y[0] ? -1 : 1));
}

export async function run({ fetch: fetchImpl = fetch, outDir, now = new Date(), log = console.log } = {}) {
  const curText = await httpGet(fetchImpl, URL_CURRENT, { encoding: "shift_jis" });
  const cur = parseJgbCsv(curText);
  let all = { tenors: cur.tenors, rows: [] };
  try {
    all = parseJgbCsv(await httpGet(fetchImpl, URL_ALL, { encoding: "shift_jis", timeoutMs: 60000 }));
  } catch (e) {
    log(`JGB: 過去分の取得に失敗（当月分のみで続行）: ${e.message}`);
  }
  if (all.tenors.join() !== cur.tenors.join()) {
    throw new Error(`年限の並びが一致しません: ${all.tenors.join()} / ${cur.tenors.join()}`);
  }
  const since = addDays(ymd(now), -365 * 3 - 10);
  const rows = mergeRows(all.rows, cur.rows).filter(([d]) => d >= since);
  if (!rows.length) throw new Error("国債金利のデータ行がありません");
  await writeJson(join(outDir, "jgb.json"), {
    updated: now.toISOString(),
    source: "財務省「国債金利情報」（https://www.mof.go.jp/jgbs/reference/interest_rate/index.htm）を加工して作成",
    license: "公共データ利用規約（第1.0版）",
    tenors: cur.tenors,
    rows
  });
  const last = rows[rows.length - 1];
  log(`JGB: ${rows.length}日分（最新 ${last[0]}、10年 ${last[1][cur.tenors.indexOf("10Y")]}%）`);
  return { ok: true, message: `${rows.length}日分`, asOf: last[0] };
}
