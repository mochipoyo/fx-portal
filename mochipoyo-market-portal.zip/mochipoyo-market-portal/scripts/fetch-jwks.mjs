// Fincsの公開鍵（JWKS）をサイト内にコピーする
// ブラウザからFincsの鍵URLを直接読めない場合（CORS制限）に備え、同じサイト内のファイルとして配信します。
// 出力: data/fincs_jwks.json
import { join } from "node:path";
import { httpGet, writeJson } from "./lib/util.mjs";

export const JWKS_URL = "https://api.fincs.jp/token_access_link/jwks";

export function sanitize(json) {
  if (!json || !Array.isArray(json.keys)) throw new Error("JWKSの形式が不正です");
  const keys = json.keys
    .filter((k) => k && k.kty === "RSA" && typeof k.n === "string" && typeof k.e === "string")
    .map((k) => ({ kty: "RSA", kid: k.kid, use: k.use, alg: k.alg, n: k.n, e: k.e })); // 公開情報のみ残す
  if (!keys.length) throw new Error("RSA公開鍵がありません");
  return { keys };
}

export async function run({ fetch: fetchImpl = fetch, outDir, log = console.log } = {}) {
  const jwks = sanitize(await httpGet(fetchImpl, JWKS_URL, { as: "json" }));
  await writeJson(join(outDir, "fincs_jwks.json"), jwks);
  log(`Fincs JWKS: ${jwks.keys.map((k) => k.kid).join(", ")}`);
  return { ok: true, message: jwks.keys.map((k) => k.kid).join(", ") };
}
