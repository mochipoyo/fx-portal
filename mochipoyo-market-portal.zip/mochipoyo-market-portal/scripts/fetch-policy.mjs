// 主要中央銀行の政策金利（BIS 国際決済銀行「Central bank policy rates」日次・週1回更新）
// BISの利用条件: 出典の明記／BISの公式翻訳ではない旨の表示／統計を理由とした追加料金を取らないこと 等
//   https://data.bis.org/help/legal
// 出力: data/policy_bis.json
import { join } from "node:path";
import { httpGet, writeJson, addDays, ymd, num, parseCsv } from "./lib/util.mjs";

export const AREAS = ["US", "JP", "GB", "XM", "AU", "NZ", "CA", "CH"];

export function buildUrl(since) {
  return `https://stats.bis.org/api/v1/data/WS_CBPOL/D.${AREAS.join("+")}/all?startPeriod=${since}&format=csv`;
}

export function parseBisCsv(text) {
  const rows = parseCsv(text).filter((r) => r.length > 1);
  if (!rows.length) throw new Error("BIS: 空のCSV");
  const head = rows[0].map((h) => h.trim());
  const iA = head.indexOf("REF_AREA"), iT = head.indexOf("TIME_PERIOD"), iV = head.indexOf("OBS_VALUE");
  if (iA < 0 || iT < 0 || iV < 0) throw new Error("BIS: 列名が想定と違います " + head.join(","));
  const by = {};
  for (const r of rows.slice(1)) {
    const area = String(r[iA] || "").split(":")[0].trim();
    const date = String(r[iT] || "").trim();
    const v = num(r[iV]);
    if (!AREAS.includes(area) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || v === null) continue;
    (by[area] ||= []).push([date, v]);
  }
  const areas = {};
  for (const [area, obs] of Object.entries(by)) {
    obs.sort((a, b) => (a[0] < b[0] ? -1 : 1));
    const changes = [];
    for (const [d, v] of obs) if (!changes.length || changes.at(-1)[1] !== v) changes.push([d, v]);
    areas[area] = { last: obs.at(-1), changes };
  }
  return areas;
}

export async function run({ fetch: fetchImpl = fetch, outDir, now = new Date(), log = console.log } = {}) {
  const since = addDays(ymd(now), -365 * 3);
  const text = await httpGet(fetchImpl, buildUrl(since), { timeoutMs: 60000 });
  const areas = parseBisCsv(text);
  const got = Object.keys(areas);
  if (!got.length) throw new Error("BIS: 対象国のデータがありません");
  await writeJson(join(outDir, "policy_bis.json"), {
    updated: now.toISOString(),
    source: "BIS（国際決済銀行）Central bank policy rates。BISによる公式翻訳ではありません。",
    areas
  });
  const lag = got.map((a) => `${a} ${areas[a].last[0].slice(5)}`).join(" / ");
  log(`BIS: ${got.length}地域（最終観測日 ${lag}）`);
  return { ok: true, message: `${got.length}地域`, asOf: got.map((a) => areas[a].last[0]).sort()[0] };
}
