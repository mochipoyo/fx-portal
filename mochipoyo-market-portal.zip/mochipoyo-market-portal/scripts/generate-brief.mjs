// AIマーケットまとめ（Claude API ＋ Web検索）
//   node scripts/generate-brief.mjs --mode daily   … 平日の朝のまとめ
//   node scripts/generate-brief.mjs --mode weekly  … 土曜の週末まとめ
// 必要: 環境変数 ANTHROPIC_API_KEY
// 任意: CLAUDE_MODEL（既定 claude-sonnet-5-5）, WEB_SEARCH_TOOL（既定 web_search_20250305）, BRIEF_MAX_SEARCHES（既定 8）
// 出力: data/brief.json または data/brief_weekly.json、data/briefs/（過去分）、data/meta.json
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { readdir, unlink } from "node:fs/promises";
import { readJson, writeJson, addDays, sleep } from "./lib/util.mjs";
import { zonedToUtc, jst, jaDate } from "./lib/time.mjs";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const API_URL = "https://api.anthropic.com/v1/messages";
export const SECTION_TITLES = {
  policy: "金融政策・中央銀行",
  rates: "金利・債券",
  macro: "経済指標",
  fx: "為替",
  risk: "株式・商品・地政学"
};
const ARCHIVE_KEEP = 40;

// ---------- サイトが持つ検証済みデータを、AIへの参考情報にまとめる ----------
export async function buildContext(dataDir, now = new Date()) {
  const L = [];
  const t = jst(now.getTime());
  L.push(`現在時刻：${jaDate(t.date)} ${t.time}（日本時間）`);
  const last = (arr) => (arr && arr.length ? arr[arr.length - 1] : null);
  const back = (arr, days) => {
    const l = last(arr);
    if (!l) return null;
    const target = addDays(l[0], -days);
    for (let i = arr.length - 1; i >= 0; i--) if (arr[i][0] <= target) return arr[i];
    return null;
  };
  const sgn = (v, d = 2) => (v > 0 ? "+" : v < 0 ? "−" : "±") + Math.abs(v).toFixed(d);

  const r = await readJson(join(dataDir, "us_rates.json"));
  if (r && r.series && r.series.DGS10) {
    const y10 = last(r.series.DGS10), y2 = last(r.series.DGS2), w10 = back(r.series.DGS10, 7);
    L.push(`米国債利回り（${y10[0]}時点、FRB H.15）：2年 ${y2[1].toFixed(2)}%、10年 ${y10[1].toFixed(2)}%` + (w10 ? `（10年は1週間前比 ${sgn(y10[1] - w10[1])}%pt）` : ""));
    L.push(`FF金利の誘導目標：${r.fed.lower.toFixed(2)}〜${r.fed.upper.toFixed(2)}%（${r.fed.date}時点）`);
  }
  const j = await readJson(join(dataDir, "jgb.json"));
  if (j && j.rows && j.rows.length) {
    const lr = last(j.rows), i2 = j.tenors.indexOf("2Y"), i10 = j.tenors.indexOf("10Y");
    L.push(`日本国債利回り（${lr[0]}時点、財務省）：2年 ${lr[1][i2]}%、10年 ${lr[1][i10]}%`);
    if (r && r.series && r.series.DGS10) {
      const m = new Map(r.series.DGS10);
      const us = m.get(lr[0]);
      if (us !== undefined) L.push(`日米10年金利差（${lr[0]}）：${(us - lr[1][i10]).toFixed(2)}%pt`);
    }
  }
  const cb = await readJson(join(dataDir, "manual", "central_banks.json"));
  if (cb) {
    L.push("主要中央銀行の政策金利（公式発表で確認した値）：" + cb.banks.map((b) => `${b.short} ${b.current.display}（${b.current.decided} ${b.current.lastAction}）`).join("、"));
    const until = now.getTime() + 8 * 86400000;
    const ev = [];
    for (const b of cb.banks) for (const m of b.meetings) {
      const at = zonedToUtc(m.date, b.time || "12:00", b.tz);
      if (at >= now.getTime() - 86400000 && at <= until) {
        const x = jst(at);
        ev.push([at, `${jaDate(x.date)}${b.time ? " " + x.time : "（時刻未定）"} ${b.short}・${b.meeting}${m.tag ? "（" + m.tag + "）" : ""}`]);
      }
    }
    ev.sort((a, b) => a[0] - b[0]);
    if (ev.length) L.push("今後8日間の中央銀行の予定（日本時間）：" + ev.map((e) => e[1]).join("、"));
  }
  const today = t.date, end = addDays(today, 8);
  const hol = [];
  const jp = await readJson(join(dataDir, "holidays_jp.json"));
  for (const [d, n] of (jp && jp.days) || []) if (d >= today && d <= end) hol.push(`${jaDate(d)} 日本 ${n}`);
  const uk = await readJson(join(dataDir, "holidays_uk.json"));
  for (const [d, n] of (uk && uk.days) || []) if (d >= today && d <= end) hol.push(`${jaDate(d)} 英国 ${n}`);
  const us = await readJson(join(dataDir, "manual", "holidays_us.json"));
  for (const [d, , n, note] of (us && us.days) || []) if (d >= today && d <= end) hol.push(`${jaDate(d)} 米国 ${n}（${note}）`);
  if (hol.length) L.push("今後8日間の休場・祝日：" + hol.join("、"));
  const c = await readJson(join(dataDir, "cot.json"));
  if (c && c.currencies) {
    const pick = c.currencies.filter((x) => ["JPY", "GBP"].includes(x.ccy) && x.rows.length > 1).map((x) => {
      const a = x.rows[x.rows.length - 1], b = x.rows[x.rows.length - 2];
      const net = a[2] - a[3], prev = b[2] - b[3];
      return `${x.name} ${net >= 0 ? "買い越し" : "売り越し"} ${Math.abs(net).toLocaleString("en-US")}枚（前週比 ${net - prev >= 0 ? "+" : "−"}${Math.abs(net - prev).toLocaleString("en-US")}）`;
    });
    if (pick.length) L.push(`CFTC 投機筋（非商業部門）の通貨先物ポジション（${c.latest}時点）：${pick.join("、")}`);
  }
  return L.join("\n");
}

// ---------- 指示文 ----------
const SYSTEM = `あなたは、FX（外国為替）トレーダー向け会員制ポータルサイトの「マーケットまとめ」を作る編集者です。
読者は日本の個人トレーダー（初心者〜上級者）で、ポンド円（GBP/JPY）を中心に取引しています。

# 必ず守ること
- web_search で確認できた事実だけを書く。数値・日付・時刻・発言者は、検索結果の出典で確認できたものに限る。確認できないことは書かない。
- 売買の推奨、価格の予想・目標値、「買い」「売り」「チャンス」など取引を勧める表現は書かない。市場の見方を紹介する場合は「〜との見方が出ている」のように、出典のある第三者の見方として書く。
- 記事の文章を写さず、短い自分の言葉で要約する。長い引用はしない。
- 時刻は日本時間（JST）で「21:30」のように、日付は「10月5日（月）」のように書く。
- 専門用語には初心者向けの短い補足を付ける（例：「CPI（消費者物価指数）」）。
- 出典URLは、検索結果に実際に出てきたURLだけを使い、各項目に1〜3件付ける。
- 「参考データ」として渡す数値（公的機関から取得済み）と矛盾することは書かない。
- 出力は指定されたJSONだけ。前後に説明文やコードブロック記号を付けない。`;

const SRC = '"sources": [{"title": "記事・発表の名前", "url": "https://..."}]';
const SCHEMA_DAILY = `{
  "headline": "きょうの相場を一言で（40字以内）",
  "summary": ["要点1（70字以内）", "要点2", "要点3"],
  "gbpjpy": {"text": "ポンド円に関係する材料（英国・日本の材料を中心に、200字以内）", ${SRC}},
  "sections": [
    {"id": "policy", "items": [{"title": "見出し（30字以内）", "body": "本文（150字以内）", ${SRC}}]},
    {"id": "rates", "items": []},
    {"id": "macro", "items": []},
    {"id": "fx", "items": []},
    {"id": "risk", "items": []}
  ],
  "watch": [{"when": "21:30", "label": "きょうの注目予定（30字以内）", "note": "補足（50字以内、なければ空）", ${SRC}}],
  "caution": "読む人への注意点（100字以内。なければ空文字）"
}`;
const SCHEMA_WEEKLY = `{
  "headline": "先週の相場を一言で（40字以内）",
  "summary": ["要点1（70字以内）", "要点2", "要点3"],
  "review": [{"title": "先週の出来事（30字以内）", "body": "本文（150字以内）", ${SRC}}],
  "gbpjpy": {"text": "ポンド円の1週間（材料中心、200字以内）", ${SRC}},
  "next_week": [{"when": "10月7日（水）21:30", "label": "来週の注目予定（30字以内）", "note": "補足（50字以内、なければ空）", ${SRC}}],
  "caution": "読む人への注意点（100字以内。なければ空文字）"
}`;

export function buildUserPrompt(mode, context, now, maxSearches) {
  const t = jst(now.getTime());
  if (mode === "weekly") {
    const from = addDays(t.date, -6);
    return `# 作業
先週（${jaDate(from)}〜${jaDate(t.date)}）の外国為替市場を振り返り、来週の注目予定をまとめてください。
検索は${maxSearches}回以内。主要通信社・経済メディア、各国中央銀行・統計機関の公式発表を優先してください。
- review は3〜6件。ポンド・円・ドルに関係が深いものを優先。
- next_week は検索で日時を確認できた予定だけ（最大8件）。日本時間に直して書く。確認できなければ入れない。

# 参考データ（このサイトが公的機関から取得済み）
${context}

# 出力するJSONの形
${SCHEMA_WEEKLY}`;
  }
  return `# 作業
きょう（${jaDate(t.date)}）の朝に読む、外国為替市場のまとめを作ってください。
対象は、前営業日の東京時間から、けさ日本時間6時ごろまでの出来事と、きょうの予定です。
検索は${maxSearches}回以内。主要通信社・経済メディア、各国中央銀行・統計機関の公式発表を優先してください。
- sections の各 items は0〜3件。その分野で確認できた重要な出来事がなければ空配列にする。
- gbpjpy は英国と日本の材料（中銀・指標・要人発言・政治）を中心に。
- watch は、きょう〜あすの朝までの予定のうち、検索で日時を確認できたものだけ（最大6件）。日本時間に直して書く。

# 参考データ（このサイトが公的機関から取得済み）
${context}

# 出力するJSONの形
${SCHEMA_DAILY}`;
}

// ---------- Claude API ----------
async function post(fetchImpl, apiKey, body, { retries = 3 } = {}) {
  let lastErr;
  for (let i = 0; i <= retries; i++) {
    try {
      const res = await fetchImpl(API_URL, {
        method: "POST",
        headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify(body)
      });
      const text = await res.text();
      if (res.ok) return JSON.parse(text);
      const err = new Error(`Claude API ${res.status}: ${text.slice(0, 300)}`);
      if (![429, 500, 502, 503, 504, 529].includes(res.status)) throw Object.assign(err, { fatal: true });
      lastErr = err;
      const ra = Number(res.headers && res.headers.get && res.headers.get("retry-after"));
      await sleep(Number.isFinite(ra) && ra > 0 ? Math.min(ra, 60) * 1000 : 5000 * (i + 1));
    } catch (e) {
      if (e.fatal) throw e;
      lastErr = e;
      await sleep(3000 * (i + 1));
    }
  }
  throw lastErr;
}

// 検索つきで呼び出す。長い検索で一時停止（pause_turn）したら続きを依頼する。
export async function askWithSearch({ fetch: fetchImpl, apiKey, model, tool, maxSearches, system, user, maxTokens = 8000 }) {
  const messages = [{ role: "user", content: user }];
  const texts = [];
  const results = [];
  let searches = 0;
  const usage = { input_tokens: 0, output_tokens: 0 };
  for (let turn = 0; turn < 6; turn++) {
    const res = await post(fetchImpl, apiKey, {
      model,
      max_tokens: maxTokens,
      system,
      messages,
      tools: [{ type: tool, name: "web_search", max_uses: maxSearches, user_location: { type: "approximate", city: "Tokyo", region: "Tokyo", country: "JP", timezone: "Asia/Tokyo" } }]
    });
    for (const b of res.content || []) {
      if (b.type === "text") {
        texts.push(b.text || "");
        for (const c of b.citations || []) if (c.url) results.push({ url: c.url, title: c.title || "" });
      } else if (b.type === "server_tool_use") searches++;
      else if (b.type === "web_search_tool_result" && Array.isArray(b.content)) {
        for (const r of b.content) if (r.type === "web_search_result" && r.url) results.push({ url: r.url, title: r.title || "" });
      }
    }
    if (res.usage) { usage.input_tokens += res.usage.input_tokens || 0; usage.output_tokens += res.usage.output_tokens || 0; }
    if (res.stop_reason === "pause_turn") {
      messages.push({ role: "assistant", content: res.content });
      continue;
    }
    if (res.stop_reason === "max_tokens") throw new Error("出力が長すぎて途中で切れました（max_tokens）");
    return { text: texts.join(""), results, searches, usage };
  }
  throw new Error("検索の継続回数が上限に達しました");
}

// ---------- 出力の検査 ----------
export function extractJson(text) {
  const s = String(text || "").replace(/```(?:json)?/gi, "");
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a < 0 || b <= a) throw new Error("JSONが見つかりません");
  return JSON.parse(s.slice(a, b + 1));
}

export function normUrl(u) {
  try {
    const x = new URL(u);
    if (!/^https?:$/.test(x.protocol)) return null;
    x.hash = "";
    return (x.host.toLowerCase().replace(/^www\./, "") + x.pathname.replace(/\/+$/, "") + x.search);
  } catch { return null; }
}

const clip = (s, n) => {
  s = String(s || "").replace(/\s+/g, " ").trim();
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
};

// 検索結果に実在したURLだけを残し、出典のない項目は落とす
export function cleanBrief(raw, mode, results) {
  const allowed = new Map();
  for (const r of results) { const k = normUrl(r.url); if (k && !allowed.has(k)) allowed.set(k, r); }
  let dropped = 0;
  const srcs = (list) => {
    const out = [];
    for (const s of Array.isArray(list) ? list : []) {
      const k = s && normUrl(s.url);
      if (!k || !allowed.has(k) || out.some((o) => normUrl(o.url) === k)) continue;
      out.push({ title: clip(s.title || allowed.get(k).title || allowed.get(k).url, 80), url: s.url });
      if (out.length >= 3) break;
    }
    return out;
  };
  const items = (list, max, withWhen) => {
    const out = [];
    for (const it of Array.isArray(list) ? list : []) {
      const sources = srcs(it && it.sources);
      if (!sources.length) { dropped++; continue; }
      const o = withWhen
        ? { when: clip(it.when, 24), label: clip(it.label, 40), note: clip(it.note, 70), sources }
        : { title: clip(it.title, 40), body: clip(it.body, 200), sources };
      if (withWhen ? !o.label : !o.title || !o.body) { dropped++; continue; }
      out.push(o);
      if (out.length >= max) break;
    }
    return out;
  };
  const summary = (Array.isArray(raw.summary) ? raw.summary : []).map((s) => clip(s, 90)).filter(Boolean).slice(0, 3);
  const g = raw.gbpjpy || {};
  const gSources = srcs(g.sources);
  const out = {
    headline: clip(raw.headline, 60),
    summary,
    gbpjpy: gSources.length && g.text ? { text: clip(g.text, 260), sources: gSources } : null,
    caution: clip(raw.caution, 140)
  };
  if (mode === "weekly") {
    out.review = items(raw.review, 6, false);
    out.next_week = items(raw.next_week, 8, true);
  } else {
    const secs = Array.isArray(raw.sections) ? raw.sections : [];
    out.sections = Object.keys(SECTION_TITLES).map((id) => {
      const s = secs.find((x) => x && x.id === id) || {};
      return { id, title: SECTION_TITLES[id], items: items(s.items, 3, false) };
    });
    out.watch = items(raw.watch, 6, true);
  }
  const count = mode === "weekly" ? out.review.length : out.sections.reduce((n, s) => n + s.items.length, 0);
  if (!out.headline || out.summary.length < 2 || count < 2) {
    throw new Error(`内容が不足しています（見出し:${!!out.headline} 要点:${out.summary.length} 項目:${count} 出典なしで除外:${dropped}）`);
  }
  out.dropped = dropped;
  return out;
}

// ---------- 保存（最新・過去分・一覧） ----------
async function saveArchive(dataDir, brief) {
  const dir = join(dataDir, "briefs");
  const file = `${brief.date}-${brief.mode}.json`;
  await writeJson(join(dir, file), brief);
  const idx = (await readJson(join(dir, "index.json"), null)) || { items: [] };
  const items = [{ date: brief.date, mode: brief.mode, file, headline: brief.headline, generated_at: brief.generated_at },
    ...idx.items.filter((x) => x.file !== file)].slice(0, ARCHIVE_KEEP);
  await writeJson(join(dir, "index.json"), { items });
  const keep = new Set(items.map((x) => x.file).concat("index.json"));
  for (const f of await readdir(dir)) if (f.endsWith(".json") && !keep.has(f)) await unlink(join(dir, f));
}

async function setMeta(dataDir, key, entry) {
  const p = join(dataDir, "meta.json");
  const meta = (await readJson(p, null)) || { sources: {} };
  meta.sources ||= {};
  const prev = meta.sources[key] || {};
  meta.sources[key] = entry.status === "ok" ? entry : { ...prev, ...entry };
  meta.updated = new Date().toISOString();
  await writeJson(p, meta);
}

export async function run({ mode = "daily", fetch: fetchImpl = fetch, dataDir = join(ROOT, "site", "data"), env = process.env, now = new Date(), log = console.log } = {}) {
  const key = `brief_${mode}`;
  const apiKey = env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    await setMeta(dataDir, key, { status: "skipped", message: "ANTHROPIC_API_KEY が未設定", checkedAt: new Date().toISOString() });
    return { ok: false, skipped: true };
  }
  const model = env.CLAUDE_MODEL || "claude-sonnet-5-5";
  const tool = env.WEB_SEARCH_TOOL || "web_search_20250305";
  const maxSearches = Math.max(1, Math.min(20, Number(env.BRIEF_MAX_SEARCHES || 8)));
  try {
    const context = await buildContext(dataDir, now);
    const user = buildUserPrompt(mode, context, now, maxSearches);
    const res = await askWithSearch({ fetch: fetchImpl, apiKey, model, tool, maxSearches, system: SYSTEM, user });
    let raw;
    try {
      raw = extractJson(res.text);
    } catch (e) {
      log(`JSONの読み取りに失敗したため、整形だけを再依頼します: ${e.message}`);
      const fix = await post(fetchImpl, apiKey, {
        model, max_tokens: 8000,
        system: "入力されたテキストを、内容を変えずに正しいJSONだけに直して出力してください。説明文は書かないでください。",
        messages: [{ role: "user", content: res.text }]
      });
      raw = extractJson((fix.content || []).filter((b) => b.type === "text").map((b) => b.text).join(""));
    }
    const clean = cleanBrief(raw, mode, res.results);
    const t = jst(now.getTime());
    const brief = {
      mode, date: t.date, generated_at: new Date().toISOString(), model,
      searches: res.searches, ...clean,
      notice: "AI（Claude）がWeb上の公開情報を検索して自動で要約したものです。誤りを含む可能性があります。重要な数値や日時は出典でご確認ください。投資判断はご自身の責任でお願いします。"
    };
    await writeJson(join(dataDir, mode === "weekly" ? "brief_weekly.json" : "brief.json"), brief);
    await saveArchive(dataDir, brief);
    await setMeta(dataDir, key, { status: "ok", message: `検索${res.searches}回・出典なし除外${clean.dropped}件・入力${res.usage.input_tokens}/出力${res.usage.output_tokens}トークン`, asOf: brief.date, checkedAt: brief.generated_at, lastSuccess: brief.generated_at });
    log(`まとめ（${mode}）: ${brief.headline}`);
    return { ok: true, brief };
  } catch (e) {
    await setMeta(dataDir, key, { status: "error", message: String(e.message || e).slice(0, 300), checkedAt: new Date().toISOString() });
    log(`まとめ（${mode}）の作成に失敗: ${e.message}`);
    return { ok: false, error: e };
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const i = process.argv.indexOf("--mode");
  const mode = i > 0 ? process.argv[i + 1] : "daily";
  if (!["daily", "weekly"].includes(mode)) { console.error("--mode は daily か weekly"); process.exit(2); }
  const r = await run({ mode });
  if (!r.ok && !r.skipped) process.exitCode = 1; // 失敗はActions上で分かるように（前回分は残ります）
}
