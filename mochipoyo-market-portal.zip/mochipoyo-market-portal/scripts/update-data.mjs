// すべての公的データを取得して site/data/ に保存し、取得結果を data/meta.json に記録する
//   使い方: node scripts/update-data.mjs            … 全部
//           node scripts/update-data.mjs --only jgb,cot
// どれかが失敗しても他は続行し、前回のファイルは残します（終了コードは常に0）。
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { readJson, writeJson } from "./lib/util.mjs";
import * as fred from "./fetch-fred.mjs";
import * as jgb from "./fetch-jgb.mjs";
import * as cot from "./fetch-cot.mjs";
import * as policy from "./fetch-policy.mjs";
import * as holidays from "./fetch-holidays.mjs";
import * as jwks from "./fetch-jwks.mjs";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
export const TASKS = { fred, jgb, cot, policy, holidays, jwks };

export async function updateAll({ outDir = join(ROOT, "site", "data"), only = null, fetch: fetchImpl = fetch, now = new Date(), env = process.env, log = console.log } = {}) {
  const metaPath = join(outDir, "meta.json");
  const meta = (await readJson(metaPath, null)) || { sources: {} };
  meta.sources ||= {};
  for (const [name, mod] of Object.entries(TASKS)) {
    if (only && !only.includes(name)) continue;
    const prev = meta.sources[name] || {};
    const at = new Date().toISOString();
    try {
      const r = await mod.run({ fetch: fetchImpl, outDir, now, env, log });
      if (r.skipped) {
        meta.sources[name] = { ...prev, status: "skipped", message: r.message, checkedAt: at };
        log(`- ${name}: スキップ（${r.message}）`);
      } else {
        meta.sources[name] = { status: r.ok ? "ok" : "partial", message: r.message, asOf: r.asOf || null, checkedAt: at, lastSuccess: at };
      }
    } catch (e) {
      meta.sources[name] = { ...prev, status: "error", message: String(e.message || e).slice(0, 300), checkedAt: at };
      log(`! ${name}: 失敗 ${e.message}`);
    }
  }
  meta.updated = new Date().toISOString();
  await writeJson(metaPath, meta);
  return meta;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const i = process.argv.indexOf("--only");
  const only = i > 0 ? process.argv[i + 1].split(",") : null;
  const meta = await updateAll({ only });
  const bad = Object.entries(meta.sources).filter(([, v]) => v.status === "error").map(([k]) => k);
  console.log(bad.length ? `完了（失敗: ${bad.join(", ")}）` : "完了");
}
