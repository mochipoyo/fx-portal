/*
 * app.js — もちぽよ マーケットポータル 本体
 * 構成: 小道具 → 時刻計算 → データ読み込み → TradingView → タブ → 各タブの表示 → 起動
 */
(function () {
  "use strict";
  var CFG = window.PORTAL_CONFIG || {};
  var DAY = 86400000, HOUR = 3600000, MIN = 60000;
  var DOW = ["日", "月", "火", "水", "木", "金", "土"];

  // ============================== 小道具 ==============================
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s === undefined || s === null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };
  function safeUrl(u) { return /^https?:\/\//i.test(String(u || "")) ? String(u) : "#"; }
  function fmtNum(v, d) { return Number(v).toLocaleString("ja-JP", { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }); }
  function signed(v, d, unit) { return (v > 0 ? "+" : v < 0 ? "−" : "±") + fmtNum(Math.abs(v), d) + (unit || ""); }
  function pct(v, d) { return Number(v).toFixed(d === undefined ? 2 : d) + "%"; }

  // ============================== 時刻 ==============================
  var fmtCache = {};
  function partsIn(ms, tz) {
    var f = fmtCache[tz];
    if (!f) {
      f = fmtCache[tz] = new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
    }
    var p = {};
    f.formatToParts(new Date(ms)).forEach(function (x) { p[x.type] = x.value; });
    return { y: +p.year, m: +p.month, d: +p.day, h: (+p.hour) % 24, mi: +p.minute, s: +p.second };
  }
  function tzOffsetMin(ms, tz) {
    var p = partsIn(ms, tz);
    return Math.round((Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi, p.s) - Math.floor(ms / 1000) * 1000) / MIN);
  }
  function zonedToUtc(dateStr, timeStr, tz) {
    var a = dateStr.split("-").map(Number), b = (timeStr || "00:00").split(":").map(Number);
    var guess = Date.UTC(a[0], a[1] - 1, a[2], b[0], b[1]);
    var o1 = tzOffsetMin(guess, tz);
    var t = guess - o1 * MIN;
    var o2 = tzOffsetMin(t, tz);
    if (o2 !== o1) t = guess - o2 * MIN;
    return t;
  }
  function localDate(ms, tz) { var p = partsIn(ms, tz); return p.y + "-" + pad2(p.m) + "-" + pad2(p.d); }
  function jstDate(ms) { return new Date(ms + 9 * HOUR).toISOString().slice(0, 10); }
  function jstTime(ms) { return new Date(ms + 9 * HOUR).toISOString().slice(11, 16); }
  function dowOf(dateStr) { var a = dateStr.split("-").map(Number); return new Date(Date.UTC(a[0], a[1] - 1, a[2])).getUTCDay(); }
  function addDays(dateStr, n) { var a = dateStr.split("-").map(Number); return new Date(Date.UTC(a[0], a[1] - 1, a[2]) + n * DAY).toISOString().slice(0, 10); }
  function jaDate(dateStr) { var a = dateStr.split("-").map(Number); return a[1] + "月" + a[2] + "日（" + DOW[dowOf(dateStr)] + "）"; }
  function jaMD(dateStr) { var a = dateStr.split("-").map(Number); return a[1] + "/" + a[2] + "（" + DOW[dowOf(dateStr)] + "）"; }
  function toMs(dateStr) { return Date.parse(dateStr + "T00:00:00Z"); }
  function jstMidnight(dateStr) { return toMs(dateStr) - 9 * HOUR; }
  function fmtLeft(ms) {
    if (ms < MIN) return "まもなく";
    var m = Math.round(ms / MIN);
    if (m < 60) return "あと" + m + "分";
    var hh = Math.floor(m / 60), mm = m % 60;
    if (hh < 48) return "あと" + hh + "時間" + (mm ? mm + "分" : "");
    return "あと" + Math.floor(hh / 24) + "日";
  }
  function dayWord(dateStr, today) {
    if (dateStr === today) return "きょう";
    if (dateStr === addDays(today, 1)) return "あす";
    if (dateStr === addDays(today, -1)) return "きのう";
    return jaMD(dateStr);
  }
  function jstStamp(iso) {
    if (!iso) return "";
    var ms = Date.parse(iso);
    if (!isFinite(ms)) return "";
    var d = jstDate(ms).split("-").map(Number);
    return d[1] + "/" + d[2] + " " + jstTime(ms);
  }

  // ============================== データ ==============================
  var cache = {};
  function loadJson(name, fresh) {
    if (!fresh && cache[name]) return cache[name];
    var bust = Math.floor(Date.now() / (10 * MIN));
    var p = fetch("data/" + name + "?v=" + bust, { cache: "no-cache" }).then(function (r) {
      if (!r.ok) throw new Error(name + " " + r.status);
      return r.json();
    }).catch(function () { return null; });
    cache[name] = p;
    return p;
  }
  var D = {}; // 読み込み済みの共通データ

  // 祝日の表
  var CAL = { jp: {}, uk: {}, us: {}, ready: false };
  function buildCalendar() {
    CAL.jp = {}; CAL.uk = {}; CAL.us = {};
    ((D.hjp && D.hjp.days) || []).forEach(function (r) { CAL.jp[r[0]] = r[1]; });
    ((D.hjpx && D.hjpx.days) || []).forEach(function (r) { if (!CAL.jp[r[0]]) CAL.jp[r[0]] = r[1]; });
    ((D.huk && D.huk.days) || []).forEach(function (r) { CAL.uk[r[0]] = r[1]; });
    ((D.hus && D.hus.days) || []).forEach(function (r) { CAL.us[r[0]] = { type: r[1], name: r[2], note: r[3] }; });
    CAL.ready = true;
  }
  function isWeekday(dateStr) { var w = dowOf(dateStr); return w !== 0 && w !== 6; }
  function tokyoBiz(dateStr) { return isWeekday(dateStr) && !CAL.jp[dateStr]; }

  // 五十日（ゴトー日）：5・10・15・20・25日と月末。土日祝なら前の営業日にずれる
  function gotobi(dateStr) {
    if (!tokyoBiz(dateStr)) return null;
    var a = dateStr.split("-").map(Number);
    var last = new Date(Date.UTC(a[0], a[1], 0)).getUTCDate();
    var targets = [5, 10, 15, 20, 25, last];
    for (var i = 0; i < targets.length; i++) {
      var t = a[0] + "-" + pad2(a[1]) + "-" + pad2(targets[i]);
      var guard = 0;
      while (!tokyoBiz(t) && guard++ < 10) t = addDays(t, -1);
      if (t === dateStr) return targets[i] === last ? "月末の五十日" : "五十日";
    }
    return null;
  }

  // ============================== TradingView ==============================
  var tvList = [];
  function theme() {
    var t = document.documentElement.getAttribute("data-theme");
    if (t) return t;
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  function tvMount(el, file, cfgFn, noCredit) {
    var rec = tvList.filter(function (x) { return x.el === el; })[0];
    if (!rec) { rec = { el: el }; tvList.push(rec); }
    rec.file = file; rec.cfgFn = cfgFn; rec.noCredit = noCredit;
    el.innerHTML = "";
    if (window.PORTAL_NO_TV) {
      // 外部スクリプトを読み込めないプレビュー環境では、枠と説明だけを表示する
      var cfg = cfgFn(theme());
      var label = TV_NAMES[file] || "ウィジェット";
      var sym = el.getAttribute("aria-label") || cfg.symbol || "";
      el.innerHTML = file === "ticker-tape"
        ? '<div class="tv-placeholder"><span><b>レートのティッカー（公開したサイトで表示）</b></span></div>'
        : '<div class="tv-placeholder"><span><b>' + esc(label + (sym ? "：" + sym : "")) + "</b>公開したサイトでは、ここにTradingViewのウィジェットが表示されます</span></div>";
      return;
    }
    var wrap = document.createElement("div");
    wrap.className = "tradingview-widget-container";
    wrap.style.cssText = "width:100%;height:100%";
    var inner = document.createElement("div");
    inner.className = "tradingview-widget-container__widget";
    inner.style.cssText = "width:100%;height:100%";
    wrap.appendChild(inner);
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.async = true;
    s.src = "https://s3.tradingview.com/external-embedding/embed-widget-" + file + ".js";
    s.innerHTML = JSON.stringify(cfgFn(theme()));
    var failed = false;
    function fail() {
      if (failed || wrap.querySelector("iframe")) return;
      failed = true;
      var f = document.createElement("div");
      f.className = "tv-fallback";
      f.textContent = "TradingViewのウィジェットを読み込めませんでした。通信状況や、広告・トラッキングをブロックする機能の設定をご確認ください。";
      el.appendChild(f);
    }
    s.onerror = fail;
    wrap.appendChild(s);
    el.appendChild(wrap);
    setTimeout(fail, 15000);
    if (!noCredit && (!el.nextElementSibling || !el.nextElementSibling.classList.contains("tv-credit"))) {
      var c = document.createElement("div");
      c.className = "tv-credit fine";
      c.innerHTML = '提供：<a href="https://jp.tradingview.com/" target="_blank" rel="noopener nofollow">TradingView</a>';
      el.insertAdjacentElement("afterend", c);
    }
  }
  var TV_NAMES = { "ticker-tape": "レートのティッカー", "advanced-chart": "チャート", "mini-symbol-overview": "ミニチャート", "market-overview": "銘柄の一覧", "forex-heat-map": "通貨ヒートマップ", "forex-cross-rates": "クロスレート", events: "経済指標カレンダー", timeline: "為替ニュース" };
  function tvRemountAll() { tvList.forEach(function (r) { if (r.el.isConnected) tvMount(r.el, r.file, r.cfgFn, r.noCredit); }); }
  var lazyIO = "IntersectionObserver" in window ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      lazyIO.unobserve(en.target);
      var fn = en.target.__lazy;
      en.target.__lazy = null;
      if (fn) fn();
    });
  }, { rootMargin: "300px" }) : null;
  function whenVisible(el, fn) {
    if (!lazyIO) return fn();
    el.__lazy = fn;
    lazyIO.observe(el);
  }

  var TV = {
    overview: function (t) {
      return { colorTheme: t, dateRange: "1D", showChart: true, locale: "ja", isTransparent: true, width: "100%", height: "100%", showSymbolLogo: false, showFloatingTooltip: true,
        tabs: [
          { title: "円クロス", symbols: [{ s: "FX:GBPJPY", d: "ポンド円" }, { s: "FX:USDJPY", d: "ドル円" }, { s: "FX:EURJPY", d: "ユーロ円" }, { s: "FX:AUDJPY", d: "豪ドル円" }] },
          { title: "ドルストレート", symbols: [{ s: "FX:GBPUSD", d: "ポンドドル" }, { s: "FX:EURUSD", d: "ユーロドル" }, { s: "FX:AUDUSD", d: "豪ドル米ドル" }, { s: "FX:USDCHF", d: "ドルスイスフラン" }] },
          { title: "金利・ドル指数", symbols: [{ s: "TVC:DXY", d: "ドル指数" }, { s: "TVC:US10Y", d: "米10年債利回り" }, { s: "TVC:JP10Y", d: "日本10年債利回り" }, { s: "OANDA:XAUUSD", d: "金" }] }
        ] };
    },
    heatmap: function (t) { return { width: "100%", height: "100%", currencies: ["EUR", "USD", "JPY", "GBP", "CHF", "AUD", "CAD", "NZD"], isTransparent: true, colorTheme: t, locale: "ja" }; },
    cross: function (t) { return { width: "100%", height: "100%", currencies: ["EUR", "USD", "JPY", "GBP", "CHF", "AUD", "CAD", "NZD"], isTransparent: true, colorTheme: t, locale: "ja" }; },
    yields: function (t) {
      return { colorTheme: t, dateRange: "12M", showChart: true, locale: "ja", isTransparent: true, width: "100%", height: "100%", showSymbolLogo: false,
        tabs: [{ title: "10年債利回り", symbols: (CFG.yieldSymbols || []).map(function (x) { return { s: x[0], d: x[1] }; }) }] };
    },
    calendar: function (t) { return { colorTheme: t, isTransparent: true, width: "100%", height: "100%", locale: "ja", importanceFilter: "0,1", countryFilter: CFG.calendarCountries || "us,jp,gb,eu" }; },
    news: function (t) { return { feedMode: "market", market: "forex", isTransparent: true, displayMode: "regular", width: "100%", height: "100%", colorTheme: t, locale: "ja" }; }
  };
  function mountTvBoxes(root) {
    $$("[data-tv]", root).forEach(function (el) {
      if (el.__tvInit) return;
      el.__tvInit = true;
      var key = el.getAttribute("data-tv");
      whenVisible(el, function () { tvMount(el, key === "overview" || key === "yields" ? "market-overview" : key === "heatmap" ? "forex-heat-map" : key === "cross" ? "forex-cross-rates" : key === "calendar" ? "events" : "timeline", TV[key]); });
    });
  }

  // ============================== タブ ==============================
  var TABS = ["home", "chart", "strength", "rates", "macro", "news", "hours"];
  var inited = {};
  var INIT = {};
  function showTab(id, focusPanel) {
    if (TABS.indexOf(id) < 0) id = "home";
    TABS.forEach(function (t) {
      var on = t === id;
      var b = $("#tab-" + t), p = $("#pane-" + t);
      b.setAttribute("aria-selected", on ? "true" : "false");
      b.tabIndex = on ? 0 : -1;
      p.hidden = !on;
    });
    store.set("mp_tab", id);
    if (!inited[id]) { inited[id] = true; try { INIT[id](); } catch (e) { console.error(e); } }
    mountTvBoxes($("#pane-" + id));
    var b = $("#tab-" + id);
    if (b.scrollIntoView) b.scrollIntoView({ block: "nearest", inline: "nearest" });
    if (focusPanel) {
      var el = $('[data-panel="' + focusPanel + '"]');
      if (el) setTimeout(function () { el.scrollIntoView({ behavior: "smooth", block: "start" }); }, 60);
    } else {
      var tabs = $(".tabs");
      if (window.scrollY > tabs.offsetTop) window.scrollTo({ top: tabs.offsetTop });
    }
  }
  function initTabs() {
    $$('[role="tab"]').forEach(function (b) {
      b.addEventListener("click", function () {
        var id = b.getAttribute("data-tab");
        if (location.hash !== "#" + id) history.replaceState(null, "", "#" + id);
        showTab(id);
      });
    });
    $(".tabs-inner").addEventListener("keydown", function (ev) {
      var i = TABS.indexOf(store.get("mp_tab", "home"));
      if (ev.key === "ArrowRight") i = (i + 1) % TABS.length;
      else if (ev.key === "ArrowLeft") i = (i - 1 + TABS.length) % TABS.length;
      else return;
      ev.preventDefault();
      history.replaceState(null, "", "#" + TABS[i]);
      showTab(TABS[i]);
      $("#tab-" + TABS[i]).focus();
    });
    var ti = $(".tabs-inner");
    var edge = function () { ti.classList.toggle("more", ti.scrollWidth - ti.clientWidth - ti.scrollLeft > 8); };
    ti.addEventListener("scroll", edge, { passive: true });
    window.addEventListener("resize", edge);
    setTimeout(edge, 0);
    window.addEventListener("hashchange", function () {
      var parts = location.hash.replace("#", "").split("/");
      if (TABS.indexOf(parts[0]) >= 0) showTab(parts[0], parts[1]);
    });
    $$('a[href^="#"]').forEach(function (a) {
      var id = a.getAttribute("href").slice(1).split("/")[0];
      if (TABS.indexOf(id) >= 0) a.addEventListener("click", function (ev) { ev.preventDefault(); history.replaceState(null, "", "#" + id); showTab(id); });
    });
  }

  // ============================== 相場時計 ==============================
  var SESSIONS = [
    { id: "syd", name: "シドニー", tz: "Australia/Sydney", open: "08:00", close: "17:00", cls: "band-syd", hol: null },
    { id: "tky", name: "東京", tz: "Asia/Tokyo", open: "09:00", close: "15:00", cls: "band-tky", hol: "jp" },
    { id: "ldn", name: "ロンドン", tz: "Europe/London", open: "08:00", close: "17:00", cls: "band-ldn", hol: "uk" },
    { id: "ny", name: "NY", tz: "America/New_York", open: "08:00", close: "17:00", cls: "band-ny", hol: "us" }
  ];
  function isHoliday(kind, dateStr) {
    if (kind === "jp") return CAL.jp[dateStr] || null;
    if (kind === "uk") return CAL.uk[dateStr] || null;
    if (kind === "us") { var u = CAL.us[dateStr]; return u && u.type !== "early" ? u.name : null; }
    return null;
  }
  function sessionInstances(s, from, to) {
    var out = [];
    var d0 = addDays(localDate(from, s.tz), -1), d1 = addDays(localDate(to, s.tz), 1);
    for (var d = d0; d <= d1; d = addDays(d, 1)) {
      if (!isWeekday(d)) continue;
      var a = zonedToUtc(d, s.open, s.tz), b = zonedToUtc(d, s.close, s.tz);
      if (b <= from || a >= to) continue;
      out.push({ start: a, end: b, date: d, holiday: isHoliday(s.hol, d) });
    }
    return out;
  }
  // 為替の週の区切り（一般的な目安：米東部 日曜17時〜金曜17時）
  function weekClosed(ms) {
    var p = partsIn(ms, "America/New_York");
    var w = new Date(Date.UTC(p.y, p.m - 1, p.d)).getUTCDay();
    var hm = p.h * 60 + p.mi;
    return (w === 5 && hm >= 17 * 60) || w === 6 || (w === 0 && hm < 17 * 60);
  }
  function nextWeekOpen(ms) {
    var d = localDate(ms, "America/New_York");
    for (var i = 0; i < 8; i++) {
      var dd = addDays(d, i);
      if (dowOf(dd) === 0) { var t = zonedToUtc(dd, "17:00", "America/New_York"); if (t > ms) return t; }
    }
    return null;
  }

  // 指定期間のイベント一覧（定時・市場・中銀・休場・夏時間・CFTC）
  function collectEvents(from, to) {
    var ev = [];
    function add(at, label, kind, sub, short) { if (at >= from && at < to) ev.push({ at: at, label: label, kind: kind, sub: sub || "", short: short || "" }); }
    // 東京：取引開始・仲値
    for (var d = addDays(jstDate(from), -1); d <= addDays(jstDate(to), 1); d = addDays(d, 1)) {
      if (tokyoBiz(d)) {
        add(zonedToUtc(d, "09:00", "Asia/Tokyo"), "東京市場の取引時間（目安）開始", "session");
        var g = gotobi(d);
        add(zonedToUtc(d, "09:55", "Asia/Tokyo"), "東京仲値の公示", "fix", g ? "きょうは" + g + "（仲値に向けたドルの売買が増えやすいと言われる日）" : "", "仲値");
      }
    }
    // ロンドン・NY・シドニー
    [["Europe/London", "ldn"], ["America/New_York", "ny"], ["Australia/Sydney", "syd"]].forEach(function (z) {
      for (var d2 = addDays(localDate(from, z[0]), -1); d2 <= addDays(localDate(to, z[0]), 1); d2 = addDays(d2, 1)) {
        if (!isWeekday(d2)) continue;
        if (z[1] === "ldn") {
          var hu = CAL.uk[d2];
          add(zonedToUtc(d2, "08:00", z[0]), "ロンドン市場の取引時間（目安）開始", "session", hu ? "英国は祝日（" + hu + "）" : "");
          add(zonedToUtc(d2, "16:00", z[0]), "ロンドン・フィックス（WM/ロイター）", "fix", "ロンドン16時の基準レート算出", "ロンドンFix");
        } else if (z[1] === "ny") {
          var huu = CAL.us[d2];
          add(zonedToUtc(d2, "08:00", z[0]), "NY市場の取引時間（目安）開始", "session", huu ? "米国：" + huu.name + "（" + huu.note + "）" : "");
          add(zonedToUtc(d2, "10:00", z[0]), "NYカット（通貨オプションの期限）", "fix", "NY時間10時", "NYカット");
          if (dowOf(d2) === 5) add(zonedToUtc(d2, "17:00", z[0]), "週末クローズ（目安）", "week", "NY時間 金曜17時。取引終了時刻は取引会社によって異なります", "週末");
          else add(zonedToUtc(d2, "17:00", z[0]), "NYクローズ（日付の変わり目）", "fix", "NY時間17時。スワップポイントが付く区切り", "NYクローズ");
        } else if (dowOf(d2) === 1) {
          add(zonedToUtc(d2, "08:00", z[0]), "シドニー市場の取引時間（目安）開始", "session");
        }
      }
    });
    // 週明け（日曜17時 NY）
    for (var d3 = addDays(localDate(from, "America/New_York"), -1); d3 <= addDays(localDate(to, "America/New_York"), 1); d3 = addDays(d3, 1)) {
      if (dowOf(d3) === 0) add(zonedToUtc(d3, "17:00", "America/New_York"), "週明けの取引開始（目安）", "week", "NY時間 日曜17時。開始時刻は取引会社によって異なります", "週明け");
    }
    // 中央銀行
    ((D.cb && D.cb.banks) || []).forEach(function (b) {
      b.meetings.forEach(function (m) {
        var at = zonedToUtc(m.date, b.time || "12:00", b.tz);
        add(at, b.short + "・" + b.meeting + "（" + (b.time ? b.timeLabel : "結果公表") + "）", "cb", (b.time ? "" : "公表時刻は事前に決まっていません。") + (m.tag || ""), b.short);
      });
    });
    // CFTC（公表日の一覧があればそれを使い、なければ金曜）
    var cftcDates = (D.cftc && D.cftc.dates) || [];
    for (var d4 = addDays(localDate(from, "America/New_York"), -1); d4 <= addDays(localDate(to, "America/New_York"), 1); d4 = addDays(d4, 1)) {
      var listed = cftcDates.indexOf(d4) >= 0;
      var useDefault = !cftcDates.length || d4 > cftcDates[cftcDates.length - 1];
      var usHol = CAL.us[d4] && CAL.us[d4].type !== "early";
      if (listed) add(zonedToUtc(d4, "15:30", "America/New_York"), "CFTC 建玉明細（投機筋ポジション）の公表", "cftc", "火曜時点のポジション");
      else if (useDefault && dowOf(d4) === 5 && !usHol) add(zonedToUtc(d4, "15:30", "America/New_York"), "CFTC 建玉明細の公表（通常は金曜）", "cftc", "公表日の一覧が未登録のため目安です。祝日の週はずれます");
    }
    // 夏時間の切り替え
    dstChanges(from, to).forEach(function (c) { add(c.at, c.label, "dst", c.note); });
    // 休場（その日の0時に置く）
    for (var d5 = jstDate(from); d5 <= jstDate(to); d5 = addDays(d5, 1)) {
      var at0 = jstMidnight(d5);
      if (CAL.jp[d5]) ev.push({ at: Math.max(at0, from), allDay: true, date: d5, label: "日本：" + CAL.jp[d5], kind: "hol", sub: "東京市場は休み" });
      if (CAL.uk[d5]) ev.push({ at: Math.max(at0, from), allDay: true, date: d5, label: "英国：" + CAL.uk[d5], kind: "hol", sub: "ロンドン市場は休み（英国の現地日付）" });
      var u = CAL.us[d5];
      if (u) ev.push({ at: Math.max(at0, from), allDay: true, date: d5, label: "米国：" + u.name, kind: "hol", sub: u.note + "（米国の現地日付）" });
    }
    ev.sort(function (a, b) { return a.at - b.at || (a.allDay ? -1 : 1); });
    return ev;
  }

  var DST_ZONES = [
    { tz: "America/New_York", name: "米国", effect: "NY市場と米国の経済指標の時刻" },
    { tz: "Europe/London", name: "英国", effect: "ロンドン市場と英国の経済指標の時刻" },
    { tz: "Europe/Berlin", name: "欧州（ユーロ圏）", effect: "欧州の市場とECBの発表の時刻" },
    { tz: "Australia/Sydney", name: "豪州（シドニー）", effect: "シドニー市場とRBAの発表の時刻" },
    { tz: "Pacific/Auckland", name: "ニュージーランド", effect: "NZの市場とRBNZの発表の時刻" }
  ];
  var dstMemo = {};
  function dstChanges(from, to) {
    var key = Math.floor(from / HOUR) + ":" + Math.floor(to / HOUR);
    if (dstMemo[key]) return dstMemo[key];
    var out = dstMemo[key] = [];
    DST_ZONES.forEach(function (z) {
      var t0 = Math.floor((from - DAY) / HOUR) * HOUR; // 切り替えは毎正時（UTC）に起きるので、時刻を正時にそろえて探す
      var prev = tzOffsetMin(t0, z.tz);
      for (var t = t0 + HOUR * 6; t <= to + DAY; t += HOUR * 6) {
        var off = tzOffsetMin(t, z.tz);
        if (off !== prev) {
          // 切り替わった瞬間を1時間単位で探す
          var lo = t - HOUR * 6, hi = t;
          while (hi - lo > HOUR) { var mid = lo + Math.floor((hi - lo) / 2 / HOUR) * HOUR; if (mid === lo) mid = lo + HOUR; if (tzOffsetMin(mid, z.tz) === prev) lo = mid; else hi = mid; }
          var on = off > prev;
          if (hi >= from && hi < to) out.push({
            at: hi, zone: z, on: on, date: localDate(hi, z.tz),
            label: z.name + "が" + (on ? "夏時間に切り替え" : "冬時間（標準時間）に戻る"),
            note: z.effect + "が、日本時間で1時間" + (on ? "早く" : "遅く") + "なります"
          });
          prev = off;
        }
      }
    });
    out.sort(function (a, b) { return a.at - b.at; });
    return out;
  }

  function renderHero() {
    if (!CAL.ready) return;
    var now = Date.now();
    var today = jstDate(now);
    var closed = weekClosed(now);
    // 週末は、週明けの月曜の時間割を表示する
    var startDay = closed ? jstDate(nextWeekOpen(now)) : (jstTime(now) < "06:00" ? addDays(today, -1) : today);
    var from = jstMidnight(startDay) + 6 * HOUR, to = from + DAY;
    var P = function (t) { return Math.max(0, Math.min(100, (t - from) / DAY * 100)); };
    var html = [];
    // 時刻の目盛り
    html.push('<div class="sb-row"><div></div><div class="sb-ticks">');
    for (var k = 0; k <= 8; k++) {
      var hr = (6 + k * 3) % 24;
      var lab = hr === 0 ? "24" : String(hr);
      html.push('<span class="sb-tick' + (k % 2 ? " minor" : "") + '" style="left:' + (k * 12.5) + '%">' + lab + "</span>");
    }
    html.push("</div></div>");
    var openNow = [];
    SESSIONS.forEach(function (s) {
      var inst = sessionInstances(s, from, to);
      var bands = inst.map(function (x) {
        var l = P(x.start), r = P(x.end);
        if (x.start <= now && now < x.end && !weekClosed(now)) openNow.push(s.name + (x.holiday ? "（祝日）" : ""));
        var title = s.name + " " + jstTime(x.start) + "〜" + jstTime(x.end) + (x.holiday ? "（" + x.holiday + "）" : "");
        return '<div class="sb-band ' + s.cls + (x.holiday ? " is-holiday" : "") + '" style="left:' + l + "%;width:" + Math.max(0.5, r - l) + '%" title="' + esc(title) + '">' + (x.holiday ? '<span class="sb-hol">休</span>' : "") + "</div>";
      }).join("");
      html.push('<div class="sb-row"><div class="sb-label"><b>' + s.name + "</b></div><div class=\"sb-track\">" + bands + "</div></div>");
    });
    // 予定のピン（定時の目印・中銀・週の区切り）
    var pins = collectEvents(from, to).filter(function (e) { return e.short && !e.allDay; });
    html.push('<div class="sb-row"><div class="sb-label">予定</div><div class="sb-events" id="sbEvents">');
    var lastX = [-100, -100];
    var boardW = ($("#sessionBoard").clientWidth || 600) - 74;
    pins.forEach(function (e) {
      var x = P(e.at), px = x / 100 * boardW;
      var w = e.short.length * 12 + 34;
      var row = px - lastX[0] >= w ? 0 : px - lastX[1] >= w ? 1 : -1;
      if (row < 0) return;
      lastX[row] = px;
      var edge = px < w / 2 ? " at-start" : px > boardW - w / 2 ? " at-end" : "";
      html.push('<div class="sb-ev' + (e.kind === "cb" ? " is-cb" : "") + (row ? " row2" : "") + edge + '" style="left:' + x + '%" title="' + esc(jstTime(e.at) + " " + e.label) + '"><span>' + esc(jstTime(e.at) + " " + e.short) + "</span></div>");
    });
    html.push("</div></div>");
    // いまの線（ラベル列のぶんずらす）
    if (now >= from && now < to) html.push('<div class="sb-now" style="left:calc(74px + (100% - 74px) * ' + (P(now) / 100).toFixed(4) + ')"></div>');
    // 3時間ごとの縦線
    for (var g = 1; g < 8; g++) html.push('<div class="sb-gridline" style="left:calc(74px + (100% - 74px) * ' + (g * 0.125) + ')"></div>');
    var board = $("#sessionBoard");
    board.innerHTML = html.join("");
    if (window.matchMedia("(max-width: 640px)").matches) {
      $$(".sb-now, .sb-gridline", board).forEach(function (n) { n.style.left = n.style.left.replace(/74px/g, "52px"); });
    }

    // 状況の文
    var status;
    if (closed) {
      var wo = nextWeekOpen(now);
      status = "週末のため為替市場はお休み中です。週明けの取引開始（目安）まで <b>" + fmtLeft(wo - now) + "</b>（" + jaMD(jstDate(wo)) + " " + jstTime(wo) + "）。下は週明けの時間割です";
    } else {
      var next = null;
      SESSIONS.forEach(function (s) {
        sessionInstances(s, now, now + DAY).forEach(function (x) { if (x.start > now && (!next || x.start < next.at)) next = { at: x.start, name: s.name }; });
      });
      status = "いま開いている市場：<b>" + esc(openNow.length ? openNow.join("・") : "主要市場の時間外（取引は可能）") + "</b>";
      if (next) status += "　" + esc(next.name) + "の開始まで " + fmtLeft(next.at - now);
    }
    $("#heroStatus").innerHTML = status;
    renderChips(now, today);
  }

  function renderChips(now, today) {
    var chips = [];
    var g = gotobi(today);
    if (g) chips.push({ t: "きょうは" + g + "（ゴトー日）", key: true });
    [today, addDays(today, 1)].forEach(function (d) {
      var w = d === today ? "きょう" : "あす";
      if (CAL.jp[d]) chips.push({ t: w + " 日本は祝日（" + CAL.jp[d] + "）" });
      if (CAL.uk[d]) chips.push({ t: w + " 英国は祝日（" + CAL.uk[d] + "）" });
      if (CAL.us[d]) chips.push({ t: w + " 米国：" + CAL.us[d].name + "（" + CAL.us[d].note + "）" });
    });
    ((D.cb && D.cb.banks) || []).forEach(function (b) {
      b.meetings.forEach(function (m) {
        var at = zonedToUtc(m.date, b.time || "12:00", b.tz);
        var jd = jstDate(at);
        if (jd === today || jd === addDays(today, 1)) chips.push({ t: (jd === today ? "きょう" : "あす") + " " + b.short + "の政策発表" + (b.time ? "（" + jstTime(at) + "）" : "（時刻未定）"), key: jd === today });
      });
    });
    dstChanges(now, now + 10 * DAY).forEach(function (c) { chips.push({ t: jaMD(c.date) + " " + c.label }); });
    var nyOff = tzOffsetMin(now, "America/New_York");
    var t830 = zonedToUtc(localDate(now, "America/New_York"), "08:30", "America/New_York");
    chips.push({ t: "米国は" + (nyOff === -240 ? "夏時間" : "冬時間") + "：米東部8:30発表の指標は日本時間" + jstTime(t830) });
    $("#heroChips").innerHTML = chips.map(function (c) { return '<span class="chip' + (c.key ? " is-key" : "") + '">' + esc(c.t) + "</span>"; }).join("");
  }

  var KIND_TAG = { session: ["市場", ""], fix: ["定時", ""], cb: ["中銀", "cb"], hol: ["休場", "hol"], dst: ["時間変更", "hol"], cftc: ["CFTC", ""], week: ["週", ""] };
  function renderUpcoming() {
    if (!CAL.ready) return;
    var now = Date.now(), today = jstDate(now);
    var ev = collectEvents(now - 5 * MIN, now + 36 * HOUR).filter(function (e) { return e.allDay ? e.date >= today : true; });
    var seen = {};
    ev = ev.filter(function (e) { var k = e.label + e.at; if (seen[k]) return false; seen[k] = 1; return true; }).slice(0, 14);
    var list = $("#upcomingList");
    if (!ev.length) { list.innerHTML = '<li><span></span><span class="empty">36時間以内の予定はありません</span><span></span></li>'; return; }
    list.innerHTML = ev.map(function (e) {
      var d = e.allDay ? e.date : jstDate(e.at);
      var tag = KIND_TAG[e.kind] || ["", ""];
      return "<li><span class=\"tl-time\">" + (e.allDay ? "終日" : jstTime(e.at)) + '<span class="tl-day">' + esc(dayWord(d, today)) + "</span></span>" +
        '<span class="tl-label"><span class="tag ' + tag[1] + '">' + tag[0] + "</span>" + esc(e.label) + (e.sub ? "<small>" + esc(e.sub) + "</small>" : "") + "</span>" +
        '<span class="tl-left">' + (e.allDay ? "" : esc(fmtLeft(Math.max(0, e.at - now)))) + "</span></li>";
    }).join("");
  }

  // ============================== AIまとめ ==============================
  function srcLinks(list) {
    if (!list || !list.length) return "";
    return '<div class="src">出典：' + list.map(function (s) { return '<a href="' + esc(safeUrl(s.url)) + '" target="_blank" rel="noopener nofollow">' + esc(s.title || s.url) + "</a>"; }).join("、") + "</div>";
  }
  function briefStamp(b) { return b && b.generated_at ? jstStamp(b.generated_at) + " 作成" : ""; }
  function staleNote(b) {
    if (!b || !b.date) return "";
    var age = (toMs(jstDate(Date.now())) - toMs(b.date)) / DAY;
    return age >= 2 ? '<p class="warn-note">' + esc(jaMD(b.date)) + "のまとめです（最新ではありません）</p>" : "";
  }
  function renderBriefHome(daily, weekly) {
    var box = $("#briefHome");
    var b = weekly && weekly.headline && (!daily || !daily.date || weekly.date > daily.date) ? weekly : daily;
    $("#briefHomeTitle").textContent = b && b.mode === "weekly" ? "AI週末まとめ" : "AI朝のまとめ";
    if (!b || !b.headline) {
      box.innerHTML = '<p class="empty">まだ作成されていません。設定が済むと、平日の朝6時半ごろに自動で作成されます。</p>';
      return;
    }
    if (b.mode === "weekly") b = Object.assign({}, b, { watch: b.next_week });
    $("#briefHomeMeta").textContent = briefStamp(b);
    var h = staleNote(b) + '<p class="brief-headline">' + esc(b.headline) + "</p>";
    h += '<ul class="brief-points">' + (b.summary || []).map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("") + "</ul>";
    if (b.watch && b.watch.length) {
      h += '<div class="brief-box"><h3>' + (b.mode === "weekly" ? "来週の注目予定" : "きょうの注目予定") + '（AIが調べたもの・日本時間）</h3><ul class="watch-list">' + b.watch.slice(0, 4).map(function (w) {
        return '<li><span class="watch-when">' + esc(w.when) + "</span><span>" + esc(w.label) + (w.note ? '<span class="watch-note">' + esc(w.note) + "</span>" : "") + "</span></li>";
      }).join("") + "</ul></div>";
    }
    if (b.gbpjpy) h += '<div class="brief-box"><h3>ポンド円の材料</h3><p>' + esc(b.gbpjpy.text) + "</p>" + srcLinks(b.gbpjpy.sources) + "</div>";
    h += '<p class="brief-more"><a href="#news">全文と出典を見る</a></p>';
    h += '<p class="fine">AIが公開情報を検索して自動で作成したまとめです。誤りを含む可能性があります。</p>';
    box.innerHTML = h;
    $$('a[href="#news"]', box).forEach(function (a) { a.addEventListener("click", function (ev) { ev.preventDefault(); history.replaceState(null, "", "#news"); showTab("news"); }); });
  }
  function renderBriefFull(box, b) {
    if (!b || !b.headline) { box.innerHTML = '<p class="empty">まだ作成されていません。</p>'; return; }
    var h = '<p class="meta">' + esc(jaDate(b.date)) + "　" + esc(briefStamp(b)) + (b.searches ? "　Web検索 " + b.searches + "回" : "") + "</p>";
    h += staleNote(b) + '<p class="brief-headline">' + esc(b.headline) + "</p>";
    h += '<ul class="brief-points">' + (b.summary || []).map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("") + "</ul>";
    if (b.gbpjpy) h += '<div class="brief-box"><h3>ポンド円の材料</h3><p>' + esc(b.gbpjpy.text) + "</p>" + srcLinks(b.gbpjpy.sources) + "</div>";
    var watch = b.mode === "weekly" ? b.next_week : b.watch;
    if (watch && watch.length) {
      h += '<div class="brief-box"><h3>' + (b.mode === "weekly" ? "来週の注目予定" : "きょうの注目予定") + "（AIが調べたもの・日本時間。発表元でもご確認ください）</h3><ul class=\"watch-list\">" + watch.map(function (w) {
        return '<li><span class="watch-when">' + esc(w.when) + "</span><span>" + esc(w.label) + (w.note ? '<span class="watch-note">' + esc(w.note) + "</span>" : "") + srcLinks(w.sources) + "</span></li>";
      }).join("") + "</ul></div>";
    }
    var sections = b.mode === "weekly" ? [{ title: "先週の主な出来事", items: b.review || [] }] : (b.sections || []);
    sections.forEach(function (s) {
      if (!s.items || !s.items.length) return;
      h += '<section class="brief-section"><h3>' + esc(s.title) + "</h3>" + s.items.map(function (it) {
        return '<div class="brief-item"><h4>' + esc(it.title) + "</h4><p>" + esc(it.body) + "</p>" + srcLinks(it.sources) + "</div>";
      }).join("") + "</section>";
    });
    if (b.caution) h += '<p class="warn-note">' + esc(b.caution) + "</p>";
    h += '<p class="notice-ai">' + esc(b.notice || "AIが自動で作成したまとめです。誤りを含む可能性があります。") + "</p>";
    box.innerHTML = h;
  }

  // ============================== 政策金利 ==============================
  function decisionAt(b, m) { return zonedToUtc(m.date, b.time || "12:00", b.tz); }
  function resolvePolicy(now) {
    var cb = D.cb, bis = D.bis, us = D.usRates;
    if (!cb) return [];
    return cb.banks.map(function (b) {
      var cur = b.current;
      var r = { b: b, display: cur.display, value: cur.value, action: cur.lastAction, actionDate: cur.decided, actionKind: "決定", src: "公式発表", srcUrl: cur.source, pending: null, heldAt: null };
      var changes = null, autoDate = null, srcName = "", srcUrl = "";
      if (b.id === "fed" && us && us.fed && us.fed.upperHistory) {
        changes = us.fed.upperHistory.map(function (c, i) { var l = us.fed.lowerHistory[Math.min(i, us.fed.lowerHistory.length - 1)]; return [c[0], c[1], l ? l[1] : c[1] - 0.25]; });
        autoDate = us.fed.date; srcName = "FRED（FRB）"; srcUrl = "https://fred.stlouisfed.org/series/DFEDTARU";
      } else if (bis && bis.areas && bis.areas[b.bis]) {
        changes = bis.areas[b.bis].changes; autoDate = bis.areas[b.bis].last[0]; srcName = "BIS"; srcUrl = "https://data.bis.org/topics/CBPOL";
      }
      if (changes && changes.length >= 2) {
        var lc = changes[changes.length - 1], prevC = changes[changes.length - 2];
        var autoVal = b.id === "fed" ? (lc[1] + lc[2]) / 2 : lc[1];
        if (lc[0] > (cur.effective || cur.decided) && Math.abs(autoVal - cur.value) > 1e-9) {
          r.value = autoVal;
          r.display = b.id === "fed" ? lc[2].toFixed(2) + "〜" + lc[1].toFixed(2) + "%" : lc[1].toFixed(2) + "%";
          r.action = lc[1] > prevC[1] ? "利上げ" : "利下げ";
          r.actionDate = lc[0]; r.actionKind = "実施"; r.src = srcName; r.srcUrl = srcUrl;
        }
      }
      var lag = b.id === "fed" ? 1 : 7;
      var passed = b.meetings.filter(function (m) { return m.date > cur.decided && decisionAt(b, m) <= now; });
      var lastM = passed[passed.length - 1];
      if (lastM) {
        var covered = autoDate && autoDate >= addDays(lastM.date, lag);
        if (r.actionDate >= lastM.date) { /* 自動データで変更を確認済み */ }
        else if (covered) r.heldAt = lastM.date;
        else r.pending = lastM;
      }
      r.next = b.meetings.filter(function (m) { return decisionAt(b, m) > now - 2 * HOUR; })[0] || null;
      if (r.next) r.nextAt = decisionAt(b, r.next);
      return r;
    });
  }
  // 次回の発表を「日時」と「あと何日」に分けて返す（HTML）
  function nextHtml(r, now) {
    if (!r.next) return "未定（公式サイトでご確認ください）";
    var d = jstDate(r.nextAt), today = jstDate(now);
    var t = (r.b.time ? jstTime(r.nextAt) : "時刻未定");
    var left = r.nextAt > now ? fmtLeft(r.nextAt - now) : "発表済みの可能性";
    return '<span class="nw">' + esc(dayWord(d, today) + " " + t) + '</span> <span class="nw left">' + esc(left) + "</span>";
  }
  function renderPolicyMini() {
    var now = Date.now();
    var rows = resolvePolicy(now);
    if (!rows.length) { $("#policyMini").innerHTML = '<p class="empty">データを読み込めませんでした。</p>'; return; }
    rows.sort(function (a, b) { return (a.nextAt || 9e15) - (b.nextAt || 9e15); });
    $("#policyMini").innerHTML = '<ul class="policy-mini">' + rows.map(function (r) {
      return '<li><span class="pm-bank">' + esc(r.b.short) + '</span><span class="pm-rate">' + esc(r.display) + '</span><span class="pm-next">' + nextHtml(r, now) + (r.pending ? '<br><span class="warn-note">' + esc(jaMD(r.pending.date)) + "の結果は未反映</span>" : "") + "</span></li>";
    }).join("") + "</ul>";
  }
  function renderPolicyTable() {
    var now = Date.now();
    var rows = resolvePolicy(now);
    if (!rows.length) { $("#policyTable").innerHTML = '<p class="empty">データを読み込めませんでした。</p>'; return; }
    $("#policyMeta").textContent = "会合日程・公式発表の確認日 " + (D.cb.checked || "");
    var h = '<table class="tbl tbl-stack"><thead><tr><th>中央銀行</th><th>政策金利</th><th>直近の動き</th><th>次回の発表（日本時間）</th></tr></thead><tbody>';
    rows.forEach(function (r) {
      var act = r.heldAt
        ? jaMD(r.heldAt) + "の会合後も変更なし（" + r.src + "で確認）"
        : jaMD(r.actionDate) + " " + r.action + (r.actionKind === "実施" ? "（実施日）" : "");
      h += "<tr><td><b>" + esc(r.b.short) + '</b><span class="note">' + esc(r.b.name) + "</span></td>" +
        '<td><span class="big">' + esc(r.display) + '</span><span class="note">' + esc(r.b.rateName) + "</span></td>" +
        '<td data-label="直近の動き">' + esc(act) + '<span class="note">出典：<a href="' + esc(safeUrl(r.srcUrl)) + '" target="_blank" rel="noopener">' + esc(r.src) + "</a></span>" +
        (r.pending ? '<span class="warn-note">' + esc(jaMD(r.pending.date)) + 'の会合結果はまだ反映されていません。<a href="' + esc(safeUrl(r.b.url)) + '" target="_blank" rel="noopener">公式サイト</a>でご確認ください</span>' : "") + "</td>" +
        '<td data-label="次回の発表（日本時間）">' + nextHtml(r, now) + (r.next && r.next.tag ? '<span class="note">' + esc(r.next.tag) + "</span>" : "") + "</td></tr>";
    });
    h += "</tbody></table>";
    $("#policyTable").innerHTML = h;
    $("#policyNote").innerHTML = "政策金利は各中央銀行の公式発表で確認した値です。会合後の変更は、FRB分はFREDから翌営業日ごろ、その他はBISの統計（週1回更新）から自動で反映されます。会合の直後は反映まで1〜2週間かかることがあります。";
  }
  function renderCbCalendar() {
    var cb = D.cb;
    if (!cb) return;
    var now = Date.now(), today = jstDate(now);
    var start = today.slice(0, 8) + "01";
    var months = [0, 1, 2].map(function (i) { var a = start.split("-").map(Number); var d = new Date(Date.UTC(a[0], a[1] - 1 + i, 1)); return d.toISOString().slice(0, 7); });
    var items = [];
    cb.banks.forEach(function (b) { b.meetings.forEach(function (m) { var at = decisionAt(b, m); items.push({ at: at, b: b, m: m, jd: jstDate(at) }); }); });
    items.sort(function (x, y) { return x.at - y.at; });
    $("#cbCalendar").innerHTML = months.map(function (ym) {
      var list = items.filter(function (x) { return x.jd.slice(0, 7) === ym; });
      var a = ym.split("-").map(Number);
      return '<div class="cb-month"><h3>' + a[0] + "年" + a[1] + "月</h3><ul>" + (list.length ? list.map(function (x) {
        return '<li class="' + (x.at < now ? "is-past" : "") + '"><span class="when">' + esc(jaMD(x.jd)) + '<span class="cb-time">' + (x.b.time ? jstTime(x.at) : "時刻未定") + "</span></span><span><b>" + esc(x.b.short) + "</b> " + esc(x.b.meeting) + (x.m.tag ? '<span class="note">' + esc(x.m.tag) + "</span>" : "") + "</span></li>";
      }).join("") : '<li><span></span><span class="empty">予定はありません</span></li>') + "</ul></div>";
    }).join("");
  }

  // ============================== 金利差・利回り曲線 ==============================
  function lastN(arr, days) {
    if (!arr || !arr.length) return [];
    var cut = addDays(arr[arr.length - 1][0], -days);
    return arr.filter(function (p) { return p[0] >= cut; });
  }
  function jgbSeries(tenor) {
    var j = D.jgb;
    if (!j) return [];
    var i = j.tenors.indexOf(tenor);
    return j.rows.map(function (r) { return [r[0], r[1][i]]; }).filter(function (p) { return p[1] !== null; });
  }
  function toPts(arr) { return arr.map(function (p) { return [toMs(p[0]), p[1]]; }); }
  function renderSpread(tenor) {
    var us = D.usRates, j = D.jgb, fx = D.fx;
    var id = tenor === "2Y" ? "DGS2" : "DGS10";
    var label = tenor === "2Y" ? "2年" : "10年";
    $("#spreadT1").textContent = "米国と日本の国債利回り（" + label + "）";
    $("#spreadT2").textContent = "金利差（米国 − 日本、" + label + "）";
    if (!us || !j) {
      $("#chartYields").innerHTML = '<p class="empty">データの初回取得前です。GitHub Actionsでデータを取得すると表示されます。</p>';
      $("#chartSpread").innerHTML = ""; $("#chartUsdJpy").innerHTML = "";
      return;
    }
    var usS = lastN(us.series[id], 730), jpS = lastN(jgbSeries(tenor), 730);
    var jpMap = {}; jpS.forEach(function (p) { jpMap[p[0]] = p[1]; });
    var spread = usS.filter(function (p) { return jpMap[p[0]] !== undefined; }).map(function (p) { return [p[0], Math.round((p[1] - jpMap[p[0]]) * 1000) / 1000]; });
    var pf = function (v) { return v.toFixed(2) + "%"; };
    $("#spreadMeta").textContent = "米国 " + (usS.length ? usS[usS.length - 1][0] : "—") + "／日本 " + (jpS.length ? jpS[jpS.length - 1][0] : "—") + " 時点";
    Charts.line($("#chartYields"), { series: [{ name: "米国" + label, color: "var(--series-1)", data: toPts(usS) }, { name: "日本" + label, color: "var(--series-2)", data: toPts(jpS) }], yFmt: pf, height: 230, aria: "米国と日本の" + label + "国債利回りの推移" });
    Charts.line($("#chartSpread"), { series: [{ name: "金利差", color: "var(--series-1)", data: toPts(spread), area: true }], yFmt: function (v) { return v.toFixed(2) + "%pt"; }, height: 170, zero: true, aria: "日米の金利差の推移" });
    if (fx && fx.usdjpy) {
      var first = usS.length ? usS[0][0] : "0000";
      var fxS = fx.usdjpy.filter(function (p) { return p[0] >= first; });
      Charts.line($("#chartUsdJpy"), { series: [{ name: "ドル円", color: "var(--series-1)", data: toPts(fxS) }], yFmt: function (v) { return v.toFixed(2) + "円"; }, height: 170, aria: "ドル円の推移（NY正午の参考レート）" });
    } else $("#chartUsdJpy").innerHTML = '<p class="empty">データがありません</p>';
  }
  // 基準日と同じ年なら「10/2」、違う年なら「2025/10/2」
  function shortDate(d, base) {
    var a = d.split("-").map(Number);
    return (d.slice(0, 4) === base.slice(0, 4) ? "" : a[0] + "/") + a[1] + "/" + a[2];
  }
  function valueAt(arr, dateStr) {
    for (var i = arr.length - 1; i >= 0; i--) if (arr[i][0] <= dateStr && arr[i][1] !== null) return arr[i];
    return null;
  }
  function renderCurves() {
    var us = D.usRates, j = D.jgb;
    var pf = function (v) { return v.toFixed(2) + "%"; };
    if (us) {
      var ten = us.tenors;
      var latest = us.series.DGS10[us.series.DGS10.length - 1][0];
      var snaps = [["最新", latest, "var(--series-1)", false], ["1カ月前", addDays(latest, -30), "var(--series-past)", true], ["1年前", addDays(latest, -365), "var(--series-past-2)", true]];
      var series = snaps.map(function (s) {
        var data = ten.map(function (t, i) { var v = valueAt(us.series[t.id], s[1]); return [i, v ? v[1] : null]; });
        var found = valueAt(us.series.DGS10, s[1]);
        return { name: s[0] + "（" + (found ? shortDate(found[0], latest) : "—") + "）", color: s[2], data: data, past: s[3], width: s[3] ? 1.6 : 2.4 };
      });
      $("#curveUsMeta").textContent = latest + " 時点";
      Charts.line($("#curveUs"), { series: series, xType: "cat", cats: ten.map(function (t) { return t.label; }), yFmt: pf, height: 230, endLabels: false, aria: "米国債の利回り曲線" });
    } else $("#curveUs").innerHTML = '<p class="empty">データの初回取得前です。</p>';
    if (j) {
      var pick = ["1Y", "2Y", "3Y", "5Y", "7Y", "10Y", "15Y", "20Y", "30Y", "40Y"];
      var idx = pick.map(function (t) { return j.tenors.indexOf(t); });
      var lastD = j.rows[j.rows.length - 1][0];
      var rowAt = function (d) { for (var i = j.rows.length - 1; i >= 0; i--) if (j.rows[i][0] <= d) return j.rows[i]; return null; };
      var snaps2 = [["最新", lastD, "var(--series-1)", false], ["1カ月前", addDays(lastD, -30), "var(--series-past)", true], ["1年前", addDays(lastD, -365), "var(--series-past-2)", true]];
      var series2 = snaps2.map(function (s) {
        var row = rowAt(s[1]);
        return { name: s[0] + "（" + (row ? shortDate(row[0], lastD) : "—") + "）", color: s[2], past: s[3], width: s[3] ? 1.6 : 2.4, data: idx.map(function (k, i) { return [i, row ? row[1][k] : null]; }) };
      });
      $("#curveJpMeta").textContent = lastD + " 時点";
      Charts.line($("#curveJp"), { series: series2, xType: "cat", cats: pick.map(function (t) { return t.replace("Y", "年"); }), yFmt: pf, height: 230, endLabels: false, aria: "日本国債の利回り曲線" });
    } else $("#curveJp").innerHTML = '<p class="empty">データの初回取得前です。</p>';
  }

  // ============================== CFTC ==============================
  var COT_JA = { JPY: "円", GBP: "ポンド", EUR: "ユーロ", AUD: "豪ドル", NZD: "NZドル", CAD: "カナダドル", CHF: "スイスフラン", MXN: "メキシコペソ" };
  function renderCot(sel) {
    var c = D.cot;
    if (!c || !c.currencies) { $("#cotBars").innerHTML = '<p class="empty">データの初回取得前です。</p>'; return; }
    sel = sel || store.get("mp_cot", "JPY");
    $("#cotMeta").textContent = (c.latest ? c.latest + "（火曜）時点" : "");
    var rows = c.currencies.filter(function (x) { return x.rows.length; }).map(function (x) {
      var r = x.rows[x.rows.length - 1];
      return { key: x.ccy, label: COT_JA[x.ccy] || x.ccy, value: Math.round((r[2] - r[3]) / r[1] * 1000) / 10 };
    }).sort(function (a, b) { return b.value - a.value; });
    Charts.bars($("#cotBars"), {
      rows: rows, selected: sel, posLabel: "買い越し", negLabel: "売り越し", nameHeader: "通貨", valueHeader: "建玉に対する割合",
      fmt: function (v) { return (v > 0 ? "+" : "") + v.toFixed(1) + "%"; },
      aria: "通貨別の投機筋ポジション。行を選ぶと推移を表示します",
      onSelect: function (k) { store.set("mp_cot", k); renderCot(k); }
    });
    var cur = c.currencies.filter(function (x) { return x.ccy === sel; })[0] || c.currencies[0];
    var net = cur.rows.map(function (r) { return [r[0], r[2] - r[3]]; });
    var last = net[net.length - 1], prev = net[net.length - 2];
    var vals = net.map(function (p) { return p[1]; });
    var lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
    var idx = hi > lo ? Math.round((last[1] - lo) / (hi - lo) * 100) : 50;
    var name = COT_JA[cur.ccy] || cur.ccy;
    $("#cotHistTitle").textContent = name + "（対ドル）の買い越し・売り越しの推移（枚）";
    $("#cotStats").innerHTML =
      '<div class="stat"><span class="stat-label">最新</span><span class="stat-value">' + (last[1] >= 0 ? "買い越し " : "売り越し ") + fmtNum(Math.abs(last[1])) + "枚</span></div>" +
      (prev ? '<div class="stat"><span class="stat-label">前週から</span><span class="stat-value">' + esc(signed(last[1] - prev[1], 0, "枚")) + "</span></div>" : "") +
      '<div class="stat"><span class="stat-label">過去2年の中での位置（0＝最も売り越し、100＝最も買い越し）</span><span class="stat-value">' + idx + "</span></div>";
    Charts.line($("#cotHist"), {
      series: [{ name: name + "の買い越し・売り越し", color: "var(--series-1)", data: net.map(function (p) { return [toMs(p[0]), p[1]]; }), area: true }],
      yFmt: function (v) { return (v >= 0 ? "買い越し " : "売り越し ") + fmtNum(Math.abs(v)) + "枚"; },
      tickFmt: function (v) { return (v / 1000).toFixed(0) + "千"; },
      height: 230, zero: true, endLabels: false, aria: name + "の投機筋ポジションの推移"
    });
  }

  // ============================== 経済指標 ==============================
  function fmtInd(ind, v) {
    if (v === null || v === undefined) return "—";
    if (ind.unit === "%") return v.toFixed(1) + "%";
    if (ind.unit === "千人") return (v >= 0 ? "+" : "−") + fmtNum(Math.abs(v) / 10, 1) + "万人";
    if (ind.unit === "件") return fmtNum(v / 10000, 1) + "万件";
    return v.toFixed(2);
  }
  function indDate(ind, d) {
    var a = d.split("-").map(Number);
    return ind.freq === "W" ? a[1] + "/" + a[2] + "までの週" : a[0] + "年" + a[1] + "月分";
  }
  var FRED_SRC = { BLS: "米労働統計局（BLS）", BEA: "米経済分析局（BEA）", "米労働省": "米労働省", "Claudia Sahm": "Claudia Sahm" };
  function renderMacro(sel) {
    var m = D.macro;
    if (!m || !m.indicators) { $("#macroTiles").innerHTML = '<p class="empty">データの初回取得前です。GitHub Actionsでデータを取得すると表示されます。</p>'; return; }
    $("#macroMeta").textContent = "FRED経由・" + jstStamp(m.updated) + " 取得";
    var tiles = $("#macroTiles");
    tiles.innerHTML = m.indicators.map(function (ind) {
      if (!ind.latest) return "";
      var flag = ind.threshold !== undefined && ind.latest.value >= ind.threshold ? '<span class="flag">' + ind.threshold.toFixed(2) + "以上</span>" : "";
      return '<button class="tile" type="button" data-id="' + esc(ind.id) + '" aria-pressed="' + (sel === ind.id) + '">' +
        '<span class="tile-label">' + esc(ind.name) + " <small>" + esc(ind.measure) + "</small></span>" +
        '<span class="tile-value">' + esc(fmtInd(ind, ind.latest.value)) + "</span>" +
        '<span class="tile-meta">' + esc(indDate(ind, ind.latest.date)) + (ind.prev ? "・前回 " + esc(fmtInd(ind, ind.prev.value)) : "") + "</span>" + flag +
        '<span class="spark" data-spark="' + esc(ind.id) + '"></span></button>';
    }).join("");
    m.indicators.forEach(function (ind) {
      var el = $('[data-spark="' + ind.id + '"]', tiles);
      if (el) Charts.spark(el, ind.series.slice(ind.freq === "W" ? -52 : -24), { ref: ind.threshold !== undefined ? ind.threshold : ind.id === "nfp" ? 0 : undefined });
    });
    $$(".tile", tiles).forEach(function (t) {
      t.addEventListener("click", function () {
        var id = t.getAttribute("data-id");
        var next = sel === id ? null : id;
        store.set("mp_macro", next || "");
        renderMacro(next);
      });
    });
    var det = $("#macroDetail");
    var ind = m.indicators.filter(function (x) { return x.id === sel; })[0];
    if (!ind) { det.innerHTML = ""; return; }
    det.innerHTML = '<div class="panel-head"><h3>' + esc(ind.name + "（" + ind.measure + "）") + '</h3><span class="meta">' + esc(ind.hint || "") + '</span></div><div id="macroChart"></div><p class="fine">出典：' + esc(FRED_SRC[ind.src] || ind.src) + "（FRED経由）　系列：" +
      ind.fred.map(function (f) { return '<a href="https://fred.stlouisfed.org/series/' + esc(f) + '" target="_blank" rel="noopener">' + esc(f) + "</a>"; }).join("、") + "</p>";
    var refs = [];
    if (ind.threshold !== undefined) refs.push({ y: ind.threshold, label: "目安 " + ind.threshold.toFixed(2) });
    if (ind.id === "pce" || ind.id === "core_pce") refs.push({ y: 2, label: "FRBの物価目標 2%" });
    Charts.line($("#macroChart"), {
      series: [{ name: ind.name, color: "var(--series-1)", data: ind.series.map(function (p) { return [toMs(p[0]), p[1]]; }), area: ind.id === "nfp" }],
      yFmt: function (v) { return fmtInd(ind, v); }, height: 240, refs: refs, zero: ind.id === "nfp",
      xFmt: function (x) { return indDate(ind, new Date(x).toISOString().slice(0, 10)); },
      tickFmt: ind.unit === "件" ? function (v) { return (v / 10000).toFixed(0) + "万"; } : ind.unit === "千人" ? function (v) { return (v / 10).toFixed(0) + "万"; } : undefined,
      aria: ind.name + "の推移"
    });
  }

  // ============================== ニュース ==============================
  function initNews() {
    loadJson("briefs/index.json").then(function (idx) {
      var sel = $("#briefSelect");
      var items = (idx && idx.items || []).filter(function (x) { return x.mode === "daily"; });
      if (!items.length) { sel.parentElement.hidden = true; }
      sel.innerHTML = items.map(function (x) { return '<option value="' + esc(x.file) + '">' + esc(jaMD(x.date)) + "　" + esc(x.headline || "") + "</option>"; }).join("");
      sel.addEventListener("change", function () {
        loadJson("briefs/" + sel.value).then(function (b) { renderBriefFull($("#briefFull"), b); });
      });
    });
    renderBriefFull($("#briefFull"), D.brief);
    Promise.resolve(D.weekly).then(function (w) {
      $("#weeklyMeta").textContent = "毎週土曜の朝に更新";
      if (!w || !w.headline) { $("#weeklyBrief").innerHTML = '<p class="empty">まだ作成されていません。設定が済むと、毎週土曜の朝に自動で作成されます。</p>'; return; }
      renderBriefFull($("#weeklyBrief"), w);
    });
  }

  // ============================== 休場・時間 ==============================
  function renderHolidays() {
    var today = jstDate(Date.now()), end = addDays(today, 90);
    var rows = [];
    Object.keys(CAL.jp).forEach(function (d) { if (d >= today && d <= end) rows.push([d, "東京", CAL.jp[d], ""]); });
    Object.keys(CAL.uk).forEach(function (d) { if (d >= today && d <= end) rows.push([d, "ロンドン", CAL.uk[d], ""]); });
    Object.keys(CAL.us).forEach(function (d) { if (d >= today && d <= end) rows.push([d, "ニューヨーク", CAL.us[d].name, CAL.us[d].note]); });
    rows.sort(function (a, b) { return a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0; });
    $("#holidayList").innerHTML = rows.length ? '<table class="tbl"><thead><tr><th>日付（現地）</th><th>市場</th><th>内容</th></tr></thead><tbody>' + rows.map(function (r) {
      return "<tr><td>" + esc(jaMD(r[0])) + "</td><td>" + esc(r[1]) + "</td><td>" + esc(r[2]) + (r[3] ? '<span class="note">' + esc(r[3]) + "</span>" : "") + "</td></tr>";
    }).join("") + "</tbody></table>" : '<p class="empty">90日以内の休場予定はありません。</p>';
  }
  function renderDst() {
    var now = Date.now();
    var list = dstChanges(now, now + 366 * DAY);
    $("#dstList").innerHTML = list.length ? list.map(function (c) {
      return '<li><span class="when">' + esc(jaDate(c.date).replace(/^/, c.date.slice(0, 4) + "年")) + "</span>" + esc(c.label) + "<small>" + esc(c.note) + "</small></li>";
    }).join("") : '<li class="empty">1年以内の切り替えはありません。</li>';
  }
  function sessionRange(s, dateStr) {
    var a = zonedToUtc(dateStr, s.open, s.tz), b = zonedToUtc(dateStr, s.close, s.tz);
    return jstTime(a) + "〜" + (jstDate(b) !== jstDate(a) ? "翌" : "") + jstTime(b);
  }
  function nextChangeDate(tz, now) {
    var c = dstChanges(now, now + 366 * DAY).filter(function (x) { return x.zone.tz === tz; })[0];
    return c ? c.date : null;
  }
  function renderSessionTable() {
    var now = Date.now();
    var h = '<table class="tbl tbl-stack"><thead><tr><th>市場</th><th>現地時間</th><th>いま（日本時間）</th><th>次の切り替え後</th></tr></thead><tbody>';
    SESSIONS.forEach(function (s) {
      var today = localDate(now, s.tz);
      var nc = nextChangeDate(s.tz, now);
      h += "<tr><td><b>" + esc(s.name === "NY" ? "ニューヨーク" : s.name) + '</b></td><td data-label="現地時間">' + s.open + "〜" + s.close + '</td><td data-label="いま（日本時間）">' + sessionRange(s, today) + '</td><td data-label="次の切り替え後">' +
        (nc ? sessionRange(s, addDays(nc, 1)) + '<span class="note">' + esc(nc.slice(0, 4) + "年" + jaMD(nc)) + "から</span>" : "変更なし") + "</td></tr>";
    });
    h += "</tbody></table>";
    $("#sessionTable").innerHTML = h;
  }
  function renderFixedTimes() {
    var now = Date.now();
    var items = [
      ["東京仲値", "Asia/Tokyo", "09:55", "銀行が顧客向けの基準レートを決める時刻"],
      ["ロンドン・フィックス", "Europe/London", "16:00", "WM/ロイターの基準レート算出"],
      ["NYカット", "America/New_York", "10:00", "通貨オプションの権利行使の期限"],
      ["NYクローズ", "America/New_York", "17:00", "1日の区切り（スワップポイントが付く）"],
      ["米国の主要指標", "America/New_York", "08:30", "雇用統計・CPIなどの発表時刻（米東部8:30）"],
      ["CFTC建玉の公表", "America/New_York", "15:30", "金曜（祝日の週は遅れることがあります）"],
      ["週明けの取引開始（目安）", "America/New_York", "17:00", "米東部の日曜17時。取引会社により異なります"]
    ];
    var h = '<table class="tbl tbl-stack"><thead><tr><th>イベント</th><th>現地時刻</th><th>いま（日本時間）</th><th>次の切り替え後</th></tr></thead><tbody>';
    items.forEach(function (it) {
      var d = localDate(now, it[1]);
      var t = zonedToUtc(d, it[2], it[1]);
      var nc = it[1] === "Asia/Tokyo" ? null : nextChangeDate(it[1], now);
      var t2 = nc ? zonedToUtc(addDays(nc, 1), it[2], it[1]) : null;
      var label = function (ms, base) { var jd = jstDate(ms); return (jd !== base ? "翌" : "") + jstTime(ms); };
      h += "<tr><td><b>" + esc(it[0]) + '</b><span class="note">' + esc(it[3]) + '</span></td><td data-label="現地時刻">' + it[2] + '</td><td data-label="いま（日本時間）">' + label(t, d) + '</td><td data-label="次の切り替え後">' + (t2 ? label(t2, addDays(nc, 1)) : "—") + "</td></tr>";
    });
    h += "</tbody></table>";
    $("#fixedTimes").innerHTML = h;
  }

  // ============================== お知らせ・チェックリスト ==============================
  function renderNotices(n) {
    var items = (n && n.items) || [];
    if (!items.length) { $("#noticePanel").hidden = true; return; }
    $("#noticePanel").hidden = false;
    $("#notices").innerHTML = items.slice(0, 5).map(function (x) {
      return "<li>" + (x.date ? "<time>" + esc(jaDate(x.date)) + "</time>" : "") + "<h3>" + esc(x.title) + "</h3><p>" + esc(x.body || "") + "</p>" +
        (x.link ? '<p><a href="' + esc(safeUrl(x.link)) + '" target="_blank" rel="noopener">' + esc(x.linkText || "くわしく") + "</a></p>" : "") + "</li>";
    }).join("");
  }
  function initChecklist() {
    var items = CFG.checklist || [];
    var key = "mp_check_" + jstDate(Date.now());
    var state = {};
    try { state = JSON.parse(store.get(key, "{}")) || {}; } catch (e) {}
    var ul = $("#checklist");
    ul.innerHTML = items.map(function (t, i) { return '<li><label><input type="checkbox" data-i="' + i + '"' + (state[i] ? " checked" : "") + "><span>" + esc(t) + "</span></label></li>"; }).join("");
    ul.addEventListener("change", function (ev) {
      var i = ev.target.getAttribute("data-i");
      state[i] = ev.target.checked;
      store.set(key, JSON.stringify(state));
    });
    $("#checkReset").addEventListener("click", function () { state = {}; store.set(key, "{}"); $$("input", ul).forEach(function (c) { c.checked = false; }); });
  }

  // ============================== チャートタブ ==============================
  var TF = [["5", "5分"], ["15", "15分"], ["60", "1時間"], ["240", "4時間"], ["D", "日足"], ["W", "週足"]];
  var chartState = { sym: null, tf: null };
  function chartCfg(sym, tf, compact) {
    return function (t) {
      var c = { autosize: true, symbol: sym, interval: tf, timezone: "Asia/Tokyo", theme: t, style: "1", locale: "ja", allow_symbol_change: !compact, calendar: false, hide_volume: true, support_host: "https://www.tradingview.com" };
      if (compact) { c.hide_top_toolbar = true; c.hide_side_toolbar = true; c.save_image = false; }
      return c;
    };
  }
  function initChart() {
    var syms = CFG.chartSymbols || [];
    chartState.sym = store.get("mp_chart_sym", CFG.defaultChartSymbol || (syms[0] && syms[0].s) || "FX:GBPJPY");
    if (!syms.some(function (s) { return s.s === chartState.sym; })) chartState.sym = CFG.defaultChartSymbol || syms[0].s;
    chartState.tf = store.get("mp_chart_tf", "60");
    function pills() {
      $("#symPills").innerHTML = syms.map(function (s) { return '<button type="button" class="pill" data-s="' + esc(s.s) + '" aria-pressed="' + (s.s === chartState.sym) + '">' + esc(s.t) + "</button>"; }).join("");
      $("#tfPills").innerHTML = TF.map(function (t) { return '<button type="button" class="pill" data-tf="' + t[0] + '" aria-pressed="' + (t[0] === chartState.tf) + '">' + t[1] + "</button>"; }).join("");
    }
    pills();
    function mountMain() { tvMount($("#mainChart"), "advanced-chart", chartCfg(chartState.sym, chartState.tf, false)); }
    function mountMtf() {
      var name = (syms.filter(function (s) { return s.s === chartState.sym; })[0] || {}).t || chartState.sym;
      $("#mtfMeta").textContent = name;
      var grid = $("#mtfGrid");
      grid.innerHTML = [["D", "日足"], ["240", "4時間足"], ["60", "1時間足"], ["15", "15分足"]].map(function (x) {
        return '<div class="mtf-cell"><h3>' + esc(name) + "　" + x[1] + '</h3><div class="tv-box" data-mtf="' + x[0] + '"></div></div>';
      }).join("");
      $$("[data-mtf]", grid).forEach(function (el) {
        whenVisible(el, function () { tvMount(el, "advanced-chart", chartCfg(chartState.sym, el.getAttribute("data-mtf"), true), true); });
      });
      grid.insertAdjacentHTML("beforeend", '<p class="tv-credit fine" style="grid-column:1/-1">提供：<a href="https://jp.tradingview.com/" target="_blank" rel="noopener nofollow">TradingView</a></p>');
    }
    whenVisible($("#mainChart"), mountMain);
    mountMtf();
    $("#symPills").addEventListener("click", function (ev) {
      var b = ev.target.closest("[data-s]");
      if (!b) return;
      chartState.sym = b.getAttribute("data-s");
      store.set("mp_chart_sym", chartState.sym);
      pills(); mountMain(); mountMtf();
    });
    $("#tfPills").addEventListener("click", function (ev) {
      var b = ev.target.closest("[data-tf]");
      if (!b) return;
      chartState.tf = b.getAttribute("data-tf");
      store.set("mp_chart_tf", chartState.tf);
      pills(); mountMain();
    });
    // マーケット一覧
    var ml = $("#marketList");
    ml.innerHTML = (CFG.marketGroups || []).map(function (g) {
      return '<div class="mkt-group"><h3>' + esc(g.title) + '</h3><div class="mkt-grid">' + g.symbols.map(function (s) {
        return '<div class="mkt-cell"><div class="tv-box" data-mini="' + esc(s[0]) + '" aria-label="' + esc(s[1]) + '"></div></div>';
      }).join("") + "</div></div>";
    }).join("");
    $$("[data-mini]", ml).forEach(function (el) {
      var sym = el.getAttribute("data-mini");
      whenVisible(el, function () {
        tvMount(el, "mini-symbol-overview", function (t) { return { symbol: sym, width: "100%", height: "100%", locale: "ja", dateRange: "1M", colorTheme: t, isTransparent: true, autosize: true, largeChartUrl: "" }; }, true);
      });
    });
    ml.insertAdjacentHTML("beforeend", '<p class="tv-credit fine">提供：<a href="https://jp.tradingview.com/" target="_blank" rel="noopener nofollow">TradingView</a></p>');
  }

  // ============================== 検索 ==============================
  var TAB_JA = { home: "きょう", chart: "チャート", strength: "通貨の強弱", rates: "金利・中銀", macro: "経済指標", news: "ニュース", hours: "休場・時間" };
  function initSearch() {
    var dlg = $("#searchDlg"), input = $("#searchInput"), list = $("#searchList");
    var index = $$("[data-panel]").map(function (el) {
      var pane = el.closest(".pane");
      return { id: el.getAttribute("data-panel"), title: el.getAttribute("data-title") || "", tab: pane ? pane.id.replace("pane-", "") : "home" };
    });
    var cur = 0, hits = [];
    function draw() {
      var q = input.value.trim().toLowerCase();
      hits = index.filter(function (x) { return !q || (x.title + TAB_JA[x.tab]).toLowerCase().indexOf(q) >= 0; });
      cur = Math.min(cur, Math.max(0, hits.length - 1));
      list.innerHTML = hits.length ? hits.map(function (x, i) { return '<li role="option" data-i="' + i + '" aria-selected="' + (i === cur) + '"><span>' + esc(x.title) + "</span><small>" + esc(TAB_JA[x.tab]) + "</small></li>"; }).join("") : '<li class="empty">見つかりません</li>';
    }
    function go(i) {
      var x = hits[i];
      if (!x) return;
      dlg.close();
      history.replaceState(null, "", "#" + x.tab);
      showTab(x.tab, x.id);
    }
    function open() { input.value = ""; cur = 0; draw(); if (dlg.showModal) dlg.showModal(); else dlg.setAttribute("open", ""); input.focus(); }
    $("#searchBtn").addEventListener("click", open);
    input.addEventListener("input", function () { cur = 0; draw(); });
    input.addEventListener("keydown", function (ev) {
      if (ev.key === "ArrowDown") { cur = Math.min(hits.length - 1, cur + 1); draw(); ev.preventDefault(); }
      else if (ev.key === "ArrowUp") { cur = Math.max(0, cur - 1); draw(); ev.preventDefault(); }
      else if (ev.key === "Enter") { ev.preventDefault(); go(cur); }
    });
    list.addEventListener("click", function (ev) { var li = ev.target.closest("[data-i]"); if (li) go(+li.getAttribute("data-i")); });
    dlg.addEventListener("click", function (ev) { if (ev.target === dlg) dlg.close(); });
    document.addEventListener("keydown", function (ev) {
      if (ev.key === "/" && !/input|textarea|select/i.test((ev.target.tagName || "")) && !dlg.open) { ev.preventDefault(); open(); }
    });
  }

  // ============================== フッター・ダイアログ ==============================
  var SRC_JA = { fred: "米国の金利・経済指標（FRED）", jgb: "日本国債の利回り（財務省）", cot: "投機筋ポジション（CFTC）", policy: "政策金利（BIS）", holidays: "祝日（内閣府・GOV.UK）", jwks: "会員確認の鍵（Fincs）", brief_daily: "AI朝のまとめ", brief_weekly: "AI週末まとめ" };
  function renderStatus(meta) {
    var src = (meta && meta.sources) || {};
    var keys = Object.keys(SRC_JA);
    $("#sourceStatus").innerHTML = keys.map(function (k) {
      var s = src[k];
      if (!s) return '<li><span class="st st-skip">–</span><span>' + esc(SRC_JA[k]) + "：まだ取得していません</span></li>";
      var icon = s.status === "ok" ? '<span class="st st-ok" aria-label="正常">✓</span>' : s.status === "skipped" ? '<span class="st st-skip" aria-label="未設定">–</span>' : '<span class="st st-err" aria-label="要確認">!</span>';
      var txt = s.status === "skipped" ? "未設定" : (s.lastSuccess ? jstStamp(s.lastSuccess) + " 更新" : "未取得") + (s.status === "error" ? "（直近の取得に失敗）" : "");
      return "<li>" + icon + "<span>" + esc(SRC_JA[k]) + "：" + esc(txt) + "</span></li>";
    }).join("");
  }
  function initDialogs() {
    var about = $("#aboutDlg");
    function openAbout() { if (about.showModal) about.showModal(); else about.setAttribute("open", ""); }
    $("#aboutBtn").addEventListener("click", openAbout);
    $("#aboutBtn2").addEventListener("click", openAbout);
    $$("[data-close]", about).forEach(function (b) { b.addEventListener("click", function () { about.close(); }); });
    about.addEventListener("click", function (ev) { if (ev.target === about) about.close(); });
    $("#logoutBtn").addEventListener("click", function () {
      window.PortalGate.clearSession();
      about.close();
      location.reload();
    });
    if (CFG.feedbackUrl) $("#feedbackSlot").innerHTML = '　<a href="' + esc(safeUrl(CFG.feedbackUrl)) + '" target="_blank" rel="noopener">ご意見・ご要望</a>';
  }
  function initTheme() {
    $("#themeBtn").addEventListener("click", function () {
      var next = theme() === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      store.set("mp_theme", next);
      tvRemountAll();
    });
  }
  function tickClock() {
    var now = Date.now(), d = jstDate(now);
    $("#clockDate").textContent = jaDate(d);
    $("#clockTime").textContent = new Date(now + 9 * HOUR).toISOString().slice(11, 19);
  }

  // ============================== タブごとの初期化 ==============================
  INIT.home = function () {
    renderHero(); renderUpcoming(); renderPolicyMini(); renderBriefHome(D.brief, D.weekly); initChecklist();
    loadJson("manual/notices.json").then(renderNotices);
  };
  INIT.chart = initChart;
  INIT.strength = function () { renderCot(); };
  INIT.rates = function () {
    renderPolicyTable(); renderCbCalendar();
    var cur = store.get("mp_spread", "10Y");
    var pills = $("#spreadPills");
    function draw() {
      pills.innerHTML = [["10Y", "10年"], ["2Y", "2年"]].map(function (x) { return '<button type="button" class="pill" data-t="' + x[0] + '" aria-pressed="' + (x[0] === cur) + '">' + x[1] + "</button>"; }).join("");
      renderSpread(cur);
    }
    pills.addEventListener("click", function (ev) { var b = ev.target.closest("[data-t]"); if (!b) return; cur = b.getAttribute("data-t"); store.set("mp_spread", cur); draw(); });
    draw();
    renderCurves();
  };
  INIT.macro = function () { renderMacro(store.get("mp_macro", "") || null); };
  INIT.news = initNews;
  INIT.hours = function () { renderHolidays(); renderDst(); renderSessionTable(); renderFixedTimes(); };

  // ============================== 起動 ==============================
  function applyNames() {
    if (CFG.siteName) { document.title = CFG.siteName; $$("[data-site-name]").forEach(function (e) { e.textContent = CFG.siteName; }); }
    if (CFG.tagline) $$("[data-tagline]").forEach(function (e) { e.textContent = CFG.tagline; });
  }
  function showGate(res) {
    var g = $("#gate");
    g.hidden = false;
    $("#gateMsg").textContent = window.PortalGate.messageFor(res.code);
    var link = $("#gateLink");
    var url = (CFG.gate && CFG.gate.fincsUrl) || "";
    if (url) { link.href = safeUrl(url); link.hidden = false; }
    if (/[?&]gate=debug\b/.test(location.search)) {
      var c = res.claims || {};
      $("#gateDebug").hidden = false;
      $("#gateDebug").textContent = "code: " + res.code + "\ndetail: " + (res.detail || "") +
        "\niss: " + (c.iss || "") + "\naud: " + JSON.stringify(c.aud) + "\nexp: " + (c.exp ? new Date(c.exp * 1000).toISOString() : "") +
        "\nplan(" + ((CFG.gate && CFG.gate.planClaim) || "plan_id") + "): " + JSON.stringify(c[(CFG.gate && CFG.gate.planClaim) || "plan_id"]) +
        "\n許可しているaud: " + JSON.stringify(res.audiences || []);
    }
  }
  function boot() {
    $("#app").hidden = false;
    if (window.PORTAL_PREVIEW) { var pb = $("#previewBar"); pb.hidden = false; pb.textContent = window.PORTAL_PREVIEW; }
    tickClock();
    setInterval(tickClock, 1000);
    initTabs(); initTheme(); initDialogs(); initSearch();
    // ティッカー
    tvMount($("#tape"), "ticker-tape", function (t) {
      return { symbols: (CFG.ticker || []).map(function (x) { return { proName: x.s, title: x.t }; }), showSymbolLogo: false, isTransparent: true, displayMode: "adaptive", colorTheme: t, locale: "ja" };
    });
    // 共通データを読み込んでから表示
    Promise.all([
      loadJson("manual/central_banks.json"), loadJson("holidays_jp.json"), loadJson("manual/holidays_jp_extra.json"), loadJson("holidays_uk.json"),
      loadJson("manual/holidays_us.json"), loadJson("manual/cftc_schedule.json"), loadJson("policy_bis.json"), loadJson("us_rates.json"),
      loadJson("brief.json"), loadJson("meta.json"), loadJson("brief_weekly.json")
    ]).then(function (r) {
      D.cb = r[0]; D.hjp = r[1]; D.hjpx = r[2]; D.huk = r[3]; D.hus = r[4]; D.cftc = r[5]; D.bis = r[6]; D.usRates = r[7]; D.brief = r[8]; D.weekly = r[10];
      buildCalendar();
      renderStatus(r[9]);
      return Promise.all([loadJson("jgb.json"), loadJson("fx_ref.json"), loadJson("cot.json"), loadJson("us_macro.json")]).then(function (r2) {
        D.jgb = r2[0]; D.fx = r2[1]; D.cot = r2[2]; D.macro = r2[3];
      }).then(function () {
        var parts = location.hash.replace("#", "").split("/");
        var first = TABS.indexOf(parts[0]) >= 0 ? parts[0] : "home";
        showTab(first, parts[1]);
      });
    });
    // 相場時計は30秒ごと、データは30分ごとに更新
    setInterval(function () { if (inited.home && !document.hidden) { renderHero(); renderUpcoming(); } }, 30000);
    setInterval(function () {
      if (document.hidden) return;
      Promise.all([loadJson("brief.json", true), loadJson("meta.json", true), loadJson("brief_weekly.json", true)]).then(function (r) {
        if (r[0]) D.brief = r[0];
        if (r[2]) D.weekly = r[2];
        if (inited.home) renderBriefHome(D.brief, D.weekly);
        renderStatus(r[1]);
      });
    }, 30 * MIN);
    var lastW = window.innerWidth;
    window.addEventListener("resize", function () { if (Math.abs(window.innerWidth - lastW) > 40 && inited.home) { lastW = window.innerWidth; renderHero(); } });
  }

  function start() {
    applyNames();
    (window.PortalGateReady || Promise.resolve({ ok: true })).then(function (res) {
      if (res && res.ok) boot(); else showGate(res || { code: "other" });
    }, function () { showGate({ code: "other" }); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();

  // テスト用に一部の関数を公開
  window.__portal = { zonedToUtc: zonedToUtc, gotobi: gotobi, collectEvents: collectEvents, dstChanges: dstChanges, resolvePolicy: resolvePolicy, weekClosed: weekClosed, D: D, CAL: CAL, buildCalendar: buildCalendar };
})();
