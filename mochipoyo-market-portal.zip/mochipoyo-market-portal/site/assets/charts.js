/*
 * charts.js — 小さなSVGグラフ（外部ライブラリなし）
 *   Charts.line(el, opts)  折れ線（時系列・カテゴリ）＋十字線ツールチップ＋表で見る
 *   Charts.bars(el, opts)  横向きのプラス・マイナス棒グラフ（選択できる）
 *   Charts.spark(el, data, opts)  タイル用の小さな線
 * 色は CSS 変数（var(--series-1) など）で渡すので、明暗の切り替えに自動で追従する。
 */
(function () {
  "use strict";
  var NS = "http://www.w3.org/2000/svg";
  var DAY = 86400000;

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; });
  }
  function niceStep(span, count) {
    if (!(span > 0)) return 1;
    var raw = span / Math.max(1, count);
    var p = Math.pow(10, Math.floor(Math.log10(raw)));
    var m = raw / p;
    var nice = m <= 1 ? 1 : m <= 2 ? 2 : m <= 2.5 ? 2.5 : m <= 5 ? 5 : 10;
    return nice * p;
  }
  function yDomain(min, max, count) {
    if (min === max) { var pad = Math.abs(min) * 0.1 || 1; min -= pad; max += pad; }
    var step = niceStep(max - min, count);
    var lo = Math.floor(min / step) * step;
    var hi = Math.ceil(max / step) * step;
    if (lo === hi) hi = lo + step;
    var ticks = [];
    for (var v = lo; v <= hi + step / 2; v += step) ticks.push(Math.round(v / step) * step);
    return { lo: lo, hi: hi, ticks: ticks, step: step };
  }
  function decimalsOf(step) {
    var s = String(step);
    var i = s.indexOf(".");
    return i < 0 ? 0 : Math.min(3, s.length - i - 1);
  }
  function ymdLabel(t) {
    var d = new Date(t);
    return d.getUTCFullYear() + "年" + (d.getUTCMonth() + 1) + "月" + d.getUTCDate() + "日";
  }
  function timeTicks(lo, hi, maxTicks) {
    var span = hi - lo;
    var opts = [1, 2, 3, 6, 12, 24, 36, 60];
    var months = span / (30.44 * DAY);
    var stepM = opts[opts.length - 1];
    for (var i = 0; i < opts.length; i++) if (months / opts[i] <= maxTicks) { stepM = opts[i]; break; }
    var d = new Date(lo);
    var y = d.getUTCFullYear(), m = d.getUTCMonth();
    m = Math.ceil((m + (d.getUTCDate() > 1 ? 1 : 0)) / stepM) * stepM;
    var out = [];
    for (var k = 0; k < 400; k++) {
      var t = Date.UTC(y, m + k * stepM, 1);
      if (t > hi) break;
      if (t >= lo) out.push(t);
    }
    return { ticks: out, stepM: stepM };
  }
  function timeTickLabel(t, stepM, first) {
    var d = new Date(t);
    var y = d.getUTCFullYear(), m = d.getUTCMonth() + 1;
    if (stepM >= 12) return y + "年";
    if (m === 1 || first) return y + "年" + m + "月";
    return m + "月";
  }
  function median(arr) {
    if (!arr.length) return 0;
    var a = arr.slice().sort(function (x, y) { return x - y; });
    return a[Math.floor(a.length / 2)];
  }
  function nearestIndex(xs, x) {
    var lo = 0, hi = xs.length - 1;
    if (hi < 0) return -1;
    while (hi - lo > 1) {
      var mid = (lo + hi) >> 1;
      if (xs[mid] < x) lo = mid; else hi = mid;
    }
    return Math.abs(xs[lo] - x) <= Math.abs(xs[hi] - x) ? lo : hi;
  }
  function textWidth(s, px) {
    var w = 0;
    s = String(s);
    for (var i = 0; i < s.length; i++) w += s.charCodeAt(i) > 255 ? px : px * 0.58;
    return w;
  }

  // 要素の幅が変わったら描き直す（非表示タブの中では幅0なので、表示されたときに描く）
  function observe(el, draw) {
    var last = -1, raf = 0;
    function run() {
      raf = 0;
      var w = Math.floor(el.clientWidth);
      if (w > 0 && w !== last) { last = w; draw(w); }
    }
    if (typeof ResizeObserver !== "undefined") {
      if (el.__ro) el.__ro.disconnect();
      el.__ro = new ResizeObserver(function () { if (!raf) raf = requestAnimationFrame(run); });
      el.__ro.observe(el);
    }
    run();
  }

  function svgEl(tag, attrs) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) if (attrs[k] !== undefined && attrs[k] !== null) e.setAttribute(k, attrs[k]);
    return e;
  }

  function tableHtml(opts, rowsHtml) {
    return '<details><summary>数値を表で見る</summary><div class="table-wrap"><table class="tbl">' + rowsHtml + "</table></div></details>";
  }

  // ======================= 折れ線 =======================
  function line(el, opts) {
    opts = opts || {};
    var series = (opts.series || []).filter(function (s) { return s.data && s.data.length; });
    el.classList.add("chart");
    el.innerHTML = "";
    if (!series.length) { el.innerHTML = '<p class="empty">' + esc(opts.emptyText || "データがありません") + "</p>"; return; }
    var isCat = opts.xType === "cat";
    var height = opts.height || 220;
    var yFmt = opts.yFmt || function (v) { return String(v); };
    var xFmt = opts.xFmt || (isCat ? function (x) { return (opts.cats || [])[x]; } : ymdLabel);

    // 凡例（2系列以上のときだけ）
    if (series.length > 1 || opts.legend) {
      var lg = document.createElement("div");
      lg.className = "legend";
      series.forEach(function (s) {
        var sp = document.createElement("span");
        var i = document.createElement("i");
        i.style.borderTopColor = s.color;
        if (s.dash) i.style.borderTopStyle = "dashed";
        sp.appendChild(i);
        sp.appendChild(document.createTextNode(s.name));
        lg.appendChild(sp);
      });
      el.appendChild(lg);
    }
    var box = document.createElement("div");
    box.style.position = "relative";
    el.appendChild(box);
    var tip = document.createElement("div");
    tip.className = "tip";
    tip.hidden = true;
    box.appendChild(tip);

    // 系列ごとの x・y 配列
    var S = series.map(function (s) {
      var xs = [], ys = [];
      s.data.forEach(function (p) { if (p[1] !== null && p[1] !== undefined && isFinite(p[1])) { xs.push(p[0]); ys.push(p[1]); } });
      var steps = [];
      for (var i = 1; i < xs.length; i++) steps.push(xs[i] - xs[i - 1]);
      return { s: s, xs: xs, ys: ys, tol: isCat ? 0.5 : Math.max(DAY * 1.5, median(steps) * 1.6) };
    });
    var allX = [];
    S.forEach(function (o) { allX = allX.concat(o.xs); });
    allX = Array.from(new Set(allX)).sort(function (a, b) { return a - b; });
    var xMin = isCat ? -0.5 : allX[0], xMax = isCat ? (opts.cats.length - 0.5) : allX[allX.length - 1];
    if (!isCat && xMin === xMax) { xMin -= DAY; xMax += DAY; }
    var yMin = Infinity, yMax = -Infinity;
    S.forEach(function (o) { o.ys.forEach(function (v) { if (v < yMin) yMin = v; if (v > yMax) yMax = v; }); });
    if (opts.zero) { yMin = Math.min(yMin, 0); yMax = Math.max(yMax, 0); }
    (opts.refs || []).forEach(function (r) { yMin = Math.min(yMin, r.y); yMax = Math.max(yMax, r.y); });
    var dom = yDomain(yMin, yMax, height < 160 ? 3 : 4);
    var dec = opts.yDecimals !== undefined ? opts.yDecimals : decimalsOf(dom.step);
    var tickFmt = opts.tickFmt || function (v) { return v.toFixed(dec); };
    var tickLabels = dom.ticks.map(tickFmt);
    var ml = Math.ceil(Math.max.apply(null, tickLabels.map(function (t) { return textWidth(t, 11); }))) + 10;
    var endLabels = opts.endLabels !== false;

    var sel = { i: -1 };
    function draw(W) {
      var mr = endLabels ? 64 : 12, mt = 10, mb = 24;
      var w = Math.max(60, W - ml - mr), h = height - mt - mb;
      var X = function (x) { return ml + (x - xMin) / (xMax - xMin) * w; };
      var Y = function (y) { return mt + (1 - (y - dom.lo) / (dom.hi - dom.lo)) * h; };
      var svg = svgEl("svg", { viewBox: "0 0 " + W + " " + height, height: height, role: "img", "aria-label": opts.aria || "グラフ", tabindex: "0" });
      var parts = [];
      // 横の目盛り線
      dom.ticks.forEach(function (t, i) {
        parts.push('<line class="gridline" x1="' + ml + '" x2="' + (ml + w) + '" y1="' + Y(t) + '" y2="' + Y(t) + '"/>');
        parts.push('<text class="axis-t" x="' + (ml - 6) + '" y="' + (Y(t) + 4) + '" text-anchor="end">' + esc(tickLabels[i]) + "</text>");
      });
      if (opts.zero && dom.lo < 0 && dom.hi > 0) parts.push('<line class="zero" x1="' + ml + '" x2="' + (ml + w) + '" y1="' + Y(0) + '" y2="' + Y(0) + '"/>');
      (opts.refs || []).forEach(function (r) {
        parts.push('<line class="ref" x1="' + ml + '" x2="' + (ml + w) + '" y1="' + Y(r.y) + '" y2="' + Y(r.y) + '"/>');
        if (r.label) parts.push('<text class="ref-label" x="' + (ml + 4) + '" y="' + (Y(r.y) - 5) + '">' + esc(r.label) + "</text>");
      });
      // 横軸
      parts.push('<line class="axis-base" x1="' + ml + '" x2="' + (ml + w) + '" y1="' + (mt + h) + '" y2="' + (mt + h) + '"/>');
      if (isCat) {
        var every = Math.max(1, Math.ceil(opts.cats.length / Math.max(2, Math.floor(w / 46))));
        opts.cats.forEach(function (c, i) {
          if (i % every) return;
          parts.push('<text class="axis-t" x="' + X(i) + '" y="' + (mt + h + 16) + '" text-anchor="middle">' + esc(c) + "</text>");
        });
      } else {
        var tt = timeTicks(xMin, xMax, Math.max(2, Math.floor(w / 70)));
        tt.ticks.forEach(function (t, i) {
          var x = X(t);
          parts.push('<line class="gridline" x1="' + x + '" x2="' + x + '" y1="' + (mt + h) + '" y2="' + (mt + h + 4) + '"/>');
          parts.push('<text class="axis-t" x="' + x + '" y="' + (mt + h + 16) + '" text-anchor="middle">' + esc(timeTickLabel(t, tt.stepM, i === 0)) + "</text>");
        });
      }
      // 面と線（比較用の過去の線を先に描き、主役の線を上に重ねる）
      S.slice().sort(function (a, b) { return (b.s.past ? 1 : 0) - (a.s.past ? 1 : 0); }).forEach(function (o) {
        var d = "", started = false, prevX = null;
        for (var i = 0; i < o.xs.length; i++) {
          var gap = prevX !== null && !isCat && o.xs[i] - prevX > o.tol * 6;
          d += (started && !gap ? "L" : "M") + X(o.xs[i]).toFixed(1) + " " + Y(o.ys[i]).toFixed(1);
          started = true; prevX = o.xs[i];
        }
        if (o.s.area && o.xs.length > 1) {
          var base = Y(Math.max(dom.lo, Math.min(dom.hi, 0)));
          var a = "M" + X(o.xs[0]).toFixed(1) + " " + base + d.replace(/^M/, "L").replace(/M/g, "L") + "L" + X(o.xs[o.xs.length - 1]).toFixed(1) + " " + base + "Z";
          parts.push('<path d="' + a + '" style="fill:' + o.s.color + ';opacity:.1;stroke:none"/>');
        }
        parts.push('<path d="' + d + '" fill="none" style="stroke:' + o.s.color + '" stroke-width="' + (o.s.width || 2) + '" stroke-linejoin="round" stroke-linecap="round"' + (o.s.dash ? ' stroke-dasharray="5 4"' : "") + "/>");
        if (isCat) {
          for (var k = 0; k < o.xs.length; k++) {
            parts.push('<circle cx="' + X(o.xs[k]) + '" cy="' + Y(o.ys[k]) + '" r="' + (o.s.past ? 2.5 : 3.5) + '" style="fill:' + o.s.color + ';stroke:var(--surface)" stroke-width="1.5"/>');
          }
        }
      });
      // 右端の値ラベル（重なるときは出さない）
      if (endLabels) {
        var labs = S.filter(function (o) { return !o.s.past && o.xs.length; }).map(function (o) {
          var v = o.ys[o.ys.length - 1];
          return { o: o, y: Y(v), y0: Y(v), text: yFmt(v), x: X(o.xs[o.xs.length - 1]) };
        }).sort(function (a, b) { return a.y - b.y; });
        for (var j = 1; j < labs.length; j++) if (labs[j].y - labs[j - 1].y < 14) labs[j].y = labs[j - 1].y + 14;
        var ok = labs.every(function (l) { return Math.abs(l.y - l.y0) < 22; });
        if (ok) labs.forEach(function (l) {
          parts.push('<circle cx="' + l.x + '" cy="' + l.y0 + '" r="4" style="fill:' + l.o.s.color + ';stroke:var(--surface)" stroke-width="2"/>');
          parts.push('<text class="end-label" x="' + (ml + w + 8) + '" y="' + (l.y + 4) + '">' + esc(l.text) + "</text>");
        });
      }
      parts.push('<line class="crosshair" x1="0" x2="0" y1="' + mt + '" y2="' + (mt + h) + '" visibility="hidden"/>');
      parts.push('<g class="hover-dots"></g>');
      parts.push('<rect class="hit" x="' + ml + '" y="' + mt + '" width="' + w + '" height="' + h + '" fill="transparent"/>');
      svg.innerHTML = "<g>" + parts.join("") + "</g>";
      var old = box.querySelector("svg");
      if (old) box.replaceChild(svg, old); else box.insertBefore(svg, tip);

      var cross = svg.querySelector(".crosshair");
      var dots = svg.querySelector(".hover-dots");
      function show(idx, px) {
        if (idx < 0 || idx >= allX.length) return hide();
        sel.i = idx;
        var x = allX[idx];
        var cx = X(x);
        cross.setAttribute("x1", cx); cross.setAttribute("x2", cx); cross.setAttribute("visibility", "visible");
        var html = '<div class="tip-x">' + esc(xFmt(x)) + "</div>";
        var dh = "";
        S.forEach(function (o) {
          var k = nearestIndex(o.xs, x);
          if (k < 0 || Math.abs(o.xs[k] - x) > o.tol) return;
          html += '<div class="tip-row"><i style="border-top-color:' + o.s.color + '"></i><b>' + esc(yFmt(o.ys[k])) + "</b><span>" + esc(o.s.name) + "</span></div>";
          dh += '<circle cx="' + X(o.xs[k]) + '" cy="' + Y(o.ys[k]) + '" r="4" style="fill:' + o.s.color + ';stroke:var(--surface)" stroke-width="2"/>';
        });
        dots.innerHTML = dh;
        tip.innerHTML = html;
        tip.hidden = false;
        var tw = tip.offsetWidth, left = (px === undefined ? cx : px) + 14;
        if (left + tw > W) left = Math.max(0, (px === undefined ? cx : px) - tw - 14);
        tip.style.left = left + "px";
        tip.style.top = Math.max(0, mt) + "px";
      }
      function hide() { cross.setAttribute("visibility", "hidden"); dots.innerHTML = ""; tip.hidden = true; }
      function fromEvent(ev) {
        var r = svg.getBoundingClientRect();
        var px = (ev.clientX - r.left) * (W / r.width);
        var xv = xMin + (px - ml) / w * (xMax - xMin);
        return { idx: nearestIndex(allX, xv), px: px };
      }
      svg.addEventListener("pointermove", function (ev) { var f = fromEvent(ev); show(f.idx, f.px); });
      svg.addEventListener("pointerleave", hide);
      svg.addEventListener("blur", hide);
      svg.addEventListener("keydown", function (ev) {
        var k = ev.key, i = sel.i < 0 ? allX.length - 1 : sel.i;
        if (k === "ArrowLeft") i = Math.max(0, i - 1);
        else if (k === "ArrowRight") i = Math.min(allX.length - 1, i + 1);
        else if (k === "Home") i = 0;
        else if (k === "End") i = allX.length - 1;
        else if (k === "Escape") return hide();
        else return;
        ev.preventDefault();
        show(i);
      });
    }
    observe(box, draw);

    // 表で見る（新しい順）
    if (opts.table !== false) {
      var maxRows = opts.tableRows || 60;
      var xsDesc = allX.slice().reverse().slice(0, maxRows);
      var head = "<tr><th>" + esc(opts.xHeader || (isCat ? "年限" : "日付")) + "</th>" + S.map(function (o) { return '<th class="r">' + esc(o.s.name) + "</th>"; }).join("") + "</tr>";
      var rows = xsDesc.map(function (x) {
        return "<tr><td>" + esc(xFmt(x)) + "</td>" + S.map(function (o) {
          var k = nearestIndex(o.xs, x);
          var v = k >= 0 && o.xs[k] === x ? yFmt(o.ys[k]) : "—";
          return '<td class="r">' + esc(v) + "</td>";
        }).join("") + "</tr>";
      }).join("");
      if (isCat) rows = allX.map(function (x) {
        return "<tr><td>" + esc(xFmt(x)) + "</td>" + S.map(function (o) {
          var k = o.xs.indexOf(x);
          return '<td class="r">' + esc(k >= 0 ? yFmt(o.ys[k]) : "—") + "</td>";
        }).join("") + "</tr>";
      }).join("");
      var t = document.createElement("div");
      t.innerHTML = tableHtml(opts, "<thead>" + head + "</thead><tbody>" + rows + "</tbody>");
      el.appendChild(t.firstChild);
    }
  }

  // ======================= 横棒（プラス・マイナス） =======================
  function bars(el, opts) {
    el.classList.add("chart");
    el.innerHTML = "";
    var rows = opts.rows || [];
    if (!rows.length) { el.innerHTML = '<p class="empty">データがありません</p>'; return; }
    var fmt = opts.fmt || function (v) { return String(v); };
    var lg = document.createElement("div");
    lg.className = "legend";
    lg.innerHTML = '<span><i style="border-top:10px solid var(--pos);width:10px;border-radius:2px"></i>' + esc(opts.posLabel || "プラス") + '</span><span><i style="border-top:10px solid var(--neg);width:10px;border-radius:2px"></i>' + esc(opts.negLabel || "マイナス") + "</span>";
    el.appendChild(lg);
    var box = document.createElement("div");
    el.appendChild(box);
    var rowH = 32, nameW = opts.nameWidth || 96, pad = 6;
    var maxAbs = Math.max.apply(null, rows.map(function (r) { return Math.abs(r.value); })) || 1;
    function draw(W) {
      var plotL = nameW, plotW = Math.max(80, W - nameW - 8);
      var half = plotW / 2;
      var zx = plotL + half;
      var scale = (half - 52) / maxAbs;
      var H = rows.length * rowH + pad * 2;
      var svg = svgEl("svg", { viewBox: "0 0 " + W + " " + H, height: H, role: "group", "aria-label": opts.aria || "棒グラフ" });
      var g = [];
      g.push('<line class="zero" x1="' + zx + '" x2="' + zx + '" y1="' + 2 + '" y2="' + (H - 2) + '"/>');
      rows.forEach(function (r, i) {
        var y = pad + i * rowH, cy = y + rowH / 2;
        var len = Math.max(1, Math.abs(r.value) * scale);
        var pos = r.value >= 0;
        var x0 = pos ? zx : zx - len;
        var rr = Math.min(4, len);
        // 原点側は角なし・先端だけ丸い棒
        var d = pos
          ? "M" + zx + " " + (cy - 8) + "H" + (zx + len - rr) + "Q" + (zx + len) + " " + (cy - 8) + " " + (zx + len) + " " + (cy - 8 + rr) + "V" + (cy + 8 - rr) + "Q" + (zx + len) + " " + (cy + 8) + " " + (zx + len - rr) + " " + (cy + 8) + "H" + zx + "Z"
          : "M" + zx + " " + (cy - 8) + "H" + (zx - len + rr) + "Q" + (zx - len) + " " + (cy - 8) + " " + (zx - len) + " " + (cy - 8 + rr) + "V" + (cy + 8 - rr) + "Q" + (zx - len) + " " + (cy + 8) + " " + (zx - len + rr) + " " + (cy + 8) + "H" + zx + "Z";
        var label = fmt(r.value);
        var lx = pos ? zx + len + 6 : x0 - 6;
        var selected = opts.selected === r.key;
        g.push('<g class="bar-row' + (selected ? " is-selected" : "") + '" data-key="' + esc(r.key) + '" tabindex="0" role="button" aria-pressed="' + selected + '" aria-label="' + esc(r.label + " " + (pos ? (opts.posLabel || "") : (opts.negLabel || "")) + " " + label) + '">');
        g.push('<rect class="bar-hit" x="0" y="' + y + '" width="' + W + '" height="' + rowH + '" rx="6" fill="transparent"/>');
        g.push('<text class="bar-name" x="8" y="' + (cy + 4) + '">' + esc(r.label) + "</text>");
        g.push('<path d="' + d + '" style="fill:var(' + (pos ? "--pos" : "--neg") + ')"/>');
        g.push('<text class="bar-label" x="' + lx + '" y="' + (cy + 4) + '" text-anchor="' + (pos ? "start" : "end") + '">' + esc(label) + "</text>");
        g.push("</g>");
      });
      svg.innerHTML = g.join("");
      box.innerHTML = "";
      box.appendChild(svg);
      if (opts.onSelect) {
        svg.querySelectorAll(".bar-row").forEach(function (n) {
          var pick = function () { opts.onSelect(n.getAttribute("data-key")); };
          n.addEventListener("click", pick);
          n.addEventListener("keydown", function (ev) { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); pick(); } });
        });
      }
    }
    observe(box, draw);
    if (opts.table !== false) {
      var t = document.createElement("div");
      t.innerHTML = tableHtml(opts, "<thead><tr><th>" + esc(opts.nameHeader || "項目") + '</th><th class="r">' + esc(opts.valueHeader || "値") + "</th></tr></thead><tbody>" +
        rows.map(function (r) { return "<tr><td>" + esc(r.label) + '</td><td class="r">' + esc(fmt(r.value)) + "</td></tr>"; }).join("") + "</tbody>");
      el.appendChild(t.firstChild);
    }
  }

  // ======================= スパークライン =======================
  function spark(el, data, opts) {
    opts = opts || {};
    el.classList.add("spark");
    var vals = data.filter(function (p) { return p[1] !== null && isFinite(p[1]); });
    if (vals.length < 2) { el.innerHTML = ""; return; }
    observe(el, function (W) {
      var H = el.clientHeight || 36;
      var min = Infinity, max = -Infinity;
      vals.forEach(function (p) { min = Math.min(min, p[1]); max = Math.max(max, p[1]); });
      if (opts.ref !== undefined) { min = Math.min(min, opts.ref); max = Math.max(max, opts.ref); }
      if (min === max) { min -= 1; max += 1; }
      var X = function (i) { return 3 + i / (vals.length - 1) * (W - 8); };
      var Y = function (v) { return 3 + (1 - (v - min) / (max - min)) * (H - 6); };
      var d = vals.map(function (p, i) { return (i ? "L" : "M") + X(i).toFixed(1) + " " + Y(p[1]).toFixed(1); }).join("");
      var color = opts.color || "var(--series-1)";
      var last = vals[vals.length - 1];
      var s = '<svg viewBox="0 0 ' + W + " " + H + '" aria-hidden="true">';
      if (opts.ref !== undefined) s += '<line x1="0" x2="' + W + '" y1="' + Y(opts.ref) + '" y2="' + Y(opts.ref) + '" style="stroke:var(--axis)" stroke-width="1"/>';
      s += '<path d="' + d + 'L' + X(vals.length - 1).toFixed(1) + " " + H + "L" + X(0) + " " + H + 'Z" style="fill:' + color + ';opacity:.1"/>';
      s += '<path d="' + d + '" fill="none" style="stroke:' + color + '" stroke-width="1.6" stroke-linejoin="round"/>';
      s += '<circle cx="' + X(vals.length - 1) + '" cy="' + Y(last[1]) + '" r="3" style="fill:' + color + ';stroke:var(--surface)" stroke-width="1.5"/></svg>';
      el.innerHTML = s;
    });
  }

  window.Charts = { line: line, bars: bars, spark: spark, ymdLabel: ymdLabel };
})();
