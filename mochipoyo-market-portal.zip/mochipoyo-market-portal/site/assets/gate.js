/*
 * gate.js — Fincs「トークンアクセスリンク」の会員確認（ブラウザ側で検証）
 * ------------------------------------------------------------
 * 流れ:
 *   1. Fincsのリンクから  https://（このサイト）/?token=<JWT>  で開かれる
 *   2. JWTの署名（RS256）を、Fincsの公開鍵（JWKS）で検証する
 *   3. 発行元(iss)・有効期限(exp)・宛先(aud)・プラン（設定時のみ）を確認する
 *   4. 合格したらブラウザに「確認済み」の印を保存し、URLからtokenを消して本編を表示する
 *
 * 注意: GitHub Pagesは静的サイトのため、この確認は「画面の表示制御」です。
 *       data/ 配下のファイルやページのソースは、URLを知っていれば誰でも取得できます。
 *
 * ブラウザでは window.PortalGate、Node（テスト）では module.exports として使えます。
 */
(function (root, factory) {
  var api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.PortalGate = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  "use strict";

  var SESSION_KEY = "mp_portal_session_v1";
  var CLOCK_SKEW = 60; // 秒
  var te = new TextEncoder();

  function GateError(code, detail) {
    var e = new Error(code);
    e.name = "GateError";
    e.code = code;
    e.detail = detail || "";
    return e;
  }

  // ---------- base64url ----------
  function b64uToBytes(s) {
    if (typeof s !== "string" || !/^[A-Za-z0-9_-]*$/.test(s)) throw GateError("malformed", "base64url");
    s = s.replace(/-/g, "+").replace(/_/g, "/");
    var pad = s.length % 4 ? "====".slice(s.length % 4) : "";
    var bin = root.atob(s + pad);
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function b64uToJson(s) {
    try {
      return JSON.parse(new TextDecoder().decode(b64uToBytes(s)));
    } catch (e) {
      throw GateError("malformed", "json");
    }
  }
  function stripSlash(s) {
    return String(s).replace(/\/+$/, "");
  }
  function toList(v) {
    if (v === undefined || v === null) return [];
    return (Array.isArray(v) ? v : [v]).map(function (x) { return String(x); });
  }

  // ---------- 鍵の選択 ----------
  function pickKey(keys, kid) {
    var rsa = (keys || []).filter(function (k) {
      return k && k.kty === "RSA" && (!k.use || k.use === "sig") && (!k.alg || k.alg === "RS256") && k.n && k.e;
    });
    if (kid) {
      for (var i = 0; i < rsa.length; i++) if (rsa[i].kid === kid) return rsa[i];
      return null;
    }
    return rsa.length === 1 ? rsa[0] : null;
  }

  // ---------- JWT検証（RS256） ----------
  // opts: { keys, issuer, audiences:[], allowedPlanIds:[], planClaim, now(秒) }
  async function verifyJwt(token, opts) {
    opts = opts || {};
    if (typeof token !== "string" || token.length > 8192) throw GateError("malformed", "length");
    var parts = token.split(".");
    if (parts.length !== 3) throw GateError("malformed", "parts");
    var header = b64uToJson(parts[0]);
    var payload = b64uToJson(parts[1]);
    if (!header || header.alg !== "RS256") throw GateError("alg", String(header && header.alg));
    var jwk = pickKey(opts.keys, header.kid);
    if (!jwk) throw GateError("kid", String(header.kid || ""));

    var subtle = root.crypto && root.crypto.subtle;
    if (!subtle) throw GateError("crypto", "WebCrypto unavailable");
    var key = await subtle.importKey(
      "jwk",
      { kty: "RSA", n: jwk.n, e: jwk.e, alg: "RS256", ext: true },
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false,
      ["verify"]
    );
    var ok = await subtle.verify(
      "RSASSA-PKCS1-v1_5",
      key,
      b64uToBytes(parts[2]),
      te.encode(parts[0] + "." + parts[1])
    );
    if (!ok) throw GateError("signature");

    var now = typeof opts.now === "number" ? opts.now : Math.floor(Date.now() / 1000);
    if (opts.issuer && stripSlash(payload.iss || "") !== stripSlash(opts.issuer)) {
      throw GateError("iss", String(payload.iss || ""));
    }
    if (typeof payload.exp !== "number") throw GateError("exp_missing");
    if (now > payload.exp + CLOCK_SKEW) throw GateError("expired", String(payload.exp));
    if (typeof payload.nbf === "number" && now + CLOCK_SKEW < payload.nbf) throw GateError("not_yet");
    if (typeof payload.iat === "number" && payload.iat > now + CLOCK_SKEW) throw GateError("iat_future");

    var auds = (opts.audiences || []).filter(Boolean).map(stripSlash);
    if (auds.length) {
      var got = toList(payload.aud).map(stripSlash);
      var hit = got.some(function (a) { return auds.indexOf(a) >= 0; });
      if (!hit) throw GateError("aud", got.join(", "));
    }
    var plans = toList(opts.allowedPlanIds).filter(Boolean);
    if (plans.length) {
      var have = toList(payload[opts.planClaim || "plan_id"]);
      var okPlan = have.some(function (p) { return plans.indexOf(p) >= 0; });
      if (!okPlan) throw GateError("plan", have.join(", "));
    }
    return { header: header, payload: payload };
  }

  // ---------- 公開鍵の取得 ----------
  async function fetchKeys(url, fetchImpl) {
    var f = fetchImpl || root.fetch;
    var res = await f(url, { cache: "no-store", credentials: "omit" });
    if (!res.ok) throw GateError("jwks", url + " " + res.status);
    var json = await res.json();
    if (!json || !Array.isArray(json.keys) || !json.keys.length) throw GateError("jwks", url + " empty");
    return json.keys;
  }

  // 複数の鍵の置き場所を順に試す（ローカルのコピーが古く、kidが見つからない時は次へ）
  async function verifyWithSources(token, urls, opts, fetchImpl) {
    var lastErr = null;
    for (var i = 0; i < urls.length; i++) {
      var keys;
      try {
        keys = await fetchKeys(urls[i], fetchImpl);
      } catch (e) {
        lastErr = e.code ? e : GateError("jwks", String(e && e.message));
        continue;
      }
      try {
        return await verifyJwt(token, Object.assign({}, opts, { keys: keys }));
      } catch (e) {
        if (e.code === "kid") { lastErr = e; continue; }
        throw e;
      }
    }
    throw lastErr || GateError("jwks", "no source");
  }

  // ---------- 確認済みの印（ブラウザ保存） ----------
  function store() {
    try {
      var s = root.localStorage;
      s.setItem("__mp_t", "1");
      s.removeItem("__mp_t");
      return s;
    } catch (e) {
      try { return root.sessionStorage; } catch (e2) { return null; }
    }
  }
  function readSession() {
    try {
      var s = store();
      if (!s) return null;
      var v = JSON.parse(s.getItem(SESSION_KEY) || "null");
      if (!v || typeof v.exp !== "number") return null;
      if (Date.now() / 1000 > v.exp) { s.removeItem(SESSION_KEY); return null; }
      return v;
    } catch (e) { return null; }
  }
  function writeSession(hours) {
    try {
      var s = store();
      if (!s) return false;
      var now = Math.floor(Date.now() / 1000);
      s.setItem(SESSION_KEY, JSON.stringify({ v: 1, at: now, exp: now + Math.round((hours || 24) * 3600) }));
      return true;
    } catch (e) { return false; }
  }
  function clearSession() {
    try { var s = store(); if (s) s.removeItem(SESSION_KEY); } catch (e) {}
  }

  function defaultAudiences(loc) {
    var dir = loc.pathname.replace(/[^/]*$/, "");
    return [loc.origin, loc.origin + dir, loc.origin + loc.pathname];
  }

  // URLから token を取り出し、すぐにアドレスバーから消す（共有・スクリーンショットでの流出防止）
  function takeTokenFromUrl() {
    try {
      var u = new URL(root.location.href);
      var t = u.searchParams.get("token");
      if (t !== null) {
        u.searchParams.delete("token");
        root.history.replaceState(null, "", u.pathname + (u.search || "") + u.hash);
      }
      return t;
    } catch (e) { return null; }
  }

  var MESSAGES = {
    none: "このページはFincs会員専用です。Fincsのコミュニティ内にある「マーケットポータル」のリンクから開いてください。",
    expired: "リンクの有効期限が切れています。Fincsからもう一度開いてください。",
    jwks: "会員確認用の鍵を取得できませんでした。通信状況をご確認のうえ、しばらくしてからFincsのリンクを開き直してください。",
    crypto: "お使いのブラウザでは会員確認ができません。最新のChrome・Safari・Edgeなどでお試しください。",
    other: "会員確認ができませんでした。Fincsのリンクから開き直してください。解決しない場合は運営までお知らせください。"
  };

  // 本編を表示してよいか判定する
  // 戻り値: { ok:true, via } または { ok:false, code, detail, claims }
  async function start(cfg) {
    cfg = cfg || {};
    if (cfg.enabled === false) return { ok: true, via: "disabled" };
    var token = takeTokenFromUrl();
    if (token) {
      var audiences = (cfg.audiences && cfg.audiences.length) ? cfg.audiences : defaultAudiences(root.location);
      try {
        await verifyWithSources(token, cfg.jwksUrls || [], {
          issuer: cfg.issuer,
          audiences: audiences,
          allowedPlanIds: cfg.allowedPlanIds || [],
          planClaim: cfg.planClaim || "plan_id"
        });
        writeSession(cfg.sessionHours);
        return { ok: true, via: "token" };
      } catch (e) {
        var claims = null;
        try { claims = b64uToJson(String(token).split(".")[1]); } catch (_) {}
        // 既に有効な印があれば、古いリンクを開いただけなので通す
        if (readSession()) return { ok: true, via: "session" };
        return { ok: false, code: e.code || "other", detail: e.detail || String(e.message || ""), claims: claims, audiences: audiences };
      }
    }
    if (readSession()) return { ok: true, via: "session" };
    return { ok: false, code: "none" };
  }

  function messageFor(code) {
    if (code === "expired" || code === "not_yet") return MESSAGES.expired;
    if (code === "jwks") return MESSAGES.jwks;
    if (code === "crypto") return MESSAGES.crypto;
    if (code === "none") return MESSAGES.none;
    return MESSAGES.other;
  }

  return {
    SESSION_KEY: SESSION_KEY,
    GateError: GateError,
    b64uToBytes: b64uToBytes,
    pickKey: pickKey,
    verifyJwt: verifyJwt,
    verifyWithSources: verifyWithSources,
    readSession: readSession,
    writeSession: writeSession,
    clearSession: clearSession,
    defaultAudiences: defaultAudiences,
    start: start,
    messageFor: messageFor
  };
});
