// AIまとめ（generate-brief.mjs）のテスト：Claude APIの応答を模擬して検証
import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, writeFile, mkdir, readdir, cp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { run, cleanBrief, extractJson, normUrl, buildContext } from "../scripts/generate-brief.mjs";
import { makeFixtures, fakeFetch, FIXTURE_TODAY } from "./make-fixtures.mjs";
import { updateAll } from "../scripts/update-data.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));
const now = new Date(FIXTURE_TODAY + "T21:35:00Z"); // 日本時間 10/3 6:35
const quiet = () => {};
const A = "https://www.reuters.com/markets/currencies/boe-holds-2026-10-02/";
const B = "https://www.nikkei.com/article/DGXZQO123/";
const C = "https://www.boj.or.jp/en/mopo/mpmdeci/mpr_2026/k260918a.pdf";
const D = "https://www.bloomberg.co.jp/news/articles/2026-10-02/xyz";

function briefJson() {
  return {
    headline: "米金利の上昇でドル高・円安が進む",
    summary: ["米10年債利回りが上昇", "日銀の利上げ観測は一服", "ポンドは英指標待ち"],
    gbpjpy: { text: "英国の指標発表を控え、ポンド円は様子見ムード。", sources: [{ title: "ロイター", url: A }] },
    sections: [
      { id: "policy", items: [{ title: "BOEが金利据え置き", body: "イングランド銀行は政策金利を据え置いた。", sources: [{ title: "Reuters", url: A + "#frag" }] }] },
      { id: "rates", items: [{ title: "米長期金利が上昇", body: "米10年債利回りが上昇した。", sources: [{ title: "でっちあげ", url: "https://fake.example.com/none" }] }] },
      { id: "macro", items: [{ title: "日本の指標", body: "日銀の公表資料によると…", sources: [{ title: "日銀", url: C }] }] },
      { id: "fx", items: [{ title: "ドル円は上昇", body: "ドル円は上昇した。", sources: [{ title: "Bloomberg", url: D }, { title: "日経", url: B }] }] }
    ],
    watch: [{ when: "21:30", label: "米雇用統計", note: "", sources: [{ title: "日経", url: B }] }, { when: "23:00", label: "出典なしの予定", note: "", sources: [] }],
    caution: ""
  };
}

function fakeClaude({ json = briefJson(), brokenFirst = false, status = 200 } = {}) {
  const calls = [];
  const text = JSON.stringify(json);
  const third = Math.floor(text.length / 3);
  const f = async (url, init) => {
    const body = JSON.parse(init.body);
    calls.push(body);
    const ok = (obj) => ({ ok: true, status: 200, headers: { get: () => null }, text: async () => JSON.stringify(obj) });
    if (status !== 200) return { ok: false, status, headers: { get: () => null }, text: async () => '{"type":"error","error":{"type":"invalid_request_error","message":"bad"}}' };
    if (!body.tools) return ok({ content: [{ type: "text", text }], stop_reason: "end_turn", usage: { input_tokens: 10, output_tokens: 10 } }); // 整形の再依頼
    if (calls.filter((c) => c.tools).length === 1) {
      return ok({
        stop_reason: "pause_turn",
        usage: { input_tokens: 1000, output_tokens: 50 },
        content: [
          { type: "server_tool_use", id: "s1", name: "web_search", input: { query: "ポンド円 きょう" } },
          { type: "web_search_tool_result", tool_use_id: "s1", content: [
            { type: "web_search_result", url: A, title: "BOE holds rates", encrypted_content: "x" },
            { type: "web_search_result", url: B, title: "日経の記事", encrypted_content: "y" }
          ] }
        ]
      });
    }
    return ok({
      stop_reason: "end_turn",
      usage: { input_tokens: 2000, output_tokens: 800 },
      content: [
        { type: "server_tool_use", id: "s2", name: "web_search", input: { query: "日銀" } },
        { type: "web_search_tool_result", tool_use_id: "s2", content: [{ type: "web_search_result", url: C, title: "日銀 公表資料" }] },
        { type: "text", text: brokenFirst ? "以下です：" + text.slice(0, third).replace('"headline"', "headline") : text.slice(0, third) },
        { type: "text", text: text.slice(third, 2 * third), citations: [{ type: "web_search_result_location", url: D, title: "Bloomberg", cited_text: "…" }] },
        { type: "text", text: text.slice(2 * third) }
      ]
    });
  };
  f.calls = calls;
  return f;
}

async function dataDir() {
  await makeFixtures();
  const dir = await mkdtemp(join(tmpdir(), "brief-"));
  await updateAll({ outDir: dir, fetch: fakeFetch(), now, env: { FRED_API_KEY: "k".repeat(32), NODE_ENV: "test" }, log: quiet });
  await mkdir(join(dir, "manual"), { recursive: true });
  await cp(join(HERE, "..", "site", "data", "manual"), join(dir, "manual"), { recursive: true });
  return dir;
}

test("参考データの文章に、金利・中銀予定・CFTCが入る", async () => {
  const dir = await dataDir();
  const ctx = await buildContext(dir, now);
  assert.match(ctx, /現在時刻：10月3日（土） 06:35/);
  assert.match(ctx, /米国債利回り（2026-10-02時点/);
  assert.match(ctx, /日本国債利回り（2026-10-01時点/);
  assert.match(ctx, /主要中央銀行の政策金利.*日銀 1\.25%程度/);
  assert.match(ctx, /CFTC/);
});

test("検索の一時停止を継続し、出典を検証して保存する", async () => {
  const dir = await dataDir();
  const f = fakeClaude();
  const r = await run({ mode: "daily", fetch: f, dataDir: dir, env: { ANTHROPIC_API_KEY: "sk-test" }, now, log: quiet });
  assert.ok(r.ok, r.error && r.error.message);
  assert.equal(f.calls.length, 2);
  assert.equal(f.calls[0].model, "claude-sonnet-5-5");
  assert.equal(f.calls[0].tools[0].type, "web_search_20250305");
  assert.equal(f.calls[0].tools[0].max_uses, 8);
  assert.equal(f.calls[1].messages.length, 2, "一時停止した応答を assistant として送り返す");
  assert.equal(f.calls[1].messages[1].role, "assistant");
  const b = JSON.parse(await readFile(join(dir, "brief.json"), "utf8"));
  assert.equal(b.date, "2026-10-03");
  assert.equal(b.searches, 2);
  assert.deepEqual(b.sections.map((s) => s.items.length), [1, 0, 1, 1, 0], "でっちあげURLの項目は除外");
  assert.equal(b.sections[3].items[0].sources.length, 2, "引用（citations）のURLも出典として認める");
  assert.equal(b.watch.length, 1);
  assert.equal(b.dropped, 2);
  assert.ok(b.gbpjpy && b.gbpjpy.sources[0].url === A);
  const idx = JSON.parse(await readFile(join(dir, "briefs", "index.json"), "utf8"));
  assert.equal(idx.items[0].file, "2026-10-03-daily.json");
  const meta = JSON.parse(await readFile(join(dir, "meta.json"), "utf8"));
  assert.equal(meta.sources.brief_daily.status, "ok");
});

test("JSONが壊れていたら整形だけ再依頼する", async () => {
  const dir = await dataDir();
  const f = fakeClaude({ brokenFirst: true });
  const r = await run({ mode: "daily", fetch: f, dataDir: dir, env: { ANTHROPIC_API_KEY: "sk-test" }, now, log: quiet });
  assert.ok(r.ok, r.error && r.error.message);
  assert.equal(f.calls.length, 3);
  assert.equal(f.calls[2].tools, undefined);
});

test("APIエラー時は前回のまとめを残し、エラーを記録する", async () => {
  const dir = await dataDir();
  await writeFile(join(dir, "brief.json"), JSON.stringify({ headline: "前回" }));
  const r = await run({ mode: "daily", fetch: fakeClaude({ status: 400 }), dataDir: dir, env: { ANTHROPIC_API_KEY: "sk-test" }, now, log: quiet });
  assert.equal(r.ok, false);
  assert.equal(JSON.parse(await readFile(join(dir, "brief.json"), "utf8")).headline, "前回");
  const meta = JSON.parse(await readFile(join(dir, "meta.json"), "utf8"));
  assert.equal(meta.sources.brief_daily.status, "error");
});

test("APIキーが無ければスキップ", async () => {
  const dir = await dataDir();
  const r = await run({ mode: "daily", fetch: fakeClaude(), dataDir: dir, env: {}, now, log: quiet });
  assert.equal(r.skipped, true);
});

test("過去分は40件まで残し、古いファイルは消す", async () => {
  const dir = await dataDir();
  await mkdir(join(dir, "briefs"), { recursive: true });
  const items = [];
  for (let i = 0; i < 40; i++) {
    const d = new Date(Date.UTC(2026, 7, 1 + i)).toISOString().slice(0, 10);
    const file = `${d}-daily.json`;
    await writeFile(join(dir, "briefs", file), "{}");
    items.unshift({ date: d, mode: "daily", file, headline: "x" });
  }
  await writeFile(join(dir, "briefs", "index.json"), JSON.stringify({ items }));
  await run({ mode: "daily", fetch: fakeClaude(), dataDir: dir, env: { ANTHROPIC_API_KEY: "sk-test" }, now, log: quiet });
  const files = (await readdir(join(dir, "briefs"))).filter((f) => f !== "index.json");
  assert.equal(files.length, 40);
  assert.ok(!files.includes("2026-08-01-daily.json"), "最も古いものが消える");
});

test("週末まとめの形式", async () => {
  const dir = await dataDir();
  const weekly = {
    headline: "ドル高の1週間", summary: ["a", "b", "c"],
    review: [{ title: "BOE据え置き", body: "本文", sources: [{ title: "r", url: A }] }, { title: "日銀", body: "本文", sources: [{ title: "b", url: C }] }],
    gbpjpy: { text: "ポンド円は…", sources: [{ title: "n", url: B }] },
    next_week: [{ when: "10月7日（水）21:30", label: "米CPI", note: "", sources: [{ title: "n", url: B }] }],
    caution: ""
  };
  const r = await run({ mode: "weekly", fetch: fakeClaude({ json: weekly }), dataDir: dir, env: { ANTHROPIC_API_KEY: "sk-test" }, now, log: quiet });
  assert.ok(r.ok, r.error && r.error.message);
  const b = JSON.parse(await readFile(join(dir, "brief_weekly.json"), "utf8"));
  assert.equal(b.review.length, 2);
  assert.equal(b.next_week[0].label, "米CPI");
});

test("URLの正規化・JSON抽出・内容不足の検出", () => {
  assert.equal(normUrl("https://WWW.Example.com/a/b/#x"), "example.com/a/b");
  assert.equal(normUrl("javascript:alert(1)"), null);
  assert.deepEqual(extractJson("```json\n{\"a\":1}\n```"), { a: 1 });
  assert.throws(() => cleanBrief({ headline: "x", summary: ["a"] }, "daily", []), /内容が不足/);
});
