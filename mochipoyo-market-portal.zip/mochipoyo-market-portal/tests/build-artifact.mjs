// claude.ai のアーティファクト（画面プレビュー）用に preview を組み替える
//  - 外部スクリプト（TradingView）を読まない
//  - 文書の枠（doctype/html/head/body）は公開時に付くので外す
import { readFile, writeFile, readdir, stat } from "node:fs/promises";
import { join, relative } from "node:path";
import { buildPreview } from "./build-preview.mjs";

const out = process.argv[2];
if (!out) { console.error("出力先を指定してください"); process.exit(2); }
await buildPreview(out);
let cfg = await readFile(join(out, "config.js"), "utf8");
cfg = cfg.replace(/window\.PORTAL_PREVIEW = .*;\n$/, "") +
  'window.PORTAL_PREVIEW = "画面プレビュー：グラフの数値とAIまとめはサンプル（架空）です。中銀の日程・政策金利・休場日は確認済みの実データです。TradingViewのチャート類は、公開したサイトでのみ表示されます。";\nwindow.PORTAL_NO_TV = true;\n';
await writeFile(join(out, "config.js"), cfg);
let html = await readFile(join(out, "index.html"), "utf8");
html = html
  .replace(/<!doctype html>\s*/i, "")
  .replace(/<html[^>]*>\s*/i, "").replace(/<\/html>\s*/i, "")
  .replace(/<head>\s*/i, "").replace(/<\/head>\s*/i, "")
  .replace(/<body>\s*/i, "").replace(/<\/body>\s*/i, "")
  .replace(/<meta charset="utf-8">\s*/i, "")
  .replace(/<meta name="viewport"[^>]*>\s*/i, "")
  .replace(/<link rel="preconnect" href="https:\/\/s3\.tradingview\.com"[^>]*>\s*/i, "");
await writeFile(join(out, "index.html"), html);
const files = [];
async function walk(d) {
  for (const f of await readdir(d)) {
    const p = join(d, f);
    if ((await stat(p)).isDirectory()) await walk(p);
    else files.push(relative(out, p));
  }
}
await walk(out);
console.log(JSON.stringify(files.filter((f) => f !== "index.html" && f !== "robots.txt")));
