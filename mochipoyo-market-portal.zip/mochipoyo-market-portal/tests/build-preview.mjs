// 見た目の確認用プレビューを preview/ に作る（本番の site/ は変更しない）
//   - 会員確認を外す
//   - FRED・財務省・CFTC・BIS の部分は「架空のデータ」で埋める（tests/fixtures）
//   - AIまとめ・お知らせはサンプル文
// 使い方: node tests/build-preview.mjs  → python3 -m http.server 8080 --directory preview
import { cp, rm, readFile, writeFile, mkdir } from "node:fs/promises";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { makeFixtures, fakeFetch, FIXTURE_TODAY } from "./make-fixtures.mjs";
import { updateAll } from "../scripts/update-data.mjs";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const OUT = process.argv[2] || join(ROOT, "preview");
const BANNER = "プレビュー表示：金利・経済指標・ポジションのグラフとAIまとめはサンプル（架空の数値・文章）です。中銀の日程・政策金利・休場日は確認済みの実データです。TradingViewの部分は環境によって表示されません。";

export async function buildPreview(out = OUT) {
  await rm(out, { recursive: true, force: true });
  await cp(join(ROOT, "site"), out, { recursive: true });
  await makeFixtures();
  const now = new Date(FIXTURE_TODAY + "T22:00:00Z");
  await updateAll({ outDir: join(out, "data"), fetch: fakeFetch(), now, env: { FRED_API_KEY: "x".repeat(32), NODE_ENV: "test" }, only: ["fred", "jgb", "cot", "policy"], log: () => {} });

  const sampleSrc = (t, u) => [{ title: t, url: u }];
  const today = new Date(Date.now() + 9 * 3600000).toISOString().slice(0, 10);
  const brief = {
    mode: "daily", date: today, generated_at: new Date().toISOString(), model: "sample", searches: 8,
    headline: "【サンプル】AIの朝のまとめは、ここに一言で表示されます",
    summary: ["要点のサンプル1：前日の為替・金利・株の動きを短くまとめます", "要点のサンプル2：中央銀行や要人発言など、相場の材料を整理します", "要点のサンプル3：きょうの予定と、気をつけたい時間帯を挙げます"],
    gbpjpy: { text: "（サンプル）英国と日本の材料を中心に、ポンド円に関係するニュースを出典付きでまとめます。", sources: sampleSrc("イングランド銀行", "https://www.bankofengland.co.uk/") },
    sections: [
      { id: "policy", title: "金融政策・中央銀行", items: [{ title: "見出しのサンプル", body: "本文のサンプルです。実際には、前日から朝までの出来事を150字程度で、出典のリンク付きでまとめます。", sources: sampleSrc("日本銀行", "https://www.boj.or.jp/") }] },
      { id: "rates", title: "金利・債券", items: [{ title: "見出しのサンプル", body: "本文のサンプルです。検索で確認できた事実だけを書き、売買の推奨はしません。", sources: sampleSrc("財務省 国債金利情報", "https://www.mof.go.jp/jgbs/reference/interest_rate/index.htm") }] },
      { id: "macro", title: "経済指標", items: [] },
      { id: "fx", title: "為替", items: [{ title: "見出しのサンプル", body: "本文のサンプルです。出典が確認できない項目は自動で除外されます。", sources: sampleSrc("FRB", "https://www.federalreserve.gov/") }] },
      { id: "risk", title: "株式・商品・地政学", items: [] }
    ],
    watch: [{ when: "21:30", label: "（サンプル）きょうの注目予定", note: "AIが日時を確認できた予定だけを表示します", sources: sampleSrc("米労働統計局", "https://www.bls.gov/") }],
    caution: "",
    notice: "これは表示確認用のサンプルです。実際のまとめは、AI（Claude）がWeb上の公開情報を検索して自動で作成します。"
  };
  await writeFile(join(out, "data", "brief.json"), JSON.stringify(brief));
  await mkdir(join(out, "data", "briefs"), { recursive: true });
  await writeFile(join(out, "data", "briefs", `${today}-daily.json`), JSON.stringify(brief));
  await writeFile(join(out, "data", "briefs", "index.json"), JSON.stringify({ items: [{ date: today, mode: "daily", file: `${today}-daily.json`, headline: brief.headline }] }));
  const weekly = { ...brief, mode: "weekly", headline: "【サンプル】週末まとめは、先週の振り返りと来週の予定を表示します",
    review: [{ title: "先週の出来事のサンプル", body: "1週間の主な出来事を、出典付きで振り返ります。", sources: sampleSrc("ECB", "https://www.ecb.europa.eu/") }],
    next_week: [{ when: "（サンプル）", label: "来週の注目予定", note: "", sources: sampleSrc("FRB", "https://www.federalreserve.gov/") }] };
  delete weekly.sections; delete weekly.watch;
  await writeFile(join(out, "data", "brief_weekly.json"), JSON.stringify(weekly));
  await writeFile(join(out, "data", "manual", "notices.json"), JSON.stringify({ items: [{ date: today, title: "（サンプル）お知らせはここに表示されます", body: "data/manual/notices.json を編集すると、会員向けのお知らせを掲載できます。" }] }));
  const meta = JSON.parse(await readFile(join(out, "data", "meta.json"), "utf8"));
  meta.sources.brief_daily = { status: "ok", lastSuccess: brief.generated_at };
  meta.sources.brief_weekly = { status: "ok", lastSuccess: brief.generated_at };
  meta.sources.holidays = { status: "ok", lastSuccess: new Date().toISOString() };
  await writeFile(join(out, "data", "meta.json"), JSON.stringify(meta));
  let cfg = await readFile(join(out, "config.js"), "utf8");
  cfg = cfg.replace("enabled: true,", "enabled: false,") + `\nwindow.PORTAL_PREVIEW = ${JSON.stringify(BANNER)};\n`;
  await writeFile(join(out, "config.js"), cfg);
  return out;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  console.log("preview:", await buildPreview());
}
