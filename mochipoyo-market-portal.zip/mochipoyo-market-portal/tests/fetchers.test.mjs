// データ取得スクリプトのテスト（各提供元のフォーマットを再現した架空データで検証）
import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { makeFixtures, fakeFetch, FIXTURE_TODAY } from "./make-fixtures.mjs";
import { updateAll } from "../scripts/update-data.mjs";
import { yoy, mom, diff, crossMultiply, changePoints } from "../scripts/fetch-fred.mjs";
import { parseJgbDate } from "../scripts/fetch-jgb.mjs";
import { parseBisCsv } from "../scripts/fetch-policy.mjs";
import { buildUrl as cotUrl } from "../scripts/fetch-cot.mjs";
import { parseCsv } from "../scripts/lib/util.mjs";

let out;
const now = new Date(FIXTURE_TODAY + "T22:00:00Z");
const read = async (f) => JSON.parse(await readFile(join(out, f), "utf8"));
const quiet = () => {};

test.before(async () => {
  await makeFixtures();
  out = await mkdtemp(join(tmpdir(), "portal-data-"));
  const meta = await updateAll({ outDir: out, fetch: fakeFetch(), now, env: { FRED_API_KEY: "x".repeat(32), NODE_ENV: "test" }, log: quiet });
  for (const [k, v] of Object.entries(meta.sources)) assert.equal(v.status, "ok", `${k}: ${v.message}`);
});

test("FRED：欠損値 '.' を除き、利回り・FF金利・指標を出力", async () => {
  const r = await read("us_rates.json");
  assert.ok(r.series.DGS10.every(([, v]) => typeof v === "number"));
  assert.ok(!r.series.DGS10.some(([d]) => d === "2026-08-19"));
  assert.equal(r.fed.upper - r.fed.lower, 0.25);
  assert.equal(r.fed.upperHistory.at(-1)[1], 4.0);
  const m = await read("us_macro.json");
  const ids = m.indicators.map((i) => i.id);
  assert.deepEqual(ids, ["cpi", "core_cpi", "cpi_mom", "core_pce", "pce", "unrate", "nfp", "ahe", "claims", "sahm"]);
  for (const i of m.indicators) {
    assert.ok(i.latest && typeof i.latest.value === "number", i.id);
    assert.ok(i.series.length >= 24, i.id);
  }
  assert.equal(m.indicators.find((i) => i.id === "claims").freq, "W");
  const fx = await read("fx_ref.json");
  const last = fx.gbpjpy.at(-1);
  const uj = new Map(fx.usdjpy).get(last[0]), gu = new Map(fx.gbpusd).get(last[0]);
  assert.ok(Math.abs(last[1] - uj * gu) < 0.001);
});

test("FRED：前年比・前月比・前月差の計算", () => {
  const s = [["2025-01-01", 100], ["2025-02-01", 101], ["2026-01-01", 103], ["2026-02-01", 104.03]];
  assert.deepEqual(yoy(s), [["2026-01-01", 3], ["2026-02-01", 3]]);
  assert.deepEqual(mom(s), [["2025-02-01", 1], ["2026-02-01", 1]]); // 月が飛んだ所は計算しない
  assert.deepEqual(diff([["2026-01-01", 1000], ["2026-02-01", 1150]]), [["2026-02-01", 150]]);
  assert.deepEqual(crossMultiply([["d1", 150], ["d2", 151]], [["d2", 1.3]]), [["d2", 196.3]]);
  assert.deepEqual(changePoints([["a", 1], ["b", 1], ["c", 2], ["d", 2]]), [["a", 1], ["c", 2]]);
});

test("財務省：和暦の日付変換と '-' の欠損、当月分と過去分の結合", async () => {
  assert.equal(parseJgbDate("R8.10.1"), "2026-10-01");
  assert.equal(parseJgbDate("H31.4.26"), "2019-04-26");
  assert.equal(parseJgbDate("R元.5.7"), "2019-05-07");
  assert.equal(parseJgbDate("S49.9.24"), "1974-09-24");
  assert.equal(parseJgbDate("2026/10/1"), "2026-10-01");
  assert.equal(parseJgbDate("※注記"), null);
  const j = await read("jgb.json");
  assert.deepEqual(j.tenors, ["1Y", "2Y", "3Y", "4Y", "5Y", "6Y", "7Y", "8Y", "9Y", "10Y", "15Y", "20Y", "25Y", "30Y", "40Y"]);
  assert.equal(j.rows.at(-1)[0], "2026-10-01");
  assert.ok(j.rows.every(([, v]) => v.length === 15));
  const dates = j.rows.map(([d]) => d);
  assert.deepEqual([...dates].sort(), dates);
  assert.equal(new Set(dates).size, dates.length);
});

test("CFTC：8通貨・日付昇順・数値化", async () => {
  const c = await read("cot.json");
  assert.equal(c.currencies.length, 8);
  assert.equal(c.latest, "2026-09-29");
  for (const cur of c.currencies) {
    assert.ok(cur.rows.length >= 100, cur.ccy);
    assert.ok(cur.rows.every((r) => r.length === 8 && r.slice(1).every((v) => typeof v === "number")));
  }
  const u = new URL(cotUrl("2024-09-01"));
  assert.match(u.searchParams.get("$where"), /cftc_contract_market_code in\('097741','096742'/);
  assert.equal(u.searchParams.get("$order"), "report_date_as_yyyy_mm_dd DESC");
});

test("BIS：カンマ入りの引用符フィールドを正しく読み、変化点だけ残す", async () => {
  const p = await read("policy_bis.json");
  assert.deepEqual(Object.keys(p.areas).sort(), ["AU", "CA", "CH", "GB", "JP", "NZ", "US", "XM"]);
  assert.deepEqual(p.areas.AU.last, ["2026-09-24", 4.35]);
  assert.equal(p.areas.US.last[1], 3.875);
  const a = parseBisCsv('REF_AREA,TITLE,TIME_PERIOD,OBS_VALUE\n"JP: Japan","a, b",2026-09-01,0.5\nJP,"x",2026-09-02,NaN\n');
  assert.deepEqual(a.JP.last, ["2026-09-01", 0.5]);
  assert.deepEqual(parseCsv('a,"b,""c""",d\r\n1,2,3'), [["a", 'b,"c"', "d"], ["1", "2", "3"]]);
});

test("祝日：内閣府CSV（Shift_JIS）とGOV.UK", async () => {
  const jp = await read("holidays_jp.json");
  assert.ok(jp.days.some(([d, n]) => d === "2026-10-12" && n === "スポーツの日"));
  assert.ok(jp.days.every(([d]) => d >= "2025-01-01"));
  const uk = await read("holidays_uk.json");
  assert.deepEqual(uk.days.find(([d]) => d === "2026-12-28"), ["2026-12-28", "ボクシングデー（振替）", "Boxing Day"]);
  assert.match(uk.license, /Open Government Licence v3\.0/);
});

test("Fincs公開鍵：公開情報以外は保存しない", async () => {
  const k = await read("fincs_jwks.json");
  assert.deepEqual(Object.keys(k.keys[0]).sort(), ["alg", "e", "kid", "kty", "n", "use"]);
});

test("FREDキーが無ければスキップし、他のデータは更新する", async () => {
  const dir = await mkdtemp(join(tmpdir(), "portal-nokey-"));
  const meta = await updateAll({ outDir: dir, fetch: fakeFetch(), now, env: {}, log: quiet });
  assert.equal(meta.sources.fred.status, "skipped");
  assert.equal(meta.sources.jgb.status, "ok");
});

test("取得元が落ちていても前回のファイルは残り、エラーを記録する", async () => {
  const dir = await mkdtemp(join(tmpdir(), "portal-err-"));
  await updateAll({ outDir: dir, fetch: fakeFetch(), now, env: { NODE_ENV: "test" }, log: quiet, only: ["cot"] });
  const down = async () => ({ ok: false, status: 503, text: async () => "down", json: async () => ({}) });
  const meta = await updateAll({ outDir: dir, fetch: down, now, env: { NODE_ENV: "test" }, log: quiet, only: ["cot"] });
  assert.equal(meta.sources.cot.status, "error");
  assert.ok(meta.sources.cot.lastSuccess, "前回成功時刻が残る");
  const c = JSON.parse(await readFile(join(dir, "cot.json"), "utf8"));
  assert.equal(c.currencies.length, 8);
});
