// 会員確認（gate.js）のテスト：自前で作った鍵でJWTに署名し、合否を確かめる
import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const Gate = require("../site/assets/gate.js");
const subtle = globalThis.crypto.subtle;

const b64u = (bytes) => Buffer.from(bytes).toString("base64url");
const enc = (obj) => b64u(new TextEncoder().encode(JSON.stringify(obj)));

async function makeKey(kid) {
  const pair = await subtle.generateKey(
    { name: "RSASSA-PKCS1-v1_5", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" },
    true,
    ["sign", "verify"]
  );
  const jwk = await subtle.exportKey("jwk", pair.publicKey);
  return { pair, pub: { kty: "RSA", kid, use: "sig", alg: "RS256", n: jwk.n, e: jwk.e } };
}
async function sign(privateKey, header, payload) {
  const data = enc(header) + "." + enc(payload);
  const sig = await subtle.sign("RSASSA-PKCS1-v1_5", privateKey, new TextEncoder().encode(data));
  return data + "." + b64u(new Uint8Array(sig));
}

const now = Math.floor(Date.now() / 1000);
const ISS = "https://api.fincs.jp";
const AUD = "https://example.github.io/portal/";
let K1, K2;

test.before(async () => {
  K1 = await makeKey("tal-key-prd-v1");
  K2 = await makeKey("tal-key-prd-v2");
});

const base = () => ({ iss: ISS, aud: AUD, sub: "member-1", plan_id: "plan_a", iat: now - 5, exp: now + 300 });
const opts = (extra) => Object.assign({ keys: [K1.pub], issuer: ISS, audiences: [AUD], allowedPlanIds: [], planClaim: "plan_id", now }, extra);

test("正しいトークンは合格する", async () => {
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1", typ: "JWT" }, base());
  const r = await Gate.verifyJwt(t, opts());
  assert.equal(r.payload.sub, "member-1");
});

test("audの末尾スラッシュ有無は同じとみなす", async () => {
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, Object.assign(base(), { aud: "https://example.github.io/portal" }));
  await Gate.verifyJwt(t, opts());
});

test("署名の改ざんは不合格", async () => {
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, base());
  const p = t.split(".");
  const forged = p[0] + "." + enc(Object.assign(base(), { plan_id: "vip" })) + "." + p[2];
  await assert.rejects(Gate.verifyJwt(forged, opts()), (e) => e.code === "signature");
});

test("別の鍵で署名されたものは不合格", async () => {
  const t = await sign(K2.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, base());
  await assert.rejects(Gate.verifyJwt(t, opts()), (e) => e.code === "signature");
});

test("alg:none や HS256 は拒否", async () => {
  const t1 = enc({ alg: "none" }) + "." + enc(base()) + ".";
  await assert.rejects(Gate.verifyJwt(t1, opts()), (e) => e.code === "alg");
  const t2 = enc({ alg: "HS256", kid: "tal-key-prd-v1" }) + "." + enc(base()) + ".AAAA";
  await assert.rejects(Gate.verifyJwt(t2, opts()), (e) => e.code === "alg");
});

test("発行元が違えば不合格", async () => {
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, Object.assign(base(), { iss: "https://evil.example" }));
  await assert.rejects(Gate.verifyJwt(t, opts()), (e) => e.code === "iss");
});

test("期限切れは不合格（60秒の猶予あり）", async () => {
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, Object.assign(base(), { exp: now - 61 }));
  await assert.rejects(Gate.verifyJwt(t, opts()), (e) => e.code === "expired");
  const t2 = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, Object.assign(base(), { exp: now - 30 }));
  await Gate.verifyJwt(t2, opts());
});

test("expが無いトークンは不合格", async () => {
  const p = base(); delete p.exp;
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, p);
  await assert.rejects(Gate.verifyJwt(t, opts()), (e) => e.code === "exp_missing");
});

test("宛先(aud)が違えば不合格", async () => {
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, Object.assign(base(), { aud: "https://other.example/" }));
  await assert.rejects(Gate.verifyJwt(t, opts()), (e) => e.code === "aud" && e.detail === "https://other.example");
});

test("プラン制限：許可プラン以外は不合格、配列や数値も扱える", async () => {
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, base());
  await assert.rejects(Gate.verifyJwt(t, opts({ allowedPlanIds: ["plan_b"] })), (e) => e.code === "plan");
  await Gate.verifyJwt(t, opts({ allowedPlanIds: ["plan_b", "plan_a"] }));
  const t2 = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, Object.assign(base(), { plan_id: [12, 34] }));
  await Gate.verifyJwt(t2, opts({ allowedPlanIds: ["34"] }));
});

test("kidが見つからない鍵ファイルは飛ばして次の取得元を使う", async () => {
  const t = await sign(K2.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v2" }, base());
  const files = {
    "local.json": { keys: [K1.pub] },          // 古いコピー（v1のみ）
    "remote.json": { keys: [K1.pub, K2.pub] }  // 新しい鍵を含む
  };
  const fakeFetch = async (url) => ({ ok: true, status: 200, json: async () => files[url] });
  const r = await Gate.verifyWithSources(t, ["local.json", "remote.json"], opts({ keys: undefined }), fakeFetch);
  assert.equal(r.header.kid, "tal-key-prd-v2");
});

test("鍵が1つも取れなければ jwks エラー", async () => {
  const t = await sign(K1.pair.privateKey, { alg: "RS256", kid: "tal-key-prd-v1" }, base());
  const failFetch = async () => { throw new TypeError("Failed to fetch"); };
  await assert.rejects(Gate.verifyWithSources(t, ["a.json", "b.json"], opts(), failFetch), (e) => e.code === "jwks");
});

test("壊れたトークンは malformed", async () => {
  await assert.rejects(Gate.verifyJwt("abc", opts()), (e) => e.code === "malformed");
  await assert.rejects(Gate.verifyJwt("a.b.c", opts()), (e) => e.code === "malformed");
  await assert.rejects(Gate.verifyJwt("x".repeat(9000), opts()), (e) => e.code === "malformed");
});

test("既定のaudは オリジン・ディレクトリ・ページURL", () => {
  const a = Gate.defaultAudiences({ origin: "https://u.github.io", pathname: "/portal/index.html" });
  assert.deepEqual(a, ["https://u.github.io", "https://u.github.io/portal/", "https://u.github.io/portal/index.html"]);
});
