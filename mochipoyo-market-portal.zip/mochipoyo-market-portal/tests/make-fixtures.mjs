// テスト・プレビュー用の「架空の」入力データを作る（各提供元の公開フォーマットを再現）
// 数値はすべて乱数で作った架空の値です。本番の site/data には使いません。
//   node tests/make-fixtures.mjs  → tests/fixtures/ に出力
import { mkdir, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const DIR = join(dirname(fileURLToPath(import.meta.url)), "fixtures");
export const FIXTURE_TODAY = "2026-10-02"; // この日の夕方に取得した想定

// 再現できる乱数
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const gauss = (r) => Math.sqrt(-2 * Math.log(r() || 1e-9)) * Math.cos(2 * Math.PI * r());
const iso = (t) => new Date(t).toISOString().slice(0, 10);
const D = 86400000;
const T0 = Date.parse(FIXTURE_TODAY + "T00:00:00Z");

function businessDays(fromDays) {
  const out = [];
  for (let t = T0 - fromDays * D; t <= T0; t += D) {
    const w = new Date(t).getUTCDay();
    if (w !== 0 && w !== 6) out.push(iso(t));
  }
  return out;
}
function months(n) {
  const out = [];
  const d = new Date(T0);
  for (let i = n; i >= 1; i--) out.push(iso(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - i, 1)));
  return out;
}
function walk(dates, start, vol, r, { min = -Infinity, max = Infinity, drift = 0, digits = 2 } = {}) {
  let v = start;
  return dates.map((d) => {
    v = Math.min(max, Math.max(min, v + drift + gauss(r) * vol));
    return [d, Number(v.toFixed(digits))];
  });
}

// ---------- FRED ----------
function fredSeries() {
  const r = rng(42);
  const bd = businessDays(365 * 6 + 5);
  const S = {};
  const y10 = walk(bd, 3.9, 0.045, r, { min: 3.2, max: 5.1 });
  S.DGS10 = y10;
  S.DGS2 = y10.map(([d, v], i) => [d, Number((v - 0.45 + Math.sin(i / 90) * 0.15 + gauss(r) * 0.02).toFixed(2))]);
  S.DGS5 = y10.map(([d, v]) => [d, Number((v - 0.22 + gauss(r) * 0.02).toFixed(2))]);
  S.DGS30 = y10.map(([d, v]) => [d, Number((v + 0.48 + gauss(r) * 0.02).toFixed(2))]);
  S.DGS3MO = y10.map(([d, v], i) => [d, Number((3.95 + Math.sin(i / 160) * 0.3 + gauss(r) * 0.01).toFixed(2))]);
  // FF金利の誘導目標（階段状）
  const steps = [["2020-01-01", 4.25], ["2025-09-18", 4.0], ["2025-10-30", 3.75], ["2025-12-11", 3.5], ["2026-09-17", 3.75]];
  const all = [];
  for (let t = T0 - (365 * 6 + 5) * D; t <= T0; t += D) all.push(iso(t));
  const lvl = (d) => steps.filter(([s]) => s <= d).at(-1)[1];
  S.DFEDTARL = all.map((d) => [d, lvl(d)]);
  S.DFEDTARU = all.map((d) => [d, lvl(d) + 0.25]);
  // 為替（週1回更新なので最新は先週金曜まで）
  const fxDays = bd.filter((d) => d <= "2026-09-25");
  S.DEXJPUS = walk(fxDays, 148, 0.6, r, { min: 135, max: 162, digits: 2 });
  S.DEXUSUK = walk(fxDays, 1.33, 0.005, r, { min: 1.22, max: 1.42, digits: 4 });
  S.DEXUSEU = walk(fxDays, 1.15, 0.004, r, { min: 1.05, max: 1.22, digits: 4 });
  // 月次の物価・雇用
  const mo = months(72);
  const idx = (start, g, vol) => { let v = start; return mo.map((d) => { v *= 1 + g + gauss(r) * vol; return [d, Number(v.toFixed(3))]; }); };
  S.CPIAUCSL = idx(290, 0.0024, 0.0012);
  S.CPILFESL = idx(295, 0.0025, 0.0008);
  S.PCEPI = idx(118, 0.0021, 0.0009);
  S.PCEPILFE = idx(119, 0.0022, 0.0006);
  S.CES0500000003 = idx(29.5, 0.0031, 0.0012);
  S.UNRATE = walk(mo, 3.8, 0.07, r, { min: 3.4, max: 4.9, digits: 1 });
  let emp = 152000;
  S.PAYEMS = mo.map((d) => { emp += 140 + gauss(r) * 90; return [d, Math.round(emp)]; });
  S.SAHMREALTIME = walk(mo, 0.2, 0.05, r, { min: 0, max: 0.6, digits: 2 });
  // 週次の新規失業保険申請（土曜締め）
  const sats = [];
  for (let t = T0 - 365 * 6 * D; t <= T0 - 6 * D; t += D) if (new Date(t).getUTCDay() === 6) sats.push(iso(t));
  S.ICSA = walk(sats, 225000, 6000, r, { min: 190000, max: 270000, digits: 0 });
  // FREDの欠損表記 "." を混ぜる
  const gap = S.DGS10.findIndex(([d]) => d === "2026-08-19");
  S.DGS10[gap] = ["2026-08-19", "."];
  return S;
}

// ---------- 財務省 JGB ----------
const ERA = (d) => { const [y, m, dd] = d.split("-").map(Number); return y >= 2019 && (y > 2019 || m >= 5) ? `R${y - 2018}.${m}.${dd}` : `H${y - 1988}.${m}.${dd}`; };
function jgbCsv(rows, title) {
  const head = "基準日,1年,2年,3年,4年,5年,6年,7年,8年,9年,10年,15年,20年,25年,30年,40年";
  const lines = [`${title},,,,,,,,,,,,,,,(単位 : %)`, head];
  for (const [d, vals] of rows) lines.push([ERA(d), ...vals.map((v) => (v === null ? "-" : String(Number(v.toFixed(3)))))].join(","));
  return lines.join("\r\n") + "\r\n";
}
function jgbRows() {
  const r = rng(7);
  const bd = businessDays(365 * 4);
  let lvl = 1.4, slope = 1.6;
  return bd.map((d) => {
    lvl = Math.min(3.4, Math.max(0.9, lvl + 0.0018 + gauss(r) * 0.025));
    slope = Math.min(2.4, Math.max(1.0, slope + gauss(r) * 0.01));
    const ten = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 40];
    const base10 = lvl;
    const vals = ten.map((y) => base10 - 1.35 + slope * Math.log(1 + y) / Math.log(11) + (y > 20 ? 0.05 : 0) + gauss(r) * 0.008);
    return [d, vals];
  });
}

// ---------- CFTC ----------
const COT_CODES = { "097741": "JAPANESE YEN", "096742": "BRITISH POUND", "099741": "EURO FX", "232741": "AUSTRALIAN DOLLAR", "112741": "NZ DOLLAR", "090741": "CANADIAN DOLLAR", "092741": "SWISS FRANC", "095741": "MEXICAN PESO" };
function cotRecords() {
  const r = rng(99);
  const tuesdays = [];
  for (let t = T0 - 7 * 115 * D; t <= T0; t += D) if (new Date(t).getUTCDay() === 2) tuesdays.push(iso(t));
  const recs = [];
  for (const [code, name] of Object.entries(COT_CODES)) {
    let net = (r() - 0.5) * 120000, oi = 150000 + r() * 150000;
    for (const d of tuesdays) {
      net = Math.max(-0.6 * oi, Math.min(0.6 * oi, net + gauss(r) * 9000));
      oi = Math.max(60000, oi + gauss(r) * 5000);
      const long = Math.round(oi * 0.3 + Math.max(net, 0));
      const short = Math.round(oi * 0.3 + Math.max(-net, 0));
      recs.push({
        report_date_as_yyyy_mm_dd: d + "T00:00:00.000",
        cftc_contract_market_code: code,
        market_and_exchange_names: `${name} - CHICAGO MERCANTILE EXCHANGE`,
        open_interest_all: String(Math.round(oi)),
        noncomm_positions_long_all: String(long),
        noncomm_positions_short_all: String(short),
        comm_positions_long_all: String(Math.round(oi * 0.45 - net * 0.8)),
        comm_positions_short_all: String(Math.round(oi * 0.45 + net * 0.8)),
        nonrept_positions_long_all: String(Math.round(oi * 0.08)),
        nonrept_positions_short_all: String(Math.round(oi * 0.08))
      });
    }
  }
  return recs.sort((a, b) => (a.report_date_as_yyyy_mm_dd < b.report_date_as_yyyy_mm_dd ? 1 : -1));
}

// ---------- BIS ----------
function bisCsv() {
  const head = "FREQ,REF_AREA,UNIT_MEASURE,UNIT_MULT,TIME_FORMAT,COMPILATION,DECIMALS,SOURCE_REF,SUPP_INFO_BREAKS,TITLE,TIME_PERIOD,OBS_VALUE,OBS_STATUS,OBS_CONF,OBS_PRE_BREAK";
  // 架空の推移（最終値の水準だけは確認済みの実際の値に近づけている）
  const paths = {
    US: [["2023-10-01", 5.375], ["2024-09-19", 4.875], ["2024-12-19", 4.375], ["2025-09-18", 4.125], ["2025-10-30", 3.875], ["2025-12-11", 3.625], ["2026-09-17", 3.875]],
    JP: [["2023-10-01", -0.1], ["2024-03-19", 0.05], ["2024-08-01", 0.25], ["2025-01-27", 0.5], ["2025-12-22", 0.75], ["2026-04-30", 1.0], ["2026-09-24", 1.25]],
    GB: [["2023-10-01", 5.25], ["2024-08-02", 5.0], ["2025-02-07", 4.5], ["2025-08-08", 4.0], ["2025-12-19", 3.75]],
    XM: [["2023-10-01", 4.0], ["2024-06-12", 3.75], ["2025-06-11", 2.0], ["2026-06-17", 2.25], ["2026-09-16", 2.5]],
    AU: [["2023-10-01", 4.1], ["2023-11-08", 4.35]],
    NZ: [["2023-10-01", 5.5], ["2025-10-09", 2.5], ["2026-07-09", 2.5], ["2026-09-03", 2.75]],
    CA: [["2023-10-01", 5.0], ["2025-10-30", 2.25]],
    CH: [["2023-10-01", 1.75], ["2025-06-20", 0.0]]
  };
  const lastObs = { US: "2026-09-28", JP: "2026-09-29", GB: "2026-09-28", XM: "2026-09-29", AU: "2026-09-24", NZ: "2026-09-25", CA: "2026-09-28", CH: "2026-09-29" };
  const lines = [head];
  for (const [area, steps] of Object.entries(paths)) {
    for (let t = T0 - 365 * 3 * D; iso(t) <= lastObs[area]; t += D) {
      const d = iso(t);
      const v = steps.filter(([s]) => s <= d).at(-1)?.[1] ?? steps[0][1];
      lines.push(`D,${area},"Percent, per annum",0,P1D,"Long text, with commas",4,"Central bank, source",,"Policy rate, ${area}",${d},${v},A,F,`);
    }
  }
  return lines.join("\n") + "\n";
}

// ---------- 祝日 ----------
const JP_HOLIDAYS = [
  ["2025/1/1", "元日"], ["2025/1/13", "成人の日"], ["2025/2/11", "建国記念の日"], ["2025/2/23", "天皇誕生日"], ["2025/2/24", "休日"],
  ["2026/1/1", "元日"], ["2026/1/12", "成人の日"], ["2026/10/12", "スポーツの日"], ["2026/11/3", "文化の日"], ["2026/11/23", "勤労感謝の日"],
  ["2027/1/1", "元日"], ["2027/1/11", "成人の日"], ["2027/3/21", "春分の日"], ["2027/3/22", "休日"]
];
const UK_JSON = {
  "england-and-wales": { division: "england-and-wales", events: [
    { title: "Christmas Day", date: "2026-12-25", notes: "", bunting: true },
    { title: "Boxing Day", date: "2026-12-28", notes: "Substitute day", bunting: true },
    { title: "New Year's Day", date: "2027-01-01", notes: "", bunting: true },
    { title: "Good Friday", date: "2027-03-26", notes: "", bunting: false }
  ] },
  scotland: { division: "scotland", events: [] },
  "northern-ireland": { division: "northern-ireland", events: [] }
};

async function writeSjis(file, text) {
  const utf = file + ".utf8";
  await writeFile(utf, text, "utf8");
  execFileSync("iconv", ["-f", "UTF-8", "-t", "SHIFT_JIS", "-o", file, utf]);
  execFileSync("rm", [utf]);
}

export async function makeFixtures() {
  await mkdir(DIR, { recursive: true });
  const S = fredSeries();
  await writeFile(join(DIR, "fred.json"), JSON.stringify(S));
  const rows = jgbRows();
  const curMonth = FIXTURE_TODAY.slice(0, 7);
  // 当月分は最新1営業日（10/1）だけ、過去分は前月末まで（財務省の配信形態を再現）
  const cur = rows.filter(([d]) => d.startsWith(curMonth) && d < FIXTURE_TODAY);
  const past = rows.filter(([d]) => d < curMonth + "-01");
  past.unshift(["2019-04-26", [-0.15, -0.16, -0.17, -0.18, -0.17, -0.16, -0.15, -0.13, -0.1, -0.05, 0.25, 0.4, null, 0.55, 0.6]]);
  await writeSjis(join(DIR, "jgbcm.csv"), jgbCsv(cur, "国債金利情報 (令和8年10月)") + ",,,,,,,,,,,,,,,\r\n※金利情報が更新されない場合は、ブラウザのキャッシュを削除してください。\r\n");
  await writeSjis(join(DIR, "jgbcm_all.csv"), jgbCsv(past, "国債金利情報"));
  await writeFile(join(DIR, "cot.json"), JSON.stringify(cotRecords()));
  await writeFile(join(DIR, "bis.csv"), bisCsv());
  await writeSjis(join(DIR, "syukujitsu.csv"), ["国民の祝日・休日月日,国民の祝日・休日名称", ...JP_HOLIDAYS.map((r) => r.join(","))].join("\r\n") + "\r\n");
  await writeFile(join(DIR, "bank-holidays.json"), JSON.stringify(UK_JSON));
  return DIR;
}

// URL → フィクスチャを返す偽のfetch
export function fakeFetch(dir = DIR) {
  const { readFileSync } = require_fs();
  const S = JSON.parse(readFileSync(join(dir, "fred.json"), "utf8"));
  const resp = (body, status = 200) => ({
    ok: status >= 200 && status < 300,
    status,
    async json() { return typeof body === "string" ? JSON.parse(body) : JSON.parse(Buffer.from(body).toString("utf8")); },
    async text() { return typeof body === "string" ? body : Buffer.from(body).toString("utf8"); },
    async arrayBuffer() { const b = typeof body === "string" ? Buffer.from(body, "utf8") : body; return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); }
  });
  const calls = [];
  const f = async (url) => {
    calls.push(url);
    const u = new URL(url);
    if (u.hostname === "api.stlouisfed.org") {
      const id = u.searchParams.get("series_id");
      const start = u.searchParams.get("observation_start");
      if (!S[id]) return resp(JSON.stringify({ error_code: 400, error_message: "Bad Request. The series does not exist." }), 400);
      const obs = S[id].filter(([d]) => d >= start).map(([date, value]) => ({ realtime_start: FIXTURE_TODAY, realtime_end: FIXTURE_TODAY, date, value: String(value) }));
      return resp(JSON.stringify({ count: obs.length, observations: obs }));
    }
    if (url.endsWith("/jgbcm.csv")) return resp(readFileSync(join(dir, "jgbcm.csv")));
    if (url.endsWith("/jgbcm_all.csv")) return resp(readFileSync(join(dir, "jgbcm_all.csv")));
    if (u.hostname === "publicreporting.cftc.gov") return resp(readFileSync(join(dir, "cot.json"), "utf8"));
    if (u.hostname === "stats.bis.org") return resp(readFileSync(join(dir, "bis.csv"), "utf8"));
    if (url.endsWith("syukujitsu.csv")) return resp(readFileSync(join(dir, "syukujitsu.csv")));
    if (url.endsWith("bank-holidays.json")) return resp(readFileSync(join(dir, "bank-holidays.json"), "utf8"));
    if (u.hostname === "api.fincs.jp") return resp(JSON.stringify({ keys: [{ kty: "RSA", kid: "test-key", use: "sig", alg: "RS256", n: "sXch", e: "AQAB", x5c: ["should-be-dropped"] }] }));
    return resp("not found", 404);
  };
  f.calls = calls;
  return f;
}
import { createRequire } from "node:module";
function require_fs() { return createRequire(import.meta.url)("node:fs"); }

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  console.log("fixtures:", await makeFixtures());
}
